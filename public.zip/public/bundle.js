/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"main": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/index.ts","vendors"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/constants/index.ts":
/*!********************************!*\
  !*** ./src/constants/index.ts ***!
  \********************************/
/*! exports provided: COLOURS, SIDE_UP, SIDE_RIGHT, SIDE_DOWN, SIDE_LEFT, DEAD, ALIVE, RUN_END, TOP_LEFT, TOP, TOP_RIGHT, LEFT, RIGHT, BOTTOM_LEFT, BOTTOM, BOTTOM_RIGHT, START_DOOR, UP_SPIKE, DOWN_SPIKE, LEFT_SPIKE, RIGHT_SPIKE, WIZARD, SPIDER, SPELL, BLANK, YELLOW_KEY, BLUE_KEY, RED_KEY, GREEN_KEY, BLUE_DOOR_LOCKED, BLUE_DOOR_EXIT, BLUE_DOOR_ENTRANCE, YELLOW_DOOR_LOCKED, YELLOW_DOOR_EXIT, YELLOW_DOOR_ENTRANCE, RED_DOOR_LOCKED, RED_DOOR_EXIT, RED_DOOR_ENTRANCE, GREEN_DOOR_LOCKED, GREEN_DOOR_EXIT, GREEN_DOOR_ENTRANCE, CURSOR, ZERO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COLOURS", function() { return COLOURS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_UP", function() { return SIDE_UP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_RIGHT", function() { return SIDE_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_DOWN", function() { return SIDE_DOWN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_LEFT", function() { return SIDE_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEAD", function() { return DEAD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALIVE", function() { return ALIVE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RUN_END", function() { return RUN_END; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP_LEFT", function() { return TOP_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP", function() { return TOP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP_RIGHT", function() { return TOP_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEFT", function() { return LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RIGHT", function() { return RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM_LEFT", function() { return BOTTOM_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM", function() { return BOTTOM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM_RIGHT", function() { return BOTTOM_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "START_DOOR", function() { return START_DOOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UP_SPIKE", function() { return UP_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOWN_SPIKE", function() { return DOWN_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEFT_SPIKE", function() { return LEFT_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RIGHT_SPIKE", function() { return RIGHT_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WIZARD", function() { return WIZARD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPIDER", function() { return SPIDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPELL", function() { return SPELL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLANK", function() { return BLANK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_KEY", function() { return YELLOW_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_KEY", function() { return BLUE_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_KEY", function() { return RED_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_KEY", function() { return GREEN_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_LOCKED", function() { return BLUE_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_EXIT", function() { return BLUE_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_ENTRANCE", function() { return BLUE_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_LOCKED", function() { return YELLOW_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_EXIT", function() { return YELLOW_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_ENTRANCE", function() { return YELLOW_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_LOCKED", function() { return RED_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_EXIT", function() { return RED_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_ENTRANCE", function() { return RED_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_LOCKED", function() { return GREEN_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_EXIT", function() { return GREEN_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_ENTRANCE", function() { return GREEN_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CURSOR", function() { return CURSOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ZERO", function() { return ZERO; });
var COLOURS = {
    white: {
        string: '#CFC6B8',
        number: 0xCFC6B8
    },
    darkGray: {
        string: '#000000',
        number: 0x000000,
    },
    maroon: {
        string: '#4b2a3c',
        number: 0x4B2A3C,
    },
    green: {
        string: '#38D973',
        number: 0x38D973,
    }
};
var SIDE_UP = 0;
var SIDE_RIGHT = 1;
var SIDE_DOWN = 2;
var SIDE_LEFT = 3;
var DEAD = 407;
var ALIVE = 402;
var RUN_END = 406;
var TOP_LEFT = 19;
var TOP = 20;
var TOP_RIGHT = 21;
var LEFT = 67;
var RIGHT = 69;
var BOTTOM_LEFT = 115;
var BOTTOM = 116;
var BOTTOM_RIGHT = 117;
var START_DOOR = 489;
var UP_SPIKE = 23;
var DOWN_SPIKE = 25;
var LEFT_SPIKE = 74;
var RIGHT_SPIKE = 73;
var WIZARD = 80;
var SPIDER = 269;
var SPELL = 557;
var BLANK = 0;
var YELLOW_KEY = 561;
var BLUE_KEY = 562;
var RED_KEY = 563;
var GREEN_KEY = 564;
var BLUE_DOOR_LOCKED = 433;
var BLUE_DOOR_EXIT = 434;
var BLUE_DOOR_ENTRANCE = 435;
var YELLOW_DOOR_LOCKED = 436;
var YELLOW_DOOR_EXIT = 437;
var YELLOW_DOOR_ENTRANCE = 438;
var RED_DOOR_LOCKED = 439;
var RED_DOOR_EXIT = 440;
var RED_DOOR_ENTRANCE = 441;
var GREEN_DOOR_LOCKED = 442;
var GREEN_DOOR_EXIT = 443;
var GREEN_DOOR_ENTRANCE = 444;
var CURSOR = 713;
var ZERO = 852;


/***/ }),

/***/ "./src/game-objects/button.ts":
/*!************************************!*\
  !*** ./src/game-objects/button.ts ***!
  \************************************/
/*! exports provided: Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Button = (function (_super) {
    __extends(Button, _super);
    function Button(scene, x, y, text, style, callbacks) {
        var _this = _super.call(this, scene, x, y, text, style) || this;
        _this.defaultStyle = style;
        _this.setInteractive({ useHandCursor: true })
            .on('pointerover', function () {
            _this.buttonOver();
            if (callbacks && typeof callbacks.pointerover === 'function') {
                callbacks.pointerover();
            }
        })
            .on('pointerout', function () {
            _this.buttonOut();
            if (callbacks && typeof callbacks.pointerout === 'function') {
                callbacks.pointerout();
            }
        })
            .on('pointerdown', function () {
            _this.buttonDown();
            if (callbacks && typeof callbacks.pointerdown === 'function') {
                callbacks.pointerdown();
            }
        })
            .on('pointerup', function () {
            if (callbacks && typeof callbacks.pointerup === 'function') {
                callbacks.pointerup();
            }
        });
        return _this;
    }
    Button.prototype.buttonOver = function () {
        this.setStyle({
            fill: constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].green.string,
        });
    };
    Button.prototype.buttonOut = function () {
        this.setStyle(this.defaultStyle);
    };
    Button.prototype.buttonDown = function () {
        this.setStyle({
            fill: constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].green.string,
        });
    };
    return Button;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["GameObjects"].Text));



/***/ }),

/***/ "./src/game-objects/index.ts":
/*!***********************************!*\
  !*** ./src/game-objects/index.ts ***!
  \***********************************/
/*! exports provided: Button, Wizard, Spell, Spider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./button */ "./src/game-objects/button.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return _button__WEBPACK_IMPORTED_MODULE_0__["Button"]; });

/* harmony import */ var _wizard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wizard */ "./src/game-objects/wizard.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Wizard", function() { return _wizard__WEBPACK_IMPORTED_MODULE_1__["Wizard"]; });

/* harmony import */ var _spell__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./spell */ "./src/game-objects/spell.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spell", function() { return _spell__WEBPACK_IMPORTED_MODULE_2__["Spell"]; });

/* harmony import */ var _spider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./spider */ "./src/game-objects/spider.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spider", function() { return _spider__WEBPACK_IMPORTED_MODULE_3__["Spider"]; });







/***/ }),

/***/ "./src/game-objects/spell.ts":
/*!***********************************!*\
  !*** ./src/game-objects/spell.ts ***!
  \***********************************/
/*! exports provided: Spell */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spell", function() { return Spell; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Spell = (function (_super) {
    __extends(Spell, _super);
    function Spell(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["SPELL"]) || this;
        _this.setOrigin(0, 0);
        var angle = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Angle.Between(_this.x, _this.y, scene.player.x, scene.player.y);
        _this.setRotation(angle - 3.92699);
        scene.physics.add.overlap(_this, scene.player, function (spell, tile) {
            if (scene.isDead || scene.relocating)
                return;
            scene.killPlayer();
        });
        scene.physics.add.collider(_this, scene.groundLayer, function (spell, tile) {
            spell.destroy();
        });
        return _this;
    }
    return Spell;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Physics"].Arcade.Sprite));



/***/ }),

/***/ "./src/game-objects/spider.ts":
/*!************************************!*\
  !*** ./src/game-objects/spider.ts ***!
  \************************************/
/*! exports provided: Spider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spider", function() { return Spider; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Spider = (function (_super) {
    __extends(Spider, _super);
    function Spider(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["SPIDER"] - 1) || this;
        _this.direction = 2;
        _this.setOrigin(0.5, 0.5);
        scene.physics.add.collider(_this, scene.groundLayer, function (spider, tile) {
            _this.direction = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Wrap(_this.direction + 1, 0, 4);
            spider.setAngle(spider.angle + 90);
            var directions = [
                function () { return spider.setVelocity(0, -100); },
                function () { return spider.setVelocity(100, 0); },
                function () { return spider.setVelocity(0, 100); },
                function () { return spider.setVelocity(-100, 0); },
            ];
            directions[_this.direction]();
        });
        scene.physics.add.overlap(_this, scene.player, function (spider, tile) {
            if (scene.isDead || scene.relocating)
                return;
            scene.killPlayer();
        });
        return _this;
    }
    return Spider;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Physics"].Arcade.Sprite));



/***/ }),

/***/ "./src/game-objects/wizard.ts":
/*!************************************!*\
  !*** ./src/game-objects/wizard.ts ***!
  \************************************/
/*! exports provided: Wizard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Wizard", function() { return Wizard; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
/* harmony import */ var _spell__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./spell */ "./src/game-objects/spell.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var Wizard = (function (_super) {
    __extends(Wizard, _super);
    function Wizard(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["WIZARD"] - 1) || this;
        _this.setOrigin(0, 0);
        _this.shootingTimer = scene.time.addEvent({ delay: 1000, callback: function () {
                if (scene.isDead || scene.relocating)
                    return;
                var spell = new _spell__WEBPACK_IMPORTED_MODULE_2__["Spell"](scene, x, y, texture);
                scene.add.existing(spell);
                scene.physics.add.existing(spell);
                scene.physics.moveToObject(spell, scene.player);
                spell.body.setSize(2, 2, true);
            }, callbackScope: _this, loop: true });
        return _this;
    }
    return Wizard;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["GameObjects"].Sprite));



/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/*! exports provided: game */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "game", function() { return game; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var scenes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! scenes */ "./src/scenes/index.ts");


var config = {
    title: 'Miz jam',
    type: phaser__WEBPACK_IMPORTED_MODULE_0__["AUTO"],
    zoom: 2,
    scale: {
        parent: 'game',
        width: 800,
        height: 600,
        autoCenter: phaser__WEBPACK_IMPORTED_MODULE_0__["Scale"].CENTER_BOTH,
        mode: phaser__WEBPACK_IMPORTED_MODULE_0__["Scale"].FIT,
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: {
                y: 0
            },
        }
    },
    scene: scenes__WEBPACK_IMPORTED_MODULE_1__["default"],
    parent: 'game',
    backgroundColor: 0x4B2A3C,
};
var game = new phaser__WEBPACK_IMPORTED_MODULE_0__["Game"](config);


/***/ }),

/***/ "./src/scenes/boot.ts":
/*!****************************!*\
  !*** ./src/scenes/boot.ts ***!
  \****************************/
/*! exports provided: BootScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BootScene", function() { return BootScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var sceneConfig = {
    active: false,
    visible: false,
    key: 'Boot',
};
var BootScene = (function (_super) {
    __extends(BootScene, _super);
    function BootScene() {
        return _super.call(this, sceneConfig) || this;
    }
    BootScene.prototype.preload = function () {
        var _this = this;
        var progressBar = this.add.graphics();
        var progressBox = this.add.graphics();
        progressBox.fillStyle(_constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].darkGray.number, 0.8);
        progressBox.fillRect(240, 270, 320, 50);
        var _a = this.cameras.main, centerX = _a.centerX, centerY = _a.centerY;
        var loadingText = this.make.text({
            x: centerX,
            y: centerY,
            text: 'Loading...',
            style: {
                font: '20px monospace',
                fill: _constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].white.string
            }
        });
        loadingText.setOrigin(0.5, 0.5);
        this.load.on('progress', function (value) {
            progressBar.clear();
            progressBar.fillStyle(_constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].white.number, 1);
            progressBar.fillRect(250, 280, 300 * value, 30);
        });
        this.load.on('fileprogress', function (file) {
            loadingText.setText(file.src);
        });
        this.load.on('complete', function () {
            progressBar.destroy();
            progressBox.destroy();
            loadingText.destroy();
            _this.scene.start('Title');
        });
        this.load.tilemapTiledJSON('title', './assets/title.json');
        this.load.tilemapTiledJSON('map0', './assets/level0.json');
        this.load.tilemapTiledJSON('map1', './assets/level1.json');
        this.load.tilemapTiledJSON('map2', './assets/level2.json');
        this.load.tilemapTiledJSON('map3', './assets/level3.json');
        this.load.spritesheet('tiles', './assets/tiles.png', {
            frameWidth: 16,
            frameHeight: 16,
        });
    };
    return BootScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/game.ts":
/*!****************************!*\
  !*** ./src/scenes/game.ts ***!
  \****************************/
/*! exports provided: GameScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameScene", function() { return GameScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants/index.ts");
/* harmony import */ var game_objects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! game-objects */ "./src/game-objects/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};



var sceneConfig = {
    active: false,
    visible: false,
    key: 'Game',
};
var GameScene = (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        return _super.call(this, sceneConfig) || this;
    }
    GameScene.prototype.init = function (_a) {
        var level = _a.level;
        this.level = level;
    };
    GameScene.prototype.preload = function () {
        this.isDead = false;
        this.config = {
            gravity: 1200,
            speed: 120,
            gravityDirection: 1,
            jumpForce: 255,
        };
        this.canFlipGravity = true;
        this.isFlipped = false;
        this.rotating = false;
        this.direction = _constants__WEBPACK_IMPORTED_MODULE_1__["SIDE_UP"];
        this.relocating = false;
        this.items = [];
    };
    GameScene.prototype.create = function () {
        var _this = this;
        var _a = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes, SPACE = _a.SPACE, E = _a.E;
        this.cursors = this.input.keyboard.createCursorKeys();
        var eKey = this.input.keyboard.addKey(E);
        var spaceKey = this.input.keyboard.addKey(SPACE);
        this.map = this.make.tilemap({ key: "map" + this.level });
        this.tiles = this.map.addTilesetImage('tiles');
        this.bgLayer = this.map.createStaticLayer('Background', this.tiles);
        this.groundLayer = this.map.createStaticLayer('Ground', this.tiles);
        this.spikesLayer = this.map.createDynamicLayer('Spikes', this.tiles);
        this.actionsLayer = this.map.createDynamicLayer('Actions', this.tiles);
        this.groundLayer.setCollisionByExclusion([0, 1]);
        this.physics.world.bounds.width = this.groundLayer.width;
        this.physics.world.bounds.height = this.groundLayer.height;
        var startTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["START_DOOR"]);
        var redDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"]);
        var blueDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"]);
        var yellowDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"]);
        this.checkpoint = startTile;
        this.player = this.physics.add.sprite(startTile.pixelX + 8, startTile.pixelY + 5, 'tiles', _constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"]);
        this.player.body.gravity.set(0, this.config.gravity);
        this.anims.create({
            key: 'running',
            frames: this.anims.generateFrameNumbers('tiles', { start: _constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"], end: _constants__WEBPACK_IMPORTED_MODULE_1__["RUN_END"] }),
            frameRate: 10,
            repeat: -1,
        });
        this.player.setCollideWorldBounds(true);
        this.physics.add.collider(this.player, this.groundLayer, function (player, tile) {
            if (_this.isDead || _this.relocating) {
                return;
            }
            if (!_this.rotating) {
                _this.checkRotation(tile, player);
            }
            if (!_this.canFlipGravity) {
                _this.canFlipGravity = true;
            }
        }, function () {
            return !_this.isDead && !_this.relocating;
        });
        this.physics.add.overlap(this.player, this.spikesLayer, function (player, tile) {
            if (_this.isDead || _this.relocating) {
                return false;
            }
            _this.killPlayer();
        }, function (player, tile) {
            if (tile.index === 1 || _this.isDead || _this.relocating) {
                return false;
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["UP_SPIKE"]) {
                if (player.y > tile.pixelY - 4 && player.x >= tile.pixelX - 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["DOWN_SPIKE"]) {
                if (player.y < tile.pixelY + 15 && player.x >= tile.pixelX - 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT_SPIKE"]) {
                if (player.x >= tile.pixelX + 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT_SPIKE"]) {
                if (player.x <= tile.pixelX + 14) {
                    return true;
                }
            }
            return false;
        });
        this.physics.add.overlap(this.player, this.actionsLayer, function (_player, tile) {
            var _a;
            var actions = (_a = {},
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(redDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"]] = function (tile) {
                    var redDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"]);
                    _this.relocate(redDoorEntranceTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(yellowDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"]] = function (tile) {
                    var yellowDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"]);
                    _this.relocate(yellowDoorEntranceTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"]] = function (tile) {
                    _this.events.emit('completed');
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(blueDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"]] = function (tile) {
                    var blueDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"]);
                    _this.relocate(blueDoorEntranceTile);
                },
                _a);
            actions[tile.index](tile);
        }, function (_player, _a) {
            var index = _a.index;
            if (_this.isDead || _this.relocating) {
                return false;
            }
            if (!eKey.isDown) {
                return false;
            }
            var actions = [_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_EXIT"]];
            return actions.includes(index);
        });
        spaceKey.on("down", function () { return _this.flip(); });
        this.cameras.main.startFollow(this.player);
        this.cameras.main.setZoom(2);
        this.spikesLayer.forEachTile(function (tile) {
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["WIZARD"]) {
                _this.spikesLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
                var wizard = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Wizard"](_this, tile.pixelX, tile.pixelY, 'tiles');
                _this.add.existing(wizard);
            }
            ;
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["SPIDER"]) {
                _this.spikesLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
                var spider = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Spider"](_this, tile.pixelX, tile.pixelY, 'tiles');
                _this.add.existing(spider);
                _this.physics.add.existing(spider);
                spider.setVelocityY(100);
            }
        });
    };
    GameScene.prototype.update = function () {
        if (this.isDead || this.relocating) {
            return;
        }
        if (this.cursors.up.isDown) {
            this.jump();
        }
        if (this.cursors.left.isDown && !this.cursors.right.isDown) {
            this.player.anims.play('running', true);
            if (!this.isFlipped) {
                this.moveCounterClockwise();
            }
            else {
                this.moveClockwise();
            }
        }
        else if (this.cursors.right.isDown && !this.cursors.left.isDown) {
            this.player.anims.play('running', true);
            if (this.isFlipped) {
                this.moveCounterClockwise();
            }
            else {
                this.moveClockwise();
            }
        }
        else {
            this.stopMoving();
        }
    };
    GameScene.prototype.moveCounterClockwise = function () {
        var _this = this;
        this.player.setFlipX(!this.isFlipped);
        var directions = [
            function () {
                _this.player.setVelocity(-_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, -_this.config.speed);
            },
            function () {
                _this.player.setVelocity(_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(-_this.player.body.velocity.x, _this.config.speed);
            },
        ];
        directions[this.direction]();
    };
    GameScene.prototype.moveClockwise = function () {
        var _this = this;
        this.player.setFlipX(this.isFlipped);
        var directions = [
            function () {
                _this.player.setVelocity(_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, _this.config.speed);
            },
            function () {
                _this.player.setVelocity(-_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, -_this.config.speed);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.stopMoving = function () {
        var _this = this;
        this.player.anims.stop();
        var directions = [
            function () {
                _this.player.setVelocity(0, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, 0);
            },
            function () {
                _this.player.setVelocity(0, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, 0);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.jump = function () {
        var _this = this;
        var directions = [
            function () {
                if (_this.player.body.blocked.down) {
                    _this.player.setVelocityY(-_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.left) {
                    _this.player.setVelocityX(_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.up) {
                    _this.player.setVelocityY(_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.right) {
                    _this.player.setVelocityX(-_this.config.jumpForce);
                }
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.checkRotation = function (_a, _b) {
        var _this = this;
        var index = _a.index, tile = __rest(_a, ["index"]);
        var x = _b.x, y = _b.y, player = __rest(_b, ["x", "y"]);
        if (this.rotating)
            return;
        var directions = [
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_RIGHT"] && x >= tile.pixelX + 20 && player.body.velocity.x > 0) {
                    _this.handleRotation(1, x + 4, y + 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_LEFT"] && x <= tile.pixelX && player.body.velocity.x < 0) {
                    _this.handleRotation(-1, x - 8, y + 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT"]) {
                    _this.handleRotation(1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT"]) {
                    _this.handleRotation(-1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_RIGHT"] && y >= tile.pixelY + 20 && player.body.velocity.y > 0) {
                    _this.handleRotation(1, x - 8, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_RIGHT"] && y <= tile.pixelY && player.body.velocity.y < 0) {
                    _this.handleRotation(-1, x - 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM"]) {
                    _this.handleRotation(1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP"]) {
                    _this.handleRotation(-1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_LEFT"] && x <= tile.pixelX && player.body.velocity.x < 0) {
                    _this.handleRotation(1, x - 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_RIGHT"] && x >= tile.pixelX + 20 && player.body.velocity.x > 0) {
                    _this.handleRotation(-1, x, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT"]) {
                    _this.handleRotation(-1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT"]) {
                    _this.handleRotation(1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_LEFT"] && y <= tile.pixelY && player.body.velocity.y < 0) {
                    _this.handleRotation(1, x + 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_LEFT"] && y >= tile.pixelY + 20 && player.body.velocity.y > 0) {
                    _this.handleRotation(-1, x + 8, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM"] && !_this.rotating) {
                    _this.handleRotation(-1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP"] && !_this.rotating) {
                    _this.handleRotation(1, x, y);
                }
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.handleRotation = function (delta, x, y) {
        var _this = this;
        this.player.body.setAllowGravity(false);
        this.player.setVelocity(0, 0);
        this.rotating = true;
        this.tweens.add({
            targets: [this.player],
            angle: this.player.angle + 90 * delta,
            x: x,
            y: y,
            duration: 200,
            onComplete: function () {
                _this.rotating = false;
                _this.player.body.setAllowGravity(true);
                _this.direction = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Wrap(_this.direction + delta, 0, 4);
                _this.setGravity();
            }
        });
    };
    GameScene.prototype.setGravity = function () {
        var _this = this;
        var directions = [
            function () {
                _this.player.setGravity(0, _this.config.gravity);
            },
            function () {
                _this.player.setGravity(-_this.config.gravity, 0);
            },
            function () {
                _this.player.setGravity(0, -_this.config.gravity);
            },
            function () {
                _this.player.setGravity(_this.config.gravity, 0);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.flip = function () {
        if (this.isDead) {
            return;
        }
        if (this.canFlipGravity) {
            this.canFlipGravity = false;
            if (this.direction === 0 || this.direction === 2) {
                this.player.body.gravity.y *= -1;
                this.player.body.gravity.x = 0;
            }
            else {
                this.player.body.gravity.x *= -1;
                this.player.body.gravity.y = 0;
            }
            this.player.setFlipY(!this.isFlipped);
            var directions = [2, 3, 0, 1];
            this.direction = directions[this.direction];
            this.isFlipped = !this.isFlipped;
        }
    };
    GameScene.prototype.relocate = function (tile, callback, callback2) {
        var _this = this;
        this.relocating = true;
        this.player.body.setAllowGravity(false);
        this.tweens.add({
            targets: [this.player],
            alpha: {
                from: 1,
                to: 0
            },
            duration: 100,
            onComplete: function () {
                if (callback && typeof callback === 'function') {
                    callback(tile);
                }
                _this.resetFlippage();
                _this.tweens.add({
                    targets: [_this.player],
                    x: tile.pixelX + 8,
                    y: tile.pixelY + 7,
                    onComplete: function () {
                        _this.tweens.add({
                            targets: [_this.player],
                            alpha: {
                                from: 0,
                                to: 1,
                            },
                            onComplete: function () {
                                _this.player.body.setAllowGravity(true);
                                _this.relocating = false;
                                _this.checkpoint = tile;
                                if (callback2 && typeof callback2 === 'function') {
                                    callback2(tile);
                                }
                            }
                        });
                    }
                });
            }
        });
    };
    GameScene.prototype.pickupItem = function (item, tile) {
        this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
        this.events.emit('pickup', item);
        this.items.push(item);
        this.checkpoint = tile;
    };
    GameScene.prototype.revive = function () {
        var _this = this;
        this.relocate(this.checkpoint, function (tile) {
            _this.player.setFrame(_constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"]);
        }, function (tile) {
            _this.isDead = false;
        });
    };
    GameScene.prototype.resetFlippage = function () {
        this.direction = 0;
        this.setGravity();
        this.isFlipped = false;
        this.player.setFlipX(false);
        this.player.setFlipY(false);
        this.player.setAngle(0);
    };
    GameScene.prototype.killPlayer = function () {
        this.player.setVelocity(0, 0);
        this.player.body.setAllowGravity(false);
        this.player.anims.stop();
        this.player.setFrame(_constants__WEBPACK_IMPORTED_MODULE_1__["DEAD"]);
        this.isDead = true;
        this.time.delayedCall(1000, this.revive, [], this);
    };
    return GameScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/hud.ts":
/*!***************************!*\
  !*** ./src/scenes/hud.ts ***!
  \***************************/
/*! exports provided: HUDScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HUDScene", function() { return HUDScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! store */ "./node_modules/store/dist/store.legacy.js");
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(store__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var game_objects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! game-objects */ "./src/game-objects/index.ts");
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};




var fontStyle = {
    fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].maroon.string,
    fontFamily: 'kenny1bit',
    align: 'center',
};
var sceneConfig = {
    active: false,
    visible: false,
    key: 'HUD',
};
var HUDScene = (function (_super) {
    __extends(HUDScene, _super);
    function HUDScene() {
        return _super.call(this, sceneConfig) || this;
    }
    HUDScene.prototype.init = function (_a) {
        var level = _a.level;
        this.level = level;
        this.timer = 0;
    };
    HUDScene.prototype.create = function () {
        var _this = this;
        var ENTER = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes.ENTER;
        var enterKey = this.input.keyboard.addKey(ENTER);
        this.items = [];
        this.map = this.make.tilemap({ key: "map" + this.level });
        this.tiles = this.map.addTilesetImage('tiles');
        var hudGraphics = this.add.graphics({
            fillStyle: {
                alpha: 0.9,
                color: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].white.number
            },
        }).setScrollFactor(0);
        var itemGraphics = this.add.graphics({
            fillStyle: {
                color: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].maroon.number
            }
        });
        var hudBg = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(650, 0, 150, 600);
        hudGraphics.fillRectShape(hudBg);
        this.timeTitle = this.add.text(670, 10, ' time', fontStyle);
        this.timeText = this.add.text(670, 50, '', fontStyle);
        this.completedText = this.add.text(400, 300, ' level completed!', __assign(__assign({}, fontStyle), { fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].green.string })).setOrigin(0.5).setAlpha(0);
        this.thankyouText = this.add.text(400, 350, ' thank you for playing my game', __assign(__assign({}, fontStyle), { fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].green.string })).setOrigin(0.5).setAlpha(0);
        this.nextLevelButton = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Button"](this, 400, 350, ' next level - hit enter', {
            fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].white.string,
            fontFamily: 'kenny1bit',
            align: 'center',
        }, {
            pointerup: function () { return _this.nextLevel(); },
        }).setOrigin(0.5);
        var slot1 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 150, 50, 50);
        var slot2 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 150, 50, 50);
        var slot3 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 210, 50, 50);
        var slot4 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 210, 50, 50);
        var slot5 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 270, 50, 50);
        var slot6 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 270, 50, 50);
        itemGraphics.fillRectShape(slot1);
        itemGraphics.fillRectShape(slot2);
        itemGraphics.fillRectShape(slot3);
        itemGraphics.fillRectShape(slot4);
        itemGraphics.fillRectShape(slot5);
        itemGraphics.fillRectShape(slot6);
        var itemSprites = [
            this.add.sprite(695, 175, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 175, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(695, 235, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 235, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(695, 195, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 195, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
        ];
        this.scene.get('Game').events.on('pickup', function (item) {
            var index = _this.items.length;
            _this.items.push(item);
            itemSprites[index].setFrame(item - 1);
        });
        this.scene.get('Game').events.on('completed', function () {
            store__WEBPACK_IMPORTED_MODULE_1__["set"]('highestLevel', _this.level + 1);
            _this.timedEvent.destroy();
            _this.completedText.setAlpha(1);
            if (_this.level === 9) {
                _this.add.existing(_this.thankyouText);
            }
            else {
                _this.add.existing(_this.nextLevelButton);
            }
        });
        this.timedEvent = this.time.addEvent({ delay: 1000, callback: function () {
                _this.timer += 1;
                _this.timeText.setText(" " + _this.timer);
            }, callbackScope: this, loop: true });
        enterKey.on("down", function () { return _this.nextLevel(); });
    };
    HUDScene.prototype.nextLevel = function () {
        var level = this.level + 1;
        var gameScene = this.scene.get('Game');
        gameScene.events.removeListener('pickup');
        gameScene.events.removeListener('completed');
        gameScene.scene.restart({ level: level });
        this.scene.restart({ level: level });
    };
    return HUDScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/index.ts":
/*!*****************************!*\
  !*** ./src/scenes/index.ts ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _boot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./boot */ "./src/scenes/boot.ts");
/* harmony import */ var _game__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./game */ "./src/scenes/game.ts");
/* harmony import */ var _hud__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hud */ "./src/scenes/hud.ts");
/* harmony import */ var _title__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./title */ "./src/scenes/title.ts");




/* harmony default export */ __webpack_exports__["default"] = ([
    _boot__WEBPACK_IMPORTED_MODULE_0__["BootScene"],
    _game__WEBPACK_IMPORTED_MODULE_1__["GameScene"],
    _hud__WEBPACK_IMPORTED_MODULE_2__["HUDScene"],
    _title__WEBPACK_IMPORTED_MODULE_3__["TitleScene"],
]);


/***/ }),

/***/ "./src/scenes/title.ts":
/*!*****************************!*\
  !*** ./src/scenes/title.ts ***!
  \*****************************/
/*! exports provided: TitleScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TitleScene", function() { return TitleScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! store */ "./node_modules/store/dist/store.legacy.js");
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(store__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var sceneConfig = {
    active: false,
    visible: false,
    key: 'Title',
};
var TitleScene = (function (_super) {
    __extends(TitleScene, _super);
    function TitleScene() {
        return _super.call(this, sceneConfig) || this;
    }
    TitleScene.prototype.create = function () {
        var _this = this;
        var ENTER = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes.ENTER;
        var enterKey = this.input.keyboard.addKey(ENTER);
        var highestLevel = store__WEBPACK_IMPORTED_MODULE_1__["get"]('highestLevel') || 0;
        this.selected = highestLevel;
        this.cursors = this.input.keyboard.createCursorKeys();
        this.map = this.make.tilemap({ key: "title" });
        this.tiles = this.map.addTilesetImage('tiles');
        this.bgLayer = this.map.createStaticLayer('Background', this.tiles);
        this.numberLayer = this.map.createStaticLayer('Numbers', this.tiles);
        this.actionsLayer = this.map.createDynamicLayer('Actions', this.tiles);
        var levelTiles = [];
        for (var i = 0; i < 10; i++) {
            var tile = this.numberLayer.findByIndex(constants__WEBPACK_IMPORTED_MODULE_2__["ZERO"] + i);
            if (i <= highestLevel) {
                this.actionsLayer.putTileAt(constants__WEBPACK_IMPORTED_MODULE_2__["BLANK"], tile.x, tile.y);
            }
            levelTiles.push(tile);
        }
        var startTile = levelTiles[this.selected];
        this.cursor = this.add.sprite(startTile.pixelX, startTile.pixelY, 'tiles', constants__WEBPACK_IMPORTED_MODULE_2__["CURSOR"]).setOrigin(0, 0);
        this.cameras.main.setBounds(0, 0, 800, 600);
        this.cameras.main.startFollow(this.cursor);
        this.cameras.main.setZoom(2);
        this.cursors.left.on("down", function () {
            _this.selected = _this.selected === 0 ? highestLevel : _this.selected - 1;
            _this.cursor.setX(levelTiles[_this.selected].pixelX);
        });
        this.cursors.right.on("down", function () {
            _this.selected = _this.selected === highestLevel ? 0 : _this.selected + 1;
            _this.cursor.setX(levelTiles[_this.selected].pixelX);
        });
        enterKey.on("down", function () {
            _this.startGame(_this.selected);
        });
    };
    TitleScene.prototype.startGame = function (level) {
        this.scene.launch('Game', { level: level }).launch('HUD', { level: level }).stop();
    };
    return TitleScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnN0YW50cy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvZ2FtZS1vYmplY3RzL2J1dHRvbi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvZ2FtZS1vYmplY3RzL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9nYW1lLW9iamVjdHMvc3BlbGwudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2dhbWUtb2JqZWN0cy9zcGlkZXIudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2dhbWUtb2JqZWN0cy93aXphcmQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9zY2VuZXMvYm9vdC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NlbmVzL2dhbWUudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjZW5lcy9odWQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjZW5lcy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NlbmVzL3RpdGxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLFFBQVEsb0JBQW9CO1FBQzVCO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsaUJBQWlCLDRCQUE0QjtRQUM3QztRQUNBO1FBQ0Esa0JBQWtCLDJCQUEyQjtRQUM3QztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLGdCQUFnQix1QkFBdUI7UUFDdkM7OztRQUdBO1FBQ0E7UUFDQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDdkpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxJQUFNLE9BQU8sR0FBRztJQUNyQixLQUFLLEVBQUU7UUFDTCxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsUUFBUTtLQUNqQjtJQUNELFFBQVEsRUFBRTtRQUNSLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLE1BQU0sRUFBRSxRQUFRO0tBQ2pCO0lBQ0QsTUFBTSxFQUFFO1FBQ04sTUFBTSxFQUFFLFNBQVM7UUFDakIsTUFBTSxFQUFFLFFBQVE7S0FDakI7SUFDRCxLQUFLLEVBQUU7UUFDTCxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsUUFBUTtLQUNqQjtDQUNGO0FBRU0sSUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLElBQU0sVUFBVSxHQUFHLENBQUMsQ0FBQztBQUNyQixJQUFNLFNBQVMsR0FBRyxDQUFDLENBQUM7QUFDcEIsSUFBTSxTQUFTLEdBQUcsQ0FBQztBQUVuQixJQUFNLElBQUksR0FBRyxHQUFHLENBQUM7QUFDakIsSUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQ2xCLElBQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQztBQUVwQixJQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7QUFDcEIsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO0FBQ2YsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQ3JCLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUNoQixJQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7QUFDakIsSUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDO0FBQ3hCLElBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQztBQUNuQixJQUFNLFlBQVksR0FBRyxHQUFHLENBQUM7QUFFekIsSUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDO0FBRXZCLElBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztBQUNwQixJQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7QUFDdEIsSUFBTSxVQUFVLEdBQUcsRUFBRSxDQUFDO0FBQ3RCLElBQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUN2QixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEIsSUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDO0FBQ25CLElBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUVsQixJQUFNLEtBQUssR0FBRyxDQUFDLENBQUM7QUFDaEIsSUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDO0FBQ3ZCLElBQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQztBQUNyQixJQUFNLE9BQU8sR0FBRyxHQUFHLENBQUM7QUFDcEIsSUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3RCLElBQU0sZ0JBQWdCLEdBQUcsR0FBRyxDQUFDO0FBQzdCLElBQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQztBQUMzQixJQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQztBQUMvQixJQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQztBQUMvQixJQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQztBQUM3QixJQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQztBQUNqQyxJQUFNLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFDNUIsSUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDO0FBQzFCLElBQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDO0FBQzlCLElBQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDO0FBQzlCLElBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUM1QixJQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUVoQyxJQUFNLE1BQU0sR0FBRyxHQUFHLENBQUM7QUFDbkIsSUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVTO0FBQ0c7QUFFcEM7SUFBNEIsMEJBQXVCO0lBQ2pELGdCQUNFLEtBQW1CLEVBQ25CLENBQVMsRUFDVCxDQUFTLEVBQ1QsSUFBWSxFQUNaLEtBQVMsRUFDVCxTQUVDO1FBUkgsWUFVRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLFNBMEJoQztRQXpCQyxLQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUMxQixLQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDO2FBQzNDLEVBQUUsQ0FBQyxhQUFhLEVBQUU7WUFDakIsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7Z0JBQzVELFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxZQUFZLEVBQUU7WUFDaEIsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2pCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUU7Z0JBQzNELFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUN4QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxhQUFhLEVBQUU7WUFDakIsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7Z0JBQzVELFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDZixJQUFJLFNBQVMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxTQUFTLEtBQUssVUFBVSxFQUFFO2dCQUMxRCxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDdkI7UUFDSCxDQUFDLENBQUMsQ0FBQzs7SUFDTCxDQUFDO0lBRU0sMkJBQVUsR0FBakI7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ1osSUFBSSxFQUFFLGlEQUFPLENBQUMsS0FBSyxDQUFDLE1BQU07U0FDM0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLDBCQUFTLEdBQWhCO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVNLDJCQUFVLEdBQWpCO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNaLElBQUksRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNO1NBQzNCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDSCxhQUFDO0FBQUQsQ0FBQyxDQXREMkIsa0RBQWtCLENBQUMsSUFBSSxHQXNEbEQ7Ozs7Ozs7Ozs7Ozs7O0FDekREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXdCO0FBQ0E7QUFDRDtBQUNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSFM7QUFDQztBQUdsQztJQUEyQix5QkFBNEI7SUFDckQsZUFDRSxLQUFnQixFQUNoQixDQUFTLEVBQ1QsQ0FBUyxFQUNULE9BQWU7UUFKakIsWUFNRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxTQWNuQztRQWJDLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQixJQUFNLEtBQUssR0FBRywyQ0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBRXZGLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUVqQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxLQUFtQyxFQUFFLElBQTBCO1lBQzVHLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsVUFBVTtnQkFBRSxPQUFPO1lBQzdDLEtBQUssQ0FBQyxVQUFVLEVBQUU7UUFDcEIsQ0FBQyxDQUFDO1FBRUYsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUksRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLFVBQUMsS0FBbUMsRUFBRSxJQUEwQjtZQUNsSCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDbEIsQ0FBQyxDQUFDOztJQUNKLENBQUM7SUFFSCxZQUFDO0FBQUQsQ0FBQyxDQXZCMEIsOENBQWMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQXVCdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0JnQztBQUNFO0FBR25DO0lBQTRCLDBCQUE0QjtJQUV0RCxnQkFDRSxLQUFnQixFQUNoQixDQUFTLEVBQ1QsQ0FBUyxFQUNULE9BQWU7UUFKakIsWUFNRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsZ0RBQU0sR0FBRyxDQUFDLENBQUMsU0FvQnhDO1FBbkJDLEtBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLEtBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFJLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxVQUFDLE1BQW9DLEVBQUUsSUFBMEI7WUFDbkgsS0FBSSxDQUFDLFNBQVMsR0FBRywyQ0FBVyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFtQixDQUFFO1lBQy9FLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztZQUNuQyxJQUFNLFVBQVUsR0FBRztnQkFDakIsY0FBTSxhQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUEzQixDQUEyQjtnQkFDakMsY0FBTSxhQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBMUIsQ0FBMEI7Z0JBQ2hDLGNBQU0sYUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQTFCLENBQTBCO2dCQUNoQyxjQUFNLGFBQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQTNCLENBQTJCO2FBQ2xDO1lBQ0QsVUFBVSxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUM5QixDQUFDLENBQUM7UUFFRixLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxNQUFvQyxFQUFFLElBQTBCO1lBQzdHLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsVUFBVTtnQkFBRSxPQUFPO1lBQzdDLEtBQUssQ0FBQyxVQUFVLEVBQUU7UUFDcEIsQ0FBQyxDQUFDOztJQUNKLENBQUM7SUFDSCxhQUFDO0FBQUQsQ0FBQyxDQTdCMkIsOENBQWMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQTZCdkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pDZ0M7QUFDRTtBQUNIO0FBR2hDO0lBQTRCLDBCQUF5QjtJQUVuRCxnQkFDRSxLQUFnQixFQUNoQixDQUFTLEVBQ1QsQ0FBUyxFQUNULE9BQWU7UUFKakIsWUFNRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsZ0RBQU0sR0FBRyxDQUFDLENBQUMsU0FXeEM7UUFWQyxLQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNyQixLQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7Z0JBQ2hFLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsVUFBVTtvQkFBRSxPQUFNO2dCQUM1QyxJQUFNLEtBQUssR0FBRyxJQUFJLDRDQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQzlDLEtBQUssQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMxQixLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQztZQUVoQyxDQUFDLEVBQUUsYUFBYSxFQUFFLEtBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzs7SUFDeEMsQ0FBQztJQUNILGFBQUM7QUFBRCxDQUFDLENBcEIyQixrREFBa0IsQ0FBQyxNQUFNLEdBb0JwRDs7Ozs7Ozs7Ozs7Ozs7QUN6QkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFpQztBQUNMO0FBRTVCLElBQU0sTUFBTSxHQUFpQztJQUMzQyxLQUFLLEVBQUUsU0FBUztJQUNoQixJQUFJLEVBQUUsMkNBQVc7SUFDakIsSUFBSSxFQUFFLENBQUM7SUFDUCxLQUFLLEVBQUU7UUFDTCxNQUFNLEVBQUUsTUFBTTtRQUNkLEtBQUssRUFBRSxHQUFHO1FBQ1YsTUFBTSxFQUFFLEdBQUc7UUFDWCxVQUFVLEVBQUUsNENBQVksQ0FBQyxXQUFXO1FBQ3BDLElBQUksRUFBRSw0Q0FBWSxDQUFDLEdBQUc7S0FDdkI7SUFDRCxPQUFPLEVBQUU7UUFDUCxPQUFPLEVBQUUsUUFBUTtRQUNqQixNQUFNLEVBQUU7WUFFTixPQUFPLEVBQUU7Z0JBQ1AsQ0FBQyxFQUFFLENBQUM7YUFDTDtTQUVGO0tBQ0Y7SUFNRCxLQUFLLEVBQUUsOENBQU07SUFDYixNQUFNLEVBQUUsTUFBTTtJQUNkLGVBQWUsRUFBRSxRQUFRO0NBQzFCLENBQUM7QUFFSyxJQUFNLElBQUksR0FBRyxJQUFJLDJDQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ1g7QUFDTTtBQUV2QyxJQUFNLFdBQVcsR0FBdUM7SUFDdEQsTUFBTSxFQUFFLEtBQUs7SUFDYixPQUFPLEVBQUUsS0FBSztJQUNkLEdBQUcsRUFBRSxNQUFNO0NBQ1osQ0FBQztBQUVGO0lBQStCLDZCQUFZO0lBQ3pDO2VBQ0Usa0JBQU0sV0FBVyxDQUFDO0lBQ3BCLENBQUM7SUFFTSwyQkFBTyxHQUFkO1FBQUEsaUJBc0RDO1FBbERDLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDeEMsSUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN4QyxXQUFXLENBQUMsU0FBUyxDQUFDLGtEQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNwRCxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBS2xDLFNBQXVCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUF0QyxPQUFPLGVBQUUsT0FBTyxhQUFzQjtRQUM5QyxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUNqQyxDQUFDLEVBQUUsT0FBTztZQUNWLENBQUMsRUFBRSxPQUFPO1lBQ1YsSUFBSSxFQUFFLFlBQVk7WUFDbEIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxnQkFBZ0I7Z0JBQ3RCLElBQUksRUFBRSxrREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNO2FBQzNCO1NBQ0YsQ0FBQyxDQUFDO1FBQ0gsV0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFaEMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFVBQUMsS0FBYTtZQUNyQyxXQUFXLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDcEIsV0FBVyxDQUFDLFNBQVMsQ0FBQyxrREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0MsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsR0FBRyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDbEQsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLEVBQUUsVUFBQyxJQUFVO1lBQ3RDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2hDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFO1lBSXZCLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN0QixXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEIsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3RCLEtBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzVCLENBQUMsQ0FBQyxDQUFDO1FBS0gsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUscUJBQXFCLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxvQkFBb0IsRUFBRTtZQUNuRCxVQUFVLEVBQUUsRUFBRTtZQUNkLFdBQVcsRUFBRSxFQUFFO1NBQ2hCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDSCxnQkFBQztBQUFELENBQUMsQ0E1RDhCLDRDQUFZLEdBNEQxQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRWdDO0FBQ3ljO0FBQzViO0FBRzlDLElBQU0sV0FBVyxHQUF1QztJQUN0RCxNQUFNLEVBQUUsS0FBSztJQUNiLE9BQU8sRUFBRSxLQUFLO0lBQ2QsR0FBRyxFQUFFLE1BQU07Q0FDWixDQUFDO0FBRUY7SUFBK0IsNkJBQVk7SUFvQnpDO2VBQ0Usa0JBQU0sV0FBVyxDQUFDO0lBQ3BCLENBQUM7SUFFTSx3QkFBSSxHQUFYLFVBQVksRUFFWDtZQUZhLEtBQUs7UUFHakIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDckIsQ0FBQztJQUVNLDJCQUFPLEdBQWQ7UUFDRSxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUlwQixJQUFJLENBQUMsTUFBTSxHQUFHO1lBQ1osT0FBTyxFQUFFLElBQUk7WUFDYixLQUFLLEVBQUUsR0FBRztZQUNWLGdCQUFnQixFQUFFLENBQUM7WUFDbkIsU0FBUyxFQUFFLEdBQUc7U0FDZjtRQU1ELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO1FBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBS3ZCLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxTQUFTLEdBQUcsa0RBQU8sQ0FBQztRQU16QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUt4QixJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztJQUNsQixDQUFDO0lBRU0sMEJBQU0sR0FBYjtRQUFBLGlCQThOQztRQTdOTyxTQUFlLDRDQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBM0MsS0FBSyxhQUFFLENBQUMsT0FBbUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFdEQsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTNDLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUtuRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxFQUFFLFFBQU0sSUFBSSxDQUFDLEtBQU8sRUFBRSxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ25FLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNwRSxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFNdEUsSUFBSSxDQUFDLFdBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBU2pELElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7UUFDekQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztRQU0zRCxJQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxxREFBVSxDQUFDLENBQUM7UUFDNUQsSUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsd0RBQWEsQ0FBQyxDQUFDO1FBQ3JFLElBQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMseURBQWMsQ0FBQyxDQUFDO1FBQ3ZFLElBQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsMkRBQWdCLENBQUMsQ0FBQztRQUczRSxJQUFJLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQztRQUU1QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxPQUFPLEVBQUUsZ0RBQUssQ0FBQyxDQUFDO1FBRWxHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFLckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDaEIsR0FBRyxFQUFFLFNBQVM7WUFDZCxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsRUFBRSxLQUFLLEVBQUUsZ0RBQUssRUFBRSxHQUFHLEVBQUUsa0RBQU8sRUFBRSxDQUFDO1lBQ2hGLFNBQVMsRUFBRSxFQUFFO1lBQ2IsTUFBTSxFQUFFLENBQUMsQ0FBQztTQUNYLENBQUM7UUFLRixJQUFJLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxNQUEyQixFQUFFLElBQTBCO1lBQy9HLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxLQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQyxPQUFNO2FBQ1A7WUFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLFFBQVEsRUFBRTtnQkFDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDbEM7WUFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsRUFBRTtnQkFDeEIsS0FBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7YUFDNUI7UUFDSCxDQUFDLEVBQUU7WUFDRCxPQUFPLENBQUMsS0FBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUM7UUFDMUMsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLE1BQTJCLEVBQUUsSUFBMEI7WUFDOUcsSUFBSSxLQUFJLENBQUMsTUFBTSxJQUFJLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ2xDLE9BQU8sS0FBSzthQUNiO1lBRUQsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3BCLENBQUMsRUFBRSxVQUFDLE1BQU0sRUFBRSxJQUFJO1lBQ2QsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxLQUFJLENBQUMsTUFBTSxJQUFJLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ3RELE9BQU8sS0FBSzthQUNiO1lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLG1EQUFRLEVBQUU7Z0JBQzNCLElBQUksTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUM3RCxPQUFPLElBQUk7aUJBQ1o7YUFDRjtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxxREFBVSxFQUFFO2dCQUM3QixJQUFJLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDOUQsT0FBTyxJQUFJO2lCQUNaO2FBQ0Y7WUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUsscURBQVUsRUFBRTtnQkFDN0IsSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUMvQixPQUFPLElBQUk7aUJBQ1o7YUFDRjtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxzREFBVyxFQUFFO2dCQUM5QixJQUFJLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7b0JBQ2hDLE9BQU8sSUFBSTtpQkFDWjthQUNGO1lBQ0QsT0FBTyxLQUFLO1FBQ2QsQ0FBQyxDQUFDO1FBTUYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFDLE9BQU8sRUFBRSxJQUFJOztZQUNyRSxJQUFNLE9BQU87Z0JBQ1gsR0FBQyxrREFBTyxJQUFHLFVBQUMsSUFBMEI7b0JBQ3BDLEtBQUksQ0FBQyxVQUFVLENBQUMsa0RBQU8sRUFBRSxJQUFJLENBQUM7Z0JBQ2hDLENBQUM7Z0JBQ0QsR0FBQyxxREFBVSxJQUFHLFVBQUMsSUFBMEI7b0JBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMscURBQVUsRUFBRSxJQUFJLENBQUM7Z0JBQ25DLENBQUM7Z0JBQ0QsR0FBQyxtREFBUSxJQUFHLFVBQUMsSUFBMEI7b0JBQ3JDLEtBQUksQ0FBQyxVQUFVLENBQUMsbURBQVEsRUFBRSxJQUFJLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QsR0FBQyxvREFBUyxJQUFHLFVBQUMsSUFBMEI7b0JBQ3RDLEtBQUksQ0FBQyxVQUFVLENBQUMsb0RBQVMsRUFBRSxJQUFJLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsR0FBQywwREFBZSxJQUFHLFVBQUMsSUFBMEI7b0JBQzVDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsa0RBQU8sQ0FBQyxFQUFFO3dCQUNoQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw0REFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQy9EO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw0REFBaUIsSUFBRyxVQUFDLElBQTBCO29CQUM5QyxLQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUNELEdBQUMsd0RBQWEsSUFBRyxVQUFDLElBQTBCO29CQUUxQyxJQUFNLG1CQUFtQixHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLDREQUFpQixDQUFDLENBQUM7b0JBQzdFLEtBQUksQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDckMsQ0FBQztnQkFDRCxHQUFDLDZEQUFrQixJQUFHLFVBQUMsSUFBMEI7b0JBQy9DLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMscURBQVUsQ0FBQyxFQUFFO3dCQUNuQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQywrREFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2xFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQywrREFBb0IsSUFBRyxVQUFDLElBQTBCO29CQUNqRCxLQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3BDLENBQUM7Z0JBQ0QsR0FBQywyREFBZ0IsSUFBRyxVQUFDLElBQTBCO29CQUU3QyxJQUFNLHNCQUFzQixHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLCtEQUFvQixDQUFDLENBQUM7b0JBQ25GLEtBQUksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDeEMsQ0FBQztnQkFDRCxHQUFDLDREQUFpQixJQUFHLFVBQUMsSUFBMEI7b0JBQzlDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsb0RBQVMsQ0FBQyxFQUFFO3dCQUNsQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw4REFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2pFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw4REFBbUIsSUFBRyxVQUFDLElBQTBCO29CQUNoRCxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDaEMsQ0FBQztnQkFDRCxHQUFDLDJEQUFnQixJQUFHLFVBQUMsSUFBMEI7b0JBQzdDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsbURBQVEsQ0FBQyxFQUFFO3dCQUNqQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw2REFBa0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2hFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw2REFBa0IsSUFBRyxVQUFDLElBQTBCO29CQUMvQyxLQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsR0FBQyx5REFBYyxJQUFHLFVBQUMsSUFBMEI7b0JBRTNDLElBQU0sb0JBQW9CLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsNkRBQWtCLENBQUMsQ0FBQztvQkFDL0UsS0FBSSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO21CQUNGO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFM0IsQ0FBQyxFQUFFLFVBQUMsT0FBTyxFQUFFLEVBQStCO2dCQUE3QixLQUFLO1lBQ2xCLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxLQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQyxPQUFPLEtBQUs7YUFDYjtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNoQixPQUFPLEtBQUs7YUFDYjtZQUVELElBQU0sT0FBTyxHQUFHLENBQUMsa0RBQU8sRUFBRSxxREFBVSxFQUFFLG1EQUFRLEVBQUUsb0RBQVMsRUFBRSwwREFBZSxFQUFFLDREQUFpQixFQUFFLHdEQUFhLEVBQUUsNkRBQWtCLEVBQUUsK0RBQW9CLEVBQUUsMkRBQWdCLEVBQUUsMkRBQWdCLEVBQUUsNkRBQWtCLEVBQUUseURBQWMsRUFBRSw0REFBaUIsRUFBRSw4REFBbUIsRUFBRSwwREFBZSxDQUFDLENBQUM7WUFDelIsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUNoQyxDQUFDLENBQUM7UUFLRixRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxjQUFNLFlBQUksQ0FBQyxJQUFJLEVBQUUsRUFBWCxDQUFXLENBQUMsQ0FBQztRQU12QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQU03QixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxVQUFDLElBQTBCO1lBQ3RELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxpREFBTSxFQUFFO2dCQUN6QixLQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxnREFBSyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsRCxJQUFNLE1BQU0sR0FBRyxJQUFJLG1EQUFNLENBQUMsS0FBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7Z0JBQ2xFLEtBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQzthQUMxQjtZQUFBLENBQUM7WUFDRixJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssaURBQU0sRUFBRTtnQkFDekIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZ0RBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEQsSUFBTSxNQUFNLEdBQUcsSUFBSSxtREFBTSxDQUFDLEtBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2dCQUNsRSxLQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ3pCLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ2pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDMUI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSwwQkFBTSxHQUFiO1FBQ0UsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEMsT0FBTTtTQUNQO1FBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUU7WUFDMUIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ2I7UUFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUMxRCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztZQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDN0I7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1NBRUY7YUFBTSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNqRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztZQUN2QyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN0QjtTQUNGO2FBQU07WUFDTCxJQUFJLENBQUMsVUFBVSxFQUFFO1NBQ2xCO0lBQ0gsQ0FBQztJQUVPLHdDQUFvQixHQUE1QjtRQUFBLGlCQWlCQztRQWhCQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN0QyxJQUFNLFVBQVUsR0FBRztZQUNqQjtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDMUUsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztZQUMxRSxDQUFDO1lBQ0Q7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUN6RSxDQUFDO1lBQ0Q7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQzFFLENBQUM7U0FDRjtRQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8saUNBQWEsR0FBckI7UUFBQSxpQkFpQkM7UUFoQkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3JDLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxRSxDQUFDO1lBQ0Q7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFFLENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzRSxDQUFDO1lBQ0Q7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0UsQ0FBQztTQUNGO1FBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyw4QkFBVSxHQUFsQjtRQUFBLGlCQWlCQztRQWhCQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUN6QixJQUFNLFVBQVUsR0FBRztZQUNqQjtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzFELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzFELENBQUM7U0FDRjtRQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8sd0JBQUksR0FBWjtRQUFBLGlCQXdCQztRQXZCQyxJQUFNLFVBQVUsR0FBRztZQUNqQjtnQkFDRSxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7b0JBQ2pDLEtBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDbEQ7WUFDSCxDQUFDO1lBQ0Q7Z0JBQ0UsSUFBSSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFO29CQUNqQyxLQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNqRDtZQUNILENBQUM7WUFDRDtnQkFDRSxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUU7b0JBQy9CLEtBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2pEO1lBQ0gsQ0FBQztZQUNEO2dCQUNFLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRTtvQkFDbEMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNsRDtZQUNILENBQUM7U0FDRjtRQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8saUNBQWEsR0FBckIsVUFBc0IsRUFBaUIsRUFBRSxFQUFnQjtRQUF6RCxpQkErREM7UUEvRHVCLFNBQUssYUFBSyxJQUFJLGNBQWhCLFNBQWlCLENBQUQ7UUFBSSxLQUFDLFNBQUUsQ0FBQyxTQUFJLE1BQU0sY0FBZixVQUFnQixDQUFEO1FBQ3RELElBQUksSUFBSSxDQUFDLFFBQVE7WUFBRSxPQUFPO1FBRTFCLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLElBQUksS0FBSyxLQUFLLG9EQUFTLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQzlFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDckM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssbURBQVEsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUN4RSxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssZ0RBQUssRUFBRTtvQkFDbkIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDN0I7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssK0NBQUksRUFBRTtvQkFDbEIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM5QjtZQUNILENBQUM7WUFDRDtnQkFDRSxJQUFJLEtBQUssS0FBSyx1REFBWSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNqRixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDakM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssb0RBQVMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUN6RSxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssaURBQU0sRUFBRTtvQkFDcEIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDN0I7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssOENBQUcsRUFBRTtvQkFDakIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM5QjtZQUNILENBQUM7WUFDRDtnQkFDRSxJQUFJLEtBQUssS0FBSyxzREFBVyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQzNFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDckM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssdURBQVksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDakYsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDbEM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssZ0RBQUssRUFBRTtvQkFDbkIsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM5QjtnQkFDRCxJQUFJLEtBQUssS0FBSywrQ0FBSSxFQUFFO29CQUNsQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM3QjtZQUNILENBQUM7WUFDRDtnQkFDRSxJQUFJLEtBQUssS0FBSyxtREFBUSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3hFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2lCQUN0QztnQkFDRCxJQUFJLEtBQUssS0FBSyxzREFBVyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNoRixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7aUJBQ25DO2dCQUNELElBQUksS0FBSyxLQUFLLGlEQUFNLElBQUksQ0FBQyxLQUFJLENBQUMsUUFBUSxFQUFFO29CQUN0QyxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzlCO2dCQUNELElBQUksS0FBSyxLQUFLLDhDQUFHLElBQUksQ0FBQyxLQUFJLENBQUMsUUFBUSxFQUFFO29CQUNuQyxLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM3QjtZQUNILENBQUM7U0FDRjtRQUVELFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU8sa0NBQWMsR0FBdEIsVUFBdUIsS0FBYSxFQUFFLENBQVMsRUFBRSxDQUFTO1FBQTFELGlCQWlCQztRQWhCQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1lBQ2QsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUN0QixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLEtBQUs7WUFDckMsQ0FBQztZQUNELENBQUM7WUFDRCxRQUFRLEVBQUUsR0FBRztZQUNiLFVBQVUsRUFBRTtnQkFDVixLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDdEIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QyxLQUFJLENBQUMsU0FBUyxHQUFHLDJDQUFXLENBQUMsSUFBSSxDQUFDLEtBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQW1CLENBQUU7Z0JBQ25GLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixDQUFDO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFTyw4QkFBVSxHQUFsQjtRQUFBLGlCQWdCQztRQWZDLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ2xELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2xELENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUNqRCxDQUFDO1NBQ0Y7UUFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVNLHdCQUFJLEdBQVg7UUFDRSxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDZixPQUFNO1NBQ1A7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDdkIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsRUFBRTtnQkFDaEQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBQy9CO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQzthQUMvQjtZQUNELElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUNyQyxJQUFNLFVBQVUsR0FBeUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUMzQyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVM7U0FDakM7SUFDSCxDQUFDO0lBRU8sNEJBQVEsR0FBaEIsVUFBaUIsSUFBMEIsRUFBRSxRQUErQyxFQUFFLFNBQWdEO1FBQTlJLGlCQXVDQztRQXRDQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDeEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDZCxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3RCLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsQ0FBQztnQkFDUCxFQUFFLEVBQUUsQ0FBQzthQUNOO1lBQ0QsUUFBUSxFQUFFLEdBQUc7WUFDYixVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxRQUFRLElBQUksT0FBTyxRQUFRLEtBQUssVUFBVSxFQUFFO29CQUM5QyxRQUFRLENBQUMsSUFBSSxDQUFDO2lCQUNmO2dCQUNELEtBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDckIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7b0JBQ2QsT0FBTyxFQUFFLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQztvQkFDdEIsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQztvQkFDbEIsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQztvQkFDbEIsVUFBVSxFQUFFO3dCQUNWLEtBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDOzRCQUNkLE9BQU8sRUFBRSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUM7NEJBQ3RCLEtBQUssRUFBRTtnQ0FDTCxJQUFJLEVBQUUsQ0FBQztnQ0FDUCxFQUFFLEVBQUUsQ0FBQzs2QkFDTjs0QkFDRCxVQUFVLEVBQUU7Z0NBQ1YsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUN2QyxLQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztnQ0FDeEIsS0FBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0NBQ3ZCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxLQUFLLFVBQVUsRUFBRTtvQ0FDaEQsU0FBUyxDQUFDLElBQUksQ0FBQztpQ0FDaEI7NEJBQ0gsQ0FBQzt5QkFDRixDQUFDLENBQUM7b0JBQ0wsQ0FBQztpQkFDRixDQUFDO1lBQ0osQ0FBQztTQUNGLENBQUM7SUFDSixDQUFDO0lBRU8sOEJBQVUsR0FBbEIsVUFBbUIsSUFBWSxFQUFFLElBQTBCO1FBQ3pELElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLGdEQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQztRQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDckIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDekIsQ0FBQztJQUVPLDBCQUFNLEdBQWQ7UUFBQSxpQkFVQztRQVRDLElBQUksQ0FBQyxRQUFRLENBQ1gsSUFBSSxDQUFDLFVBQVUsRUFDZixVQUFDLElBQTBCO1lBQ3pCLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdEQUFLLENBQUMsQ0FBQztRQUM5QixDQUFDLEVBQ0QsVUFBQyxJQUEwQjtZQUN6QixLQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUN0QixDQUFDLENBQ0Y7SUFDSCxDQUFDO0lBRU8saUNBQWEsR0FBckI7UUFDRSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNuQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFDdkIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDNUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVNLDhCQUFVLEdBQWpCO1FBQ0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtRQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQywrQ0FBSSxDQUFDO1FBQzFCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSTtRQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDO0lBQ3BELENBQUM7SUFDSCxnQkFBQztBQUFELENBQUMsQ0F4bEI4Qiw0Q0FBWSxHQXdsQjFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbm1CZ0M7QUFDRjtBQUNPO0FBQ0s7QUFFM0MsSUFBTSxTQUFTLEdBQUc7SUFDaEIsSUFBSSxFQUFFLGlEQUFPLENBQUMsTUFBTSxDQUFDLE1BQU07SUFDM0IsVUFBVSxFQUFFLFdBQVc7SUFDdkIsS0FBSyxFQUFFLFFBQVE7Q0FDaEI7QUFDRCxJQUFNLFdBQVcsR0FBdUM7SUFDdEQsTUFBTSxFQUFFLEtBQUs7SUFDYixPQUFPLEVBQUUsS0FBSztJQUNkLEdBQUcsRUFBRSxLQUFLO0NBQ1gsQ0FBQztBQUVGO0lBQThCLDRCQUFZO0lBYXhDO2VBQ0Usa0JBQU0sV0FBVyxDQUFDO0lBQ3BCLENBQUM7SUFFTSx1QkFBSSxHQUFYLFVBQVksRUFFWDtZQUZhLEtBQUs7UUFHakIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDakIsQ0FBQztJQUtNLHlCQUFNLEdBQWI7UUFBQSxpQkFvRkM7UUFuRlMsU0FBSyxHQUFLLDRDQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsTUFBbkMsQ0FBb0M7UUFDakQsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRW5ELElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRTtRQUNmLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsUUFBTSxJQUFJLENBQUMsS0FBTyxFQUFFLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9DLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1lBQ3BDLFNBQVMsRUFBRTtnQkFDVCxLQUFLLEVBQUUsR0FBRztnQkFDVixLQUFLLEVBQUUsaURBQU8sQ0FBQyxLQUFLLENBQUMsTUFBTTthQUM1QjtTQUNGLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEIsSUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7WUFDckMsU0FBUyxFQUFFO2dCQUNULEtBQUssRUFBRSxpREFBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNO2FBQzdCO1NBQ0YsQ0FBQztRQUNGLElBQU0sS0FBSyxHQUFHLElBQUksMkNBQVcsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO1FBQ3pELFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxPQUFPLEVBQUUsU0FBUyxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsU0FBUyxDQUFDO1FBRXJELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxtQkFBbUIsd0JBQzNELFNBQVMsS0FDWixJQUFJLEVBQUUsaURBQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUMxQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxnQ0FBZ0Msd0JBQ3ZFLFNBQVMsS0FDWixJQUFJLEVBQUUsaURBQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxJQUMxQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxtREFBTSxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLHlCQUF5QixFQUFFO1lBQzNFLElBQUksRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNO1lBQzFCLFVBQVUsRUFBRSxXQUFXO1lBQ3ZCLEtBQUssRUFBRSxRQUFRO1NBQ2hCLEVBQUU7WUFDRCxTQUFTLEVBQUUsY0FBTSxZQUFJLENBQUMsU0FBUyxFQUFFLEVBQWhCLENBQWdCO1NBQ2xDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEIsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7UUFDekQsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDakMsSUFBTSxXQUFXLEdBQUc7WUFDbEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDdEQ7UUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxVQUFDLElBQVk7WUFDdEQsSUFBTSxLQUFLLEdBQUcsS0FBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDaEMsS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3JCLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN2QyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsV0FBVyxFQUFFO1lBQzVDLHlDQUFTLENBQUMsY0FBYyxFQUFFLEtBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1lBQ3pDLEtBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDMUIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDL0IsSUFBSSxLQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsRUFBRTtnQkFDcEIsS0FBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSSxDQUFDLFlBQVksQ0FBQzthQUNyQztpQkFBTTtnQkFDTCxLQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7YUFDekM7UUFHSCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtnQkFDNUQsS0FBSSxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUM7Z0JBQ2hCLEtBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQUksS0FBSSxDQUFDLEtBQU8sQ0FBQztZQUN6QyxDQUFDLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUV0QyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxjQUFNLFlBQUksQ0FBQyxTQUFTLEVBQUUsRUFBaEIsQ0FBZ0IsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFTyw0QkFBUyxHQUFqQjtRQUNFLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQzdCLElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUN4QyxTQUFTLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQyxTQUFTLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM3QyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEtBQUssU0FBRSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxTQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVILGVBQUM7QUFBRCxDQUFDLENBMUg2Qiw0Q0FBWSxHQTBIekM7Ozs7Ozs7Ozs7Ozs7O0FDMUlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBbUM7QUFDQTtBQUNGO0FBQ0k7QUFFdEI7SUFDYiwrQ0FBUztJQUNULCtDQUFTO0lBQ1QsNkNBQVE7SUFDUixpREFBVTtDQUNYLEVBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1YrQjtBQUNGO0FBQzBCO0FBRXpELElBQU0sV0FBVyxHQUF1QztJQUN0RCxNQUFNLEVBQUUsS0FBSztJQUNiLE9BQU8sRUFBRSxLQUFLO0lBQ2QsR0FBRyxFQUFFLE9BQU87Q0FDYixDQUFDO0FBRUY7SUFBZ0MsOEJBQVk7SUFVMUM7ZUFDRSxrQkFBTSxXQUFXLENBQUM7SUFDcEIsQ0FBQztJQUVNLDJCQUFNLEdBQWI7UUFBQSxpQkF1Q0M7UUF0Q1MsU0FBSyxHQUFLLDRDQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsTUFBbkMsQ0FBb0M7UUFDakQsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ25ELElBQU0sWUFBWSxHQUFHLHlDQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3BELElBQUksQ0FBQyxRQUFRLEdBQUcsWUFBWSxDQUFDO1FBQzdCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN0RCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUV0RSxJQUFNLFVBQVUsR0FBZ0MsRUFBRTtRQUNsRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNCLElBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLDhDQUFJLEdBQUcsQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxJQUFJLFlBQVksRUFBRTtnQkFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsK0NBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwRDtZQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ3RCO1FBQ0QsSUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsZ0RBQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFFbkcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTdCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUU7WUFDM0IsS0FBSSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUN2RSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNwRCxDQUFDLENBQUM7UUFDRixJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFO1lBQzVCLEtBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFFBQVEsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFDdkUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7UUFDcEQsQ0FBQyxDQUFDO1FBRUYsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUU7WUFDbEIsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLDhCQUFTLEdBQWpCLFVBQWtCLEtBQWE7UUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLEVBQUUsS0FBSyxTQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLEVBQUUsS0FBSyxTQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUN2RSxDQUFDO0lBQ0gsaUJBQUM7QUFBRCxDQUFDLENBMUQrQiw0Q0FBWSxHQTBEM0MiLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG4gXHRmdW5jdGlvbiB3ZWJwYWNrSnNvbnBDYWxsYmFjayhkYXRhKSB7XG4gXHRcdHZhciBjaHVua0lkcyA9IGRhdGFbMF07XG4gXHRcdHZhciBtb3JlTW9kdWxlcyA9IGRhdGFbMV07XG4gXHRcdHZhciBleGVjdXRlTW9kdWxlcyA9IGRhdGFbMl07XG5cbiBcdFx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG4gXHRcdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuIFx0XHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwLCByZXNvbHZlcyA9IFtdO1xuIFx0XHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuIFx0XHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcbiBcdFx0XHRpZihPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoaW5zdGFsbGVkQ2h1bmtzLCBjaHVua0lkKSAmJiBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcbiBcdFx0XHRcdHJlc29sdmVzLnB1c2goaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdWzBdKTtcbiBcdFx0XHR9XG4gXHRcdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMDtcbiBcdFx0fVxuIFx0XHRmb3IobW9kdWxlSWQgaW4gbW9yZU1vZHVsZXMpIHtcbiBcdFx0XHRpZihPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobW9yZU1vZHVsZXMsIG1vZHVsZUlkKSkge1xuIFx0XHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0gPSBtb3JlTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdFx0fVxuIFx0XHR9XG4gXHRcdGlmKHBhcmVudEpzb25wRnVuY3Rpb24pIHBhcmVudEpzb25wRnVuY3Rpb24oZGF0YSk7XG5cbiBcdFx0d2hpbGUocmVzb2x2ZXMubGVuZ3RoKSB7XG4gXHRcdFx0cmVzb2x2ZXMuc2hpZnQoKSgpO1xuIFx0XHR9XG5cbiBcdFx0Ly8gYWRkIGVudHJ5IG1vZHVsZXMgZnJvbSBsb2FkZWQgY2h1bmsgdG8gZGVmZXJyZWQgbGlzdFxuIFx0XHRkZWZlcnJlZE1vZHVsZXMucHVzaC5hcHBseShkZWZlcnJlZE1vZHVsZXMsIGV4ZWN1dGVNb2R1bGVzIHx8IFtdKTtcblxuIFx0XHQvLyBydW4gZGVmZXJyZWQgbW9kdWxlcyB3aGVuIGFsbCBjaHVua3MgcmVhZHlcbiBcdFx0cmV0dXJuIGNoZWNrRGVmZXJyZWRNb2R1bGVzKCk7XG4gXHR9O1xuIFx0ZnVuY3Rpb24gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKSB7XG4gXHRcdHZhciByZXN1bHQ7XG4gXHRcdGZvcih2YXIgaSA9IDA7IGkgPCBkZWZlcnJlZE1vZHVsZXMubGVuZ3RoOyBpKyspIHtcbiBcdFx0XHR2YXIgZGVmZXJyZWRNb2R1bGUgPSBkZWZlcnJlZE1vZHVsZXNbaV07XG4gXHRcdFx0dmFyIGZ1bGZpbGxlZCA9IHRydWU7XG4gXHRcdFx0Zm9yKHZhciBqID0gMTsgaiA8IGRlZmVycmVkTW9kdWxlLmxlbmd0aDsgaisrKSB7XG4gXHRcdFx0XHR2YXIgZGVwSWQgPSBkZWZlcnJlZE1vZHVsZVtqXTtcbiBcdFx0XHRcdGlmKGluc3RhbGxlZENodW5rc1tkZXBJZF0gIT09IDApIGZ1bGZpbGxlZCA9IGZhbHNlO1xuIFx0XHRcdH1cbiBcdFx0XHRpZihmdWxmaWxsZWQpIHtcbiBcdFx0XHRcdGRlZmVycmVkTW9kdWxlcy5zcGxpY2UoaS0tLCAxKTtcbiBcdFx0XHRcdHJlc3VsdCA9IF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gZGVmZXJyZWRNb2R1bGVbMF0pO1xuIFx0XHRcdH1cbiBcdFx0fVxuXG4gXHRcdHJldHVybiByZXN1bHQ7XG4gXHR9XG5cbiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4gXHQvLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbiBcdC8vIFByb21pc2UgPSBjaHVuayBsb2FkaW5nLCAwID0gY2h1bmsgbG9hZGVkXG4gXHR2YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuIFx0XHRcIm1haW5cIjogMFxuIFx0fTtcblxuIFx0dmFyIGRlZmVycmVkTW9kdWxlcyA9IFtdO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG4gXHR2YXIganNvbnBBcnJheSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSA9IHdpbmRvd1tcIndlYnBhY2tKc29ucFwiXSB8fCBbXTtcbiBcdHZhciBvbGRKc29ucEZ1bmN0aW9uID0ganNvbnBBcnJheS5wdXNoLmJpbmQoanNvbnBBcnJheSk7XG4gXHRqc29ucEFycmF5LnB1c2ggPSB3ZWJwYWNrSnNvbnBDYWxsYmFjaztcbiBcdGpzb25wQXJyYXkgPSBqc29ucEFycmF5LnNsaWNlKCk7XG4gXHRmb3IodmFyIGkgPSAwOyBpIDwganNvbnBBcnJheS5sZW5ndGg7IGkrKykgd2VicGFja0pzb25wQ2FsbGJhY2soanNvbnBBcnJheVtpXSk7XG4gXHR2YXIgcGFyZW50SnNvbnBGdW5jdGlvbiA9IG9sZEpzb25wRnVuY3Rpb247XG5cblxuIFx0Ly8gYWRkIGVudHJ5IG1vZHVsZSB0byBkZWZlcnJlZCBsaXN0XG4gXHRkZWZlcnJlZE1vZHVsZXMucHVzaChbXCIuL3NyYy9pbmRleC50c1wiLFwidmVuZG9yc1wiXSk7XG4gXHQvLyBydW4gZGVmZXJyZWQgbW9kdWxlcyB3aGVuIHJlYWR5XG4gXHRyZXR1cm4gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKTtcbiIsImV4cG9ydCBjb25zdCBDT0xPVVJTID0ge1xuICB3aGl0ZToge1xuICAgIHN0cmluZzogJyNDRkM2QjgnLFxuICAgIG51bWJlcjogMHhDRkM2QjhcbiAgfSxcbiAgZGFya0dyYXk6IHtcbiAgICBzdHJpbmc6ICcjMDAwMDAwJyxcbiAgICBudW1iZXI6IDB4MDAwMDAwLFxuICB9LFxuICBtYXJvb246IHtcbiAgICBzdHJpbmc6ICcjNGIyYTNjJyxcbiAgICBudW1iZXI6IDB4NEIyQTNDLFxuICB9LFxuICBncmVlbjoge1xuICAgIHN0cmluZzogJyMzOEQ5NzMnLFxuICAgIG51bWJlcjogMHgzOEQ5NzMsXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IFNJREVfVVAgPSAwO1xuZXhwb3J0IGNvbnN0IFNJREVfUklHSFQgPSAxO1xuZXhwb3J0IGNvbnN0IFNJREVfRE9XTiA9IDI7XG5leHBvcnQgY29uc3QgU0lERV9MRUZUID0gM1xuXG5leHBvcnQgY29uc3QgREVBRCA9IDQwNztcbmV4cG9ydCBjb25zdCBBTElWRSA9IDQwMjtcbmV4cG9ydCBjb25zdCBSVU5fRU5EID0gNDA2O1xuXG5leHBvcnQgY29uc3QgVE9QX0xFRlQgPSAxOTtcbmV4cG9ydCBjb25zdCBUT1AgPSAyMDtcbmV4cG9ydCBjb25zdCBUT1BfUklHSFQgPSAyMTtcbmV4cG9ydCBjb25zdCBMRUZUID0gNjc7XG5leHBvcnQgY29uc3QgUklHSFQgPSA2OTtcbmV4cG9ydCBjb25zdCBCT1RUT01fTEVGVCA9IDExNTtcbmV4cG9ydCBjb25zdCBCT1RUT00gPSAxMTY7XG5leHBvcnQgY29uc3QgQk9UVE9NX1JJR0hUID0gMTE3O1xuXG5leHBvcnQgY29uc3QgU1RBUlRfRE9PUiA9IDQ4OTtcblxuZXhwb3J0IGNvbnN0IFVQX1NQSUtFID0gMjM7XG5leHBvcnQgY29uc3QgRE9XTl9TUElLRSA9IDI1O1xuZXhwb3J0IGNvbnN0IExFRlRfU1BJS0UgPSA3NDtcbmV4cG9ydCBjb25zdCBSSUdIVF9TUElLRSA9IDczO1xuZXhwb3J0IGNvbnN0IFdJWkFSRCA9IDgwO1xuZXhwb3J0IGNvbnN0IFNQSURFUiA9IDI2OTtcbmV4cG9ydCBjb25zdCBTUEVMTCA9IDU1NztcblxuZXhwb3J0IGNvbnN0IEJMQU5LID0gMDtcbmV4cG9ydCBjb25zdCBZRUxMT1dfS0VZID0gNTYxO1xuZXhwb3J0IGNvbnN0IEJMVUVfS0VZID0gNTYyO1xuZXhwb3J0IGNvbnN0IFJFRF9LRVkgPSA1NjM7XG5leHBvcnQgY29uc3QgR1JFRU5fS0VZID0gNTY0O1xuZXhwb3J0IGNvbnN0IEJMVUVfRE9PUl9MT0NLRUQgPSA0MzM7XG5leHBvcnQgY29uc3QgQkxVRV9ET09SX0VYSVQgPSA0MzQ7XG5leHBvcnQgY29uc3QgQkxVRV9ET09SX0VOVFJBTkNFID0gNDM1O1xuZXhwb3J0IGNvbnN0IFlFTExPV19ET09SX0xPQ0tFRCA9IDQzNjtcbmV4cG9ydCBjb25zdCBZRUxMT1dfRE9PUl9FWElUID0gNDM3O1xuZXhwb3J0IGNvbnN0IFlFTExPV19ET09SX0VOVFJBTkNFID0gNDM4O1xuZXhwb3J0IGNvbnN0IFJFRF9ET09SX0xPQ0tFRCA9IDQzOTtcbmV4cG9ydCBjb25zdCBSRURfRE9PUl9FWElUID0gNDQwO1xuZXhwb3J0IGNvbnN0IFJFRF9ET09SX0VOVFJBTkNFID0gNDQxO1xuZXhwb3J0IGNvbnN0IEdSRUVOX0RPT1JfTE9DS0VEID0gNDQyO1xuZXhwb3J0IGNvbnN0IEdSRUVOX0RPT1JfRVhJVCA9IDQ0MztcbmV4cG9ydCBjb25zdCBHUkVFTl9ET09SX0VOVFJBTkNFID0gNDQ0O1xuXG5leHBvcnQgY29uc3QgQ1VSU09SID0gNzEzO1xuZXhwb3J0IGNvbnN0IFpFUk8gPSA4NTI7XG5cblxuIiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgeyBDT0xPVVJTIH0gZnJvbSAnY29uc3RhbnRzJztcblxuZXhwb3J0IGNsYXNzIEJ1dHRvbiBleHRlbmRzIFBoYXNlci5HYW1lT2JqZWN0cy5UZXh0IHtcbiAgY29uc3RydWN0b3IoXG4gICAgc2NlbmU6IFBoYXNlci5TY2VuZSxcbiAgICB4OiBudW1iZXIsXG4gICAgeTogbnVtYmVyLFxuICAgIHRleHQ6IHN0cmluZyxcbiAgICBzdHlsZToge30sXG4gICAgY2FsbGJhY2tzOiB7XG4gICAgICBba2V5OiBzdHJpbmddOiAoKSA9PiB2b2lkO1xuICAgIH0sXG4gICkge1xuICAgIHN1cGVyKHNjZW5lLCB4LCB5LCB0ZXh0LCBzdHlsZSk7XG4gICAgdGhpcy5kZWZhdWx0U3R5bGUgPSBzdHlsZTtcbiAgICB0aGlzLnNldEludGVyYWN0aXZlKHsgdXNlSGFuZEN1cnNvcjogdHJ1ZSB9KVxuICAgIC5vbigncG9pbnRlcm92ZXInLCAoKSA9PiB7XG4gICAgICB0aGlzLmJ1dHRvbk92ZXIoKTtcbiAgICAgIGlmIChjYWxsYmFja3MgJiYgdHlwZW9mIGNhbGxiYWNrcy5wb2ludGVyb3ZlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjYWxsYmFja3MucG9pbnRlcm92ZXIoKTtcbiAgICAgIH1cbiAgICB9KVxuICAgIC5vbigncG9pbnRlcm91dCcsICgpID0+IHtcbiAgICAgIHRoaXMuYnV0dG9uT3V0KCk7XG4gICAgICBpZiAoY2FsbGJhY2tzICYmIHR5cGVvZiBjYWxsYmFja3MucG9pbnRlcm91dCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjYWxsYmFja3MucG9pbnRlcm91dCgpO1xuICAgICAgfVxuICAgIH0pXG4gICAgLm9uKCdwb2ludGVyZG93bicsICgpID0+IHtcbiAgICAgIHRoaXMuYnV0dG9uRG93bigpO1xuICAgICAgaWYgKGNhbGxiYWNrcyAmJiB0eXBlb2YgY2FsbGJhY2tzLnBvaW50ZXJkb3duID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wb2ludGVyZG93bigpO1xuICAgICAgfVxuICAgIH0pXG4gICAgLm9uKCdwb2ludGVydXAnLCAoKSA9PiB7XG4gICAgICBpZiAoY2FsbGJhY2tzICYmIHR5cGVvZiBjYWxsYmFja3MucG9pbnRlcnVwID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wb2ludGVydXAoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBidXR0b25PdmVyKCkge1xuICAgIHRoaXMuc2V0U3R5bGUoe1xuICAgICAgZmlsbDogQ09MT1VSUy5ncmVlbi5zdHJpbmcsXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgYnV0dG9uT3V0KCkge1xuICAgIHRoaXMuc2V0U3R5bGUodGhpcy5kZWZhdWx0U3R5bGUpO1xuICB9XG5cbiAgcHVibGljIGJ1dHRvbkRvd24oKSB7XG4gICAgdGhpcy5zZXRTdHlsZSh7XG4gICAgICBmaWxsOiBDT0xPVVJTLmdyZWVuLnN0cmluZyxcbiAgICB9KTtcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJ1dHRvbiB7XG4gIGRlZmF1bHRTdHlsZToge307XG59IiwiZXhwb3J0ICogZnJvbSAnLi9idXR0b24nXG5leHBvcnQgKiBmcm9tICcuL3dpemFyZCdcbmV4cG9ydCAqIGZyb20gJy4vc3BlbGwnXG5leHBvcnQgKiBmcm9tICcuL3NwaWRlciciLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCB7IFNQRUxMIH0gZnJvbSAnY29uc3RhbnRzJztcbmltcG9ydCB7IEdhbWVTY2VuZSB9IGZyb20gJ3NyYy9zY2VuZXMvZ2FtZSc7XG5cbmV4cG9ydCBjbGFzcyBTcGVsbCBleHRlbmRzIFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGUge1xuICBjb25zdHJ1Y3RvcihcbiAgICBzY2VuZTogR2FtZVNjZW5lLFxuICAgIHg6IG51bWJlcixcbiAgICB5OiBudW1iZXIsXG4gICAgdGV4dHVyZTogc3RyaW5nXG4gICkge1xuICAgIHN1cGVyKHNjZW5lLCB4LCB5LCB0ZXh0dXJlLCBTUEVMTCk7XG4gICAgdGhpcy5zZXRPcmlnaW4oMCwgMClcbiAgICBjb25zdCBhbmdsZSA9IFBoYXNlci5NYXRoLkFuZ2xlLkJldHdlZW4odGhpcy54LCB0aGlzLnksIHNjZW5lLnBsYXllci54LCBzY2VuZS5wbGF5ZXIueSlcbiAgICAvLyBhZGQgNDUgZGVncmVlcyB0byBvZmZzZXQgdGhlIHNwcml0ZVxuICAgIHRoaXMuc2V0Um90YXRpb24oYW5nbGUgLSAzLjkyNjk5KVxuICAgIFxuICAgIHNjZW5lLnBoeXNpY3MuYWRkLm92ZXJsYXAodGhpcywgc2NlbmUucGxheWVyLCAoc3BlbGw6IFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGUsIHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICBpZiAoc2NlbmUuaXNEZWFkIHx8IHNjZW5lLnJlbG9jYXRpbmcpIHJldHVybjtcbiAgICAgIHNjZW5lLmtpbGxQbGF5ZXIoKVxuICAgIH0pXG4gICAgXG4gICAgc2NlbmUucGh5c2ljcy5hZGQuY29sbGlkZXIodGhpcywgc2NlbmUuZ3JvdW5kTGF5ZXIsIChzcGVsbDogUGhhc2VyLlBoeXNpY3MuQXJjYWRlLlNwcml0ZSwgdGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgIHNwZWxsLmRlc3Ryb3koKTtcbiAgICB9KVxuICB9XG4gIFxufSIsImltcG9ydCAqIGFzIFBoYXNlciBmcm9tICdwaGFzZXInO1xuaW1wb3J0IHsgU1BJREVSIH0gZnJvbSAnY29uc3RhbnRzJztcbmltcG9ydCB7IEdhbWVTY2VuZSB9IGZyb20gJ3NyYy9zY2VuZXMvZ2FtZSc7XG5cbmV4cG9ydCBjbGFzcyBTcGlkZXIgZXh0ZW5kcyBQaGFzZXIuUGh5c2ljcy5BcmNhZGUuU3ByaXRlIHtcbiAgZGlyZWN0aW9uOiAwIHwgMSB8IDIgfCAzO1xuICBjb25zdHJ1Y3RvcihcbiAgICBzY2VuZTogR2FtZVNjZW5lLFxuICAgIHg6IG51bWJlcixcbiAgICB5OiBudW1iZXIsXG4gICAgdGV4dHVyZTogc3RyaW5nXG4gICkge1xuICAgIHN1cGVyKHNjZW5lLCB4LCB5LCB0ZXh0dXJlLCBTUElERVIgLSAxKTtcbiAgICB0aGlzLmRpcmVjdGlvbiA9IDI7XG4gICAgdGhpcy5zZXRPcmlnaW4oMC41LCAwLjUpO1xuXG4gICAgc2NlbmUucGh5c2ljcy5hZGQuY29sbGlkZXIodGhpcywgc2NlbmUuZ3JvdW5kTGF5ZXIsIChzcGlkZXI6IFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGUsIHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICB0aGlzLmRpcmVjdGlvbiA9IFBoYXNlci5NYXRoLldyYXAodGhpcy5kaXJlY3Rpb24gKyAxLCAwLCA0KSAgYXMgMCB8IDEgfCAyIHwgMyA7XG4gICAgICBzcGlkZXIuc2V0QW5nbGUoc3BpZGVyLmFuZ2xlICsgOTApO1xuICAgICAgY29uc3QgZGlyZWN0aW9ucyA9IFtcbiAgICAgICAgKCkgPT4gc3BpZGVyLnNldFZlbG9jaXR5KDAsIC0xMDApLFxuICAgICAgICAoKSA9PiBzcGlkZXIuc2V0VmVsb2NpdHkoMTAwLCAwKSxcbiAgICAgICAgKCkgPT4gc3BpZGVyLnNldFZlbG9jaXR5KDAsIDEwMCksXG4gICAgICAgICgpID0+IHNwaWRlci5zZXRWZWxvY2l0eSgtMTAwLCAwKSxcbiAgICAgIF1cbiAgICAgIGRpcmVjdGlvbnNbdGhpcy5kaXJlY3Rpb25dKClcbiAgICB9KVxuICAgIFxuICAgIHNjZW5lLnBoeXNpY3MuYWRkLm92ZXJsYXAodGhpcywgc2NlbmUucGxheWVyLCAoc3BpZGVyOiBQaGFzZXIuUGh5c2ljcy5BcmNhZGUuU3ByaXRlLCB0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgaWYgKHNjZW5lLmlzRGVhZCB8fCBzY2VuZS5yZWxvY2F0aW5nKSByZXR1cm47XG4gICAgICBzY2VuZS5raWxsUGxheWVyKClcbiAgICB9KVxuICB9XG59IiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgeyBXSVpBUkQgfSBmcm9tICdjb25zdGFudHMnO1xuaW1wb3J0IHsgU3BlbGwgfSBmcm9tICcuL3NwZWxsJztcbmltcG9ydCB7IEdhbWVTY2VuZSB9IGZyb20gJ3NyYy9zY2VuZXMvZ2FtZSc7XG5cbmV4cG9ydCBjbGFzcyBXaXphcmQgZXh0ZW5kcyBQaGFzZXIuR2FtZU9iamVjdHMuU3ByaXRlIHtcbiAgc2hvb3RpbmdUaW1lcjogUGhhc2VyLlRpbWUuVGltZXJFdmVudDtcbiAgY29uc3RydWN0b3IoXG4gICAgc2NlbmU6IEdhbWVTY2VuZSxcbiAgICB4OiBudW1iZXIsXG4gICAgeTogbnVtYmVyLFxuICAgIHRleHR1cmU6IHN0cmluZ1xuICApIHtcbiAgICBzdXBlcihzY2VuZSwgeCwgeSwgdGV4dHVyZSwgV0laQVJEIC0gMSk7XG4gICAgdGhpcy5zZXRPcmlnaW4oMCwgMCk7XG4gICAgdGhpcy5zaG9vdGluZ1RpbWVyID0gc2NlbmUudGltZS5hZGRFdmVudCh7IGRlbGF5OiAxMDAwLCBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgaWYgKHNjZW5lLmlzRGVhZCB8fCBzY2VuZS5yZWxvY2F0aW5nKSByZXR1cm5cbiAgICAgIGNvbnN0IHNwZWxsID0gbmV3IFNwZWxsKHNjZW5lLCB4LCB5LCB0ZXh0dXJlKTtcbiAgICAgIHNjZW5lLmFkZC5leGlzdGluZyhzcGVsbCk7XG4gICAgICBzY2VuZS5waHlzaWNzLmFkZC5leGlzdGluZyhzcGVsbCk7XG4gICAgICBzY2VuZS5waHlzaWNzLm1vdmVUb09iamVjdChzcGVsbCwgc2NlbmUucGxheWVyKVxuICAgICAgc3BlbGwuYm9keS5zZXRTaXplKDIsIDIsIHRydWUpXG4gICAgICAvLyBzcGVsbC5zZXRWZWxvY2l0eVgoLTEwMCk7XG4gICAgfSwgY2FsbGJhY2tTY29wZTogdGhpcywgbG9vcDogdHJ1ZSB9KTtcbiAgfVxufSIsImltcG9ydCAqIGFzIFBoYXNlciBmcm9tICdwaGFzZXInO1xuaW1wb3J0IFNjZW5lcyBmcm9tICdzY2VuZXMnO1xuXG5jb25zdCBjb25maWc6IFBoYXNlci5UeXBlcy5Db3JlLkdhbWVDb25maWcgPSB7XG4gIHRpdGxlOiAnTWl6IGphbScsXG4gIHR5cGU6IFBoYXNlci5BVVRPLFxuICB6b29tOiAyLFxuICBzY2FsZToge1xuICAgIHBhcmVudDogJ2dhbWUnLFxuICAgIHdpZHRoOiA4MDAsXG4gICAgaGVpZ2h0OiA2MDAsXG4gICAgYXV0b0NlbnRlcjogUGhhc2VyLlNjYWxlLkNFTlRFUl9CT1RILFxuICAgIG1vZGU6IFBoYXNlci5TY2FsZS5GSVQsXG4gIH0sXG4gIHBoeXNpY3M6IHtcbiAgICBkZWZhdWx0OiAnYXJjYWRlJyxcbiAgICBhcmNhZGU6IHtcbiAgICAgIC8vIHRpbWVTY2FsZTogNCxcbiAgICAgIGdyYXZpdHk6IHtcbiAgICAgICAgeTogMFxuICAgICAgfSxcbiAgICAgIC8vIGRlYnVnOiB0cnVlXG4gICAgfVxuICB9LFxuICAvLyBjYWxsYmFja3M6IHtcbiAgLy8gICBwb3N0Qm9vdDogZnVuY3Rpb24gKGdhbWUpIHtcbiAgLy8gICAgIGdhbWUuc2NlbmUuZHVtcCgpO1xuICAvLyAgIH1cbiAgLy8gfSxcbiAgc2NlbmU6IFNjZW5lcyxcbiAgcGFyZW50OiAnZ2FtZScsXG4gIGJhY2tncm91bmRDb2xvcjogMHg0QjJBM0MsXG59O1xuXG5leHBvcnQgY29uc3QgZ2FtZSA9IG5ldyBQaGFzZXIuR2FtZShjb25maWcpO1xuXG4iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCB7IENPTE9VUlMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuXG5jb25zdCBzY2VuZUNvbmZpZzogUGhhc2VyLlR5cGVzLlNjZW5lcy5TZXR0aW5nc0NvbmZpZyA9IHtcbiAgYWN0aXZlOiBmYWxzZSxcbiAgdmlzaWJsZTogZmFsc2UsXG4gIGtleTogJ0Jvb3QnLFxufTtcblxuZXhwb3J0IGNsYXNzIEJvb3RTY2VuZSBleHRlbmRzIFBoYXNlci5TY2VuZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHNjZW5lQ29uZmlnKTtcbiAgfVxuXG4gIHB1YmxpYyBwcmVsb2FkKCkge1xuICAgIC8qKiAgICBcbiAgICAgKiBDcmVhdGUgYSBwcm9ncmVzcyBiYXIgZ3JhcGhpY3MgICAgXG4gICAgICovICAgICBcbiAgICBjb25zdCBwcm9ncmVzc0JhciA9IHRoaXMuYWRkLmdyYXBoaWNzKCk7XG4gICAgY29uc3QgcHJvZ3Jlc3NCb3ggPSB0aGlzLmFkZC5ncmFwaGljcygpO1xuICAgIHByb2dyZXNzQm94LmZpbGxTdHlsZShDT0xPVVJTLmRhcmtHcmF5Lm51bWJlciwgMC44KTtcbiAgICBwcm9ncmVzc0JveC5maWxsUmVjdCgyNDAsIDI3MCwgMzIwLCA1MCk7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIEFkZCB0ZXh0IHRvIHRoZSBsb2FkZXIgICAgXG4gICAgICovXG4gICAgY29uc3QgeyBjZW50ZXJYLCBjZW50ZXJZIH0gPSB0aGlzLmNhbWVyYXMubWFpblxuICAgIGNvbnN0IGxvYWRpbmdUZXh0ID0gdGhpcy5tYWtlLnRleHQoe1xuICAgICAgeDogY2VudGVyWCxcbiAgICAgIHk6IGNlbnRlclksXG4gICAgICB0ZXh0OiAnTG9hZGluZy4uLicsXG4gICAgICBzdHlsZToge1xuICAgICAgICBmb250OiAnMjBweCBtb25vc3BhY2UnLFxuICAgICAgICBmaWxsOiBDT0xPVVJTLndoaXRlLnN0cmluZ1xuICAgICAgfVxuICAgIH0pO1xuICAgIGxvYWRpbmdUZXh0LnNldE9yaWdpbigwLjUsIDAuNSk7XG4gICAgXG4gICAgdGhpcy5sb2FkLm9uKCdwcm9ncmVzcycsICh2YWx1ZTogbnVtYmVyKSA9PiB7XG4gICAgICBwcm9ncmVzc0Jhci5jbGVhcigpO1xuICAgICAgcHJvZ3Jlc3NCYXIuZmlsbFN0eWxlKENPTE9VUlMud2hpdGUubnVtYmVyLCAxKTtcbiAgICAgIHByb2dyZXNzQmFyLmZpbGxSZWN0KDI1MCwgMjgwLCAzMDAgKiB2YWx1ZSwgMzApO1xuICAgIH0pO1xuICAgIHRoaXMubG9hZC5vbignZmlsZXByb2dyZXNzJywgKGZpbGU6IEZpbGUpID0+IHtcbiAgICAgIGxvYWRpbmdUZXh0LnNldFRleHQoZmlsZS5zcmMpO1xuICAgIH0pO1xuICAgIHRoaXMubG9hZC5vbignY29tcGxldGUnLCAoKSA9PiB7XG4gICAgICAvKiogICAgICBcbiAgICAgICAqIERlc3Ryb3kgdGhlIGxvYWRpbmcgYmFyIGdyYXBoaWNzICAgICAgXG4gICAgICAgKi8gICAgICAgXG4gICAgICBwcm9ncmVzc0Jhci5kZXN0cm95KCk7XG4gICAgICBwcm9ncmVzc0JveC5kZXN0cm95KCk7XG4gICAgICBsb2FkaW5nVGV4dC5kZXN0cm95KCk7XG4gICAgICB0aGlzLnNjZW5lLnN0YXJ0KCdUaXRsZScpO1xuICAgIH0pO1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBMb2FkIHRoZSBhc3NldHMgICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLmxvYWQudGlsZW1hcFRpbGVkSlNPTigndGl0bGUnLCAnLi9hc3NldHMvdGl0bGUuanNvbicpO1xuICAgIHRoaXMubG9hZC50aWxlbWFwVGlsZWRKU09OKCdtYXAwJywgJy4vYXNzZXRzL2xldmVsMC5qc29uJyk7XG4gICAgdGhpcy5sb2FkLnRpbGVtYXBUaWxlZEpTT04oJ21hcDEnLCAnLi9hc3NldHMvbGV2ZWwxLmpzb24nKTtcbiAgICB0aGlzLmxvYWQudGlsZW1hcFRpbGVkSlNPTignbWFwMicsICcuL2Fzc2V0cy9sZXZlbDIuanNvbicpO1xuICAgIHRoaXMubG9hZC50aWxlbWFwVGlsZWRKU09OKCdtYXAzJywgJy4vYXNzZXRzL2xldmVsMy5qc29uJyk7XG4gICAgdGhpcy5sb2FkLnNwcml0ZXNoZWV0KCd0aWxlcycsICcuL2Fzc2V0cy90aWxlcy5wbmcnLCB7IFxuICAgICAgZnJhbWVXaWR0aDogMTYsXG4gICAgICBmcmFtZUhlaWdodDogMTYsXG4gICAgfSk7XG4gIH1cbn1cblxudHlwZSBGaWxlID0geyBcbiAgc3JjOiBzdHJpbmdcbn0iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCB7IFNJREVfVVAsIFRPUF9MRUZULCBUT1AsIFRPUF9SSUdIVCwgQk9UVE9NX1JJR0hULCBCT1RUT01fTEVGVCwgTEVGVCwgQk9UVE9NLCBSSUdIVCwgU1RBUlRfRE9PUiwgRE9XTl9TUElLRSwgVVBfU1BJS0UsIExFRlRfU1BJS0UsIFJJR0hUX1NQSUtFLCBDT0xPVVJTLCBSRURfS0VZLCBCTEFOSywgUkVEX0RPT1JfTE9DS0VELCBSRURfRE9PUl9FTlRSQU5DRSwgUkVEX0RPT1JfRVhJVCwgWUVMTE9XX0tFWSwgWUVMTE9XX0RPT1JfTE9DS0VELCBZRUxMT1dfRE9PUl9FTlRSQU5DRSwgWUVMTE9XX0RPT1JfRVhJVCwgQkxVRV9ET09SX0VYSVQsIEdSRUVOX0RPT1JfRVhJVCwgQkxVRV9LRVksIEdSRUVOX0RPT1JfTE9DS0VELCBHUkVFTl9ET09SX0VOVFJBTkNFLCBCTFVFX0RPT1JfTE9DS0VELCBCTFVFX0RPT1JfRU5UUkFOQ0UsIEdSRUVOX0tFWSwgREVBRCwgQUxJVkUsIFJVTl9FTkQsIFdJWkFSRCwgU1BJREVSIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmltcG9ydCB7IFdpemFyZCwgU3BpZGVyIH0gZnJvbSAnZ2FtZS1vYmplY3RzJztcbiBcblxuY29uc3Qgc2NlbmVDb25maWc6IFBoYXNlci5UeXBlcy5TY2VuZXMuU2V0dGluZ3NDb25maWcgPSB7XG4gIGFjdGl2ZTogZmFsc2UsXG4gIHZpc2libGU6IGZhbHNlLFxuICBrZXk6ICdHYW1lJyxcbn07XG5cbmV4cG9ydCBjbGFzcyBHYW1lU2NlbmUgZXh0ZW5kcyBQaGFzZXIuU2NlbmUge1xuICBtYXA6IFBoYXNlci5UaWxlbWFwcy5UaWxlbWFwO1xuICB0aWxlczogUGhhc2VyLlRpbGVtYXBzLlRpbGVzZXQ7XG4gIGdyb3VuZExheWVyOiBQaGFzZXIuVGlsZW1hcHMuU3RhdGljVGlsZW1hcExheWVyO1xuICBjb25maWc6IENvbmZpZztcbiAgcGxheWVyOiBQaGFzZXIuUGh5c2ljcy5BcmNhZGUuU3ByaXRlO1xuICBkZWJ1Z0dyYXBoaWM6IFBoYXNlci5HYW1lT2JqZWN0cy5HcmFwaGljcztcbiAgY2FuRmxpcEdyYXZpdHk6IGJvb2xlYW47XG4gIGN1cnNvcnM6IFBoYXNlci5UeXBlcy5JbnB1dC5LZXlib2FyZC5DdXJzb3JLZXlzO1xuICByb3RhdGluZzogYm9vbGVhbjtcbiAgZGlyZWN0aW9uOiAwIHwgMSB8IDIgfCAzO1xuICBpc0ZsaXBwZWQ6IGJvb2xlYW47XG4gIGJnTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5TdGF0aWNUaWxlbWFwTGF5ZXI7XG4gIHNwaWtlc0xheWVyOiBQaGFzZXIuVGlsZW1hcHMuRHluYW1pY1RpbGVtYXBMYXllcjtcbiAgaXNEZWFkOiBib29sZWFuO1xuICBhY3Rpb25zTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5EeW5hbWljVGlsZW1hcExheWVyO1xuICBpdGVtczogYW55W107XG4gIHJlbG9jYXRpbmc6IGJvb2xlYW47XG4gIGNoZWNrcG9pbnQ6IFBoYXNlci5UaWxlbWFwcy5UaWxlO1xuICBsZXZlbDogbnVtYmVyO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihzY2VuZUNvbmZpZyk7XG4gIH1cbiAgXG4gIHB1YmxpYyBpbml0KHsgbGV2ZWwgfToge1xuICAgIGxldmVsOiBudW1iZXI7XG4gIH0pIHtcbiAgICB0aGlzLmxldmVsID0gbGV2ZWw7XG4gIH1cbiAgXG4gIHB1YmxpYyBwcmVsb2FkKCkge1xuICAgIHRoaXMuaXNEZWFkID0gZmFsc2U7XG4gICAgLyoqICAgIFxuICAgICAqIFVzZSB0aGVzZSB0byBjb250cm9sIHRoZSBzcGVlZCBhbmQgZ3Jhdml0eSBvZiB0aGUgcGxheWVyICAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5jb25maWcgPSB7XG4gICAgICBncmF2aXR5OiAxMjAwLFxuICAgICAgc3BlZWQ6IDEyMCxcbiAgICAgIGdyYXZpdHlEaXJlY3Rpb246IDEsXG4gICAgICBqdW1wRm9yY2U6IDI1NSxcbiAgICB9XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIFRoaXMgd2lsbCBiZSBzZXQgdG8gZmFsc2Ugd2hpbHN0IHRoZSBjaGFyYWN0ZXIgaXMgZmFsbGluZyBzbyB0aGF0IHRoZXkgY2Fubm90IGZsaXAgZ3Jhdml0eSBoYWxmXG4gICAgICogd2F5IHRocm91Z2ggZmFsbGluZy4gICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLmNhbkZsaXBHcmF2aXR5ID0gdHJ1ZTtcbiAgICB0aGlzLmlzRmxpcHBlZCA9IGZhbHNlO1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBXZSB3aWxsIHVzZSB0aGVzZSB2YWx1ZXMgdG8gcm90YXRlIHRoZSBzcHJpdGUgYXJvdW5kIGNvcm5lcnNcbiAgICAgKi8gICAgIFxuICAgIHRoaXMucm90YXRpbmcgPSBmYWxzZTtcbiAgICB0aGlzLmRpcmVjdGlvbiA9IFNJREVfVVA7XG4gICAgXG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIFdlIHdpbGwgdXNlIHRoaXMgdmFsdWUgdG8gZGVmaW5lIHdoZXRoZXIgb3Igbm90IHRoZSB1c2UgaXMgbW92aW5nIGJldHdlZW4gMiBkb29ycy4gICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLnJlbG9jYXRpbmcgPSBmYWxzZTtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogQW55IGl0ZW1zIHRoYXQgdGhlIHBsYXllciBwaWNrcyB1cCB3aWxsIGJlIHN0b3JlZCBpbiB0aGlzIGFycmF5ICAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5pdGVtcyA9IFtdO1xuICB9XG4gIFxuICBwdWJsaWMgY3JlYXRlKCkge1xuICAgIGNvbnN0IHsgU1BBQ0UsIEUgfSA9IFBoYXNlci5JbnB1dC5LZXlib2FyZC5LZXlDb2RlcztcbiAgICAvLyBEZWZpbmUgdGhlIGFycm93IGtleXNcbiAgICB0aGlzLmN1cnNvcnMgPSB0aGlzLmlucHV0LmtleWJvYXJkLmNyZWF0ZUN1cnNvcktleXMoKTtcbiAgICAvLyBEZWZpbmUgRSBrZXlcbiAgICBjb25zdCBlS2V5ID0gdGhpcy5pbnB1dC5rZXlib2FyZC5hZGRLZXkoRSk7XG4gICAgLy8gRGVmaW5lIHNwYWNlYmFyIGtleVxuICAgIGNvbnN0IHNwYWNlS2V5ID0gdGhpcy5pbnB1dC5rZXlib2FyZC5hZGRLZXkoU1BBQ0UpO1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBDcmVhdGUgdGhlIG1hcCBhbmQgdGhlIHBsYXRmb3JtIGxheWVyICAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5tYXAgPSB0aGlzLm1ha2UudGlsZW1hcCh7IGtleTogYG1hcCR7dGhpcy5sZXZlbH1gIH0pO1xuICAgIHRoaXMudGlsZXMgPSB0aGlzLm1hcC5hZGRUaWxlc2V0SW1hZ2UoJ3RpbGVzJyk7XG4gICAgdGhpcy5iZ0xheWVyID0gdGhpcy5tYXAuY3JlYXRlU3RhdGljTGF5ZXIoJ0JhY2tncm91bmQnLCB0aGlzLnRpbGVzKVxuICAgIHRoaXMuZ3JvdW5kTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVTdGF0aWNMYXllcignR3JvdW5kJywgdGhpcy50aWxlcylcbiAgICB0aGlzLnNwaWtlc0xheWVyID0gdGhpcy5tYXAuY3JlYXRlRHluYW1pY0xheWVyKCdTcGlrZXMnLCB0aGlzLnRpbGVzKVxuICAgIHRoaXMuYWN0aW9uc0xheWVyID0gdGhpcy5tYXAuY3JlYXRlRHluYW1pY0xheWVyKCdBY3Rpb25zJywgdGhpcy50aWxlcylcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogU2V0IHRoZSBncm91bmQgbGF5ZXIgdG8gYmUgaGF2ZSBhbnkgdGlsZXMgd2l0aCBpbmRleCAxIG9yIDAgbm90IGJlIGNvbGlkYWJsZS5cbiAgICAgKiBUaWxlcyAxIGFuZCAwIGFyZSB0aGUgYmFja2dyb3VuZC8gYmxhbmsgdGlsZXMuICAgICBcbiAgICAgKi9cbiAgICB0aGlzLmdyb3VuZExheWVyLnNldENvbGxpc2lvbkJ5RXhjbHVzaW9uKFswLCAxXSk7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIFRoZSB0aWxlcyB3aWxsIHByb2JhYmx5IGdvIGFsbCB0aGUgd2F5IGFyb3VuZCB0aGUgZWRnZSBvZiB0aGUgbWFwIHRvXG4gICAgICogcHJldmVudCB0aGUgcGxheWVyIGZyb20gZ29pbmcgb2ZmIGNhbnZhcy5cbiAgICAgKiBKdXN0IGluIGNhc2UgdGhvdWdoIG1ha2UgdGhleSBwbGF5ZXIgY29sbGlkZSB3aXRoIHRoZSBib3VuZHMuXG4gICAgICogSGVyZSB3ZSBhcmUganVzdCBjcmVhdGluZyB0aGUgYm91bmRzIGJhc2VkIG9uIHRoZSB0aWxlbWFwIHNpemUuXG4gICAgICogTGF0ZXIgd2Ugd2lsbCBhZGQgYSBjb2xsaXNpb24gIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5waHlzaWNzLndvcmxkLmJvdW5kcy53aWR0aCA9IHRoaXMuZ3JvdW5kTGF5ZXIud2lkdGg7XG4gICAgdGhpcy5waHlzaWNzLndvcmxkLmJvdW5kcy5oZWlnaHQgPSB0aGlzLmdyb3VuZExheWVyLmhlaWdodDtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogQ3JlYXRlIGEgbmV3IHNwcml0ZSBhbmQgYWRkIGl0IHRvIHRoZSBwaHlzaWNzIG9mIHRoZSBzY2VuZS4gXG4gICAgICogV2UgdGhlbiBzZXQgdGhlIHZlcnRpY2FsIGdyYXZpdHkgb2YgdGhlIHNwcml0ZSBzbyB0aGF0IGl0IGZhbGxzLiAgXG4gICAgICovICAgXG4gICAgY29uc3Qgc3RhcnRUaWxlID0gdGhpcy5hY3Rpb25zTGF5ZXIuZmluZEJ5SW5kZXgoU1RBUlRfRE9PUik7ICBcbiAgICBjb25zdCByZWREb29yRXhpdFRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChSRURfRE9PUl9FWElUKTtcbiAgICBjb25zdCBibHVlRG9vckV4aXRUaWxlID0gdGhpcy5hY3Rpb25zTGF5ZXIuZmluZEJ5SW5kZXgoQkxVRV9ET09SX0VYSVQpO1xuICAgIGNvbnN0IHllbGxvd0Rvb3JFeGl0VGlsZSA9IHRoaXMuYWN0aW9uc0xheWVyLmZpbmRCeUluZGV4KFlFTExPV19ET09SX0VYSVQpO1xuICAgIFxuICAgIFxuICAgIHRoaXMuY2hlY2twb2ludCA9IHN0YXJ0VGlsZTtcbiAgICBcbiAgICB0aGlzLnBsYXllciA9IHRoaXMucGh5c2ljcy5hZGQuc3ByaXRlKHN0YXJ0VGlsZS5waXhlbFggKyA4LCBzdGFydFRpbGUucGl4ZWxZICsgNSwgJ3RpbGVzJywgQUxJVkUpO1xuICAgIC8vIHRoaXMucGxheWVyLnNldE9yaWdpbigwLCAwKVxuICAgIHRoaXMucGxheWVyLmJvZHkuZ3Jhdml0eS5zZXQoMCwgdGhpcy5jb25maWcuZ3Jhdml0eSk7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIENyZWF0ZSB3YWxraW5nIGFuaW1hdGlvbnMgICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLmFuaW1zLmNyZWF0ZSh7XG4gICAgICBrZXk6ICdydW5uaW5nJyxcbiAgICAgIGZyYW1lczogdGhpcy5hbmltcy5nZW5lcmF0ZUZyYW1lTnVtYmVycygndGlsZXMnLCB7IHN0YXJ0OiBBTElWRSwgZW5kOiBSVU5fRU5EIH0pLFxuICAgICAgZnJhbWVSYXRlOiAxMCxcbiAgICAgIHJlcGVhdDogLTEsXG4gICAgfSlcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogQ29sbGlkZSB0aGUgcGxheWVyIHdpdGggdGhlIGNvbGlkYWJsZSB0aWxlcyBpbiB0aGUgdGlsZW1hcCAgICBcbiAgICAgKi8gICAgIFxuICAgIHRoaXMucGxheWVyLnNldENvbGxpZGVXb3JsZEJvdW5kcyh0cnVlKTtcbiAgICB0aGlzLnBoeXNpY3MuYWRkLmNvbGxpZGVyKHRoaXMucGxheWVyLCB0aGlzLmdyb3VuZExheWVyLCAocGxheWVyOiBHYW1lU2NlbmVbJ3BsYXllciddLCB0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgaWYgKHRoaXMuaXNEZWFkIHx8IHRoaXMucmVsb2NhdGluZykge1xuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5yb3RhdGluZykge1xuICAgICAgICB0aGlzLmNoZWNrUm90YXRpb24odGlsZSwgcGxheWVyKTtcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5jYW5GbGlwR3Jhdml0eSkge1xuICAgICAgICB0aGlzLmNhbkZsaXBHcmF2aXR5ID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9LCAoKSA9PiB7XG4gICAgICByZXR1cm4gIXRoaXMuaXNEZWFkICYmICF0aGlzLnJlbG9jYXRpbmc7XG4gICAgfSlcbiAgICBcbiAgICB0aGlzLnBoeXNpY3MuYWRkLm92ZXJsYXAodGhpcy5wbGF5ZXIsIHRoaXMuc3Bpa2VzTGF5ZXIsIChwbGF5ZXI6IEdhbWVTY2VuZVsncGxheWVyJ10sIHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICBpZiAodGhpcy5pc0RlYWQgfHwgdGhpcy5yZWxvY2F0aW5nKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgXG4gICAgICB0aGlzLmtpbGxQbGF5ZXIoKTtcbiAgICB9LCAocGxheWVyLCB0aWxlKSA9PiB7XG4gICAgICBpZiAodGlsZS5pbmRleCA9PT0gMSB8fCB0aGlzLmlzRGVhZCB8fCB0aGlzLnJlbG9jYXRpbmcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICBpZiAodGlsZS5pbmRleCA9PT0gVVBfU1BJS0UpIHtcbiAgICAgICAgaWYgKHBsYXllci55ID4gdGlsZS5waXhlbFkgLSA0ICYmIHBsYXllci54ID49IHRpbGUucGl4ZWxYIC0gNSkge1xuICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSBET1dOX1NQSUtFKSB7XG4gICAgICAgIGlmIChwbGF5ZXIueSA8IHRpbGUucGl4ZWxZICsgMTUgJiYgcGxheWVyLnggPj0gdGlsZS5waXhlbFggLSA1KSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHRpbGUuaW5kZXggPT09IExFRlRfU1BJS0UpIHtcbiAgICAgICAgaWYgKHBsYXllci54ID49IHRpbGUucGl4ZWxYICsgNSkge1xuICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSBSSUdIVF9TUElLRSkge1xuICAgICAgICBpZiAocGxheWVyLnggPD0gdGlsZS5waXhlbFggKyAxNCkge1xuICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH0pXG4gICAgXG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIEZpcmVkIHdoZW4gdGhlIHBsYXllciBvdmVybGFwcyB3aXRoIHRoZSBhY3Rpb24gdGlsZXM6IGRvb3JzIGFuZCBrZXlzIGV0YyAgICBcbiAgICAgKi8gICAgIFxuICAgIHRoaXMucGh5c2ljcy5hZGQub3ZlcmxhcCh0aGlzLnBsYXllciwgdGhpcy5hY3Rpb25zTGF5ZXIsIChfcGxheWVyLCB0aWxlKSA9PiB7XG4gICAgICBjb25zdCBhY3Rpb25zID0ge1xuICAgICAgICBbUkVEX0tFWV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGlja3VwSXRlbShSRURfS0VZLCB0aWxlKVxuICAgICAgICB9LFxuICAgICAgICBbWUVMTE9XX0tFWV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGlja3VwSXRlbShZRUxMT1dfS0VZLCB0aWxlKVxuICAgICAgICB9LFxuICAgICAgICBbQkxVRV9LRVldOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICB0aGlzLnBpY2t1cEl0ZW0oQkxVRV9LRVksIHRpbGUpXG4gICAgICAgIH0sXG4gICAgICAgIFtHUkVFTl9LRVldOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICB0aGlzLnBpY2t1cEl0ZW0oR1JFRU5fS0VZLCB0aWxlKVxuICAgICAgICB9LFxuICAgICAgICBbUkVEX0RPT1JfTE9DS0VEXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMuaXRlbXMuaW5jbHVkZXMoUkVEX0tFWSkpIHtcbiAgICAgICAgICAgIHRoaXMuYWN0aW9uc0xheWVyLnB1dFRpbGVBdChSRURfRE9PUl9FTlRSQU5DRSwgdGlsZS54LCB0aWxlLnkpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbUkVEX0RPT1JfRU5UUkFOQ0VdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICB0aGlzLnJlbG9jYXRlKHJlZERvb3JFeGl0VGlsZSk7XG4gICAgICAgIH0sXG4gICAgICAgIFtSRURfRE9PUl9FWElUXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgLy8gRmluZCB0aGUgdGlsZSBoZXJlIGJlY2F1c2UgaXQgbWF5IG5vdCBleGlzdCBhdCB0aGUgc3RhcnQgb2YgdGhlIGdhbWVcbiAgICAgICAgICBjb25zdCByZWREb29yRW50cmFuY2VUaWxlID0gdGhpcy5hY3Rpb25zTGF5ZXIuZmluZEJ5SW5kZXgoUkVEX0RPT1JfRU5UUkFOQ0UpO1xuICAgICAgICAgIHRoaXMucmVsb2NhdGUocmVkRG9vckVudHJhbmNlVGlsZSk7XG4gICAgICAgIH0sXG4gICAgICAgIFtZRUxMT1dfRE9PUl9MT0NLRURdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5pdGVtcy5pbmNsdWRlcyhZRUxMT1dfS0VZKSkge1xuICAgICAgICAgICAgdGhpcy5hY3Rpb25zTGF5ZXIucHV0VGlsZUF0KFlFTExPV19ET09SX0VOVFJBTkNFLCB0aWxlLngsIHRpbGUueSlcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFtZRUxMT1dfRE9PUl9FTlRSQU5DRV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucmVsb2NhdGUoeWVsbG93RG9vckV4aXRUaWxlKTtcbiAgICAgICAgfSxcbiAgICAgICAgW1lFTExPV19ET09SX0VYSVRdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICAvLyBGaW5kIHRoZSB0aWxlIGhlcmUgYmVjYXVzZSBpdCBtYXkgbm90IGV4aXN0IGF0IHRoZSBzdGFydCBvZiB0aGUgZ2FtZVxuICAgICAgICAgIGNvbnN0IHllbGxvd0Rvb3JFbnRyYW5jZVRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChZRUxMT1dfRE9PUl9FTlRSQU5DRSk7XG4gICAgICAgICAgdGhpcy5yZWxvY2F0ZSh5ZWxsb3dEb29yRW50cmFuY2VUaWxlKTtcbiAgICAgICAgfSxcbiAgICAgICAgW0dSRUVOX0RPT1JfTE9DS0VEXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMuaXRlbXMuaW5jbHVkZXMoR1JFRU5fS0VZKSkge1xuICAgICAgICAgICAgdGhpcy5hY3Rpb25zTGF5ZXIucHV0VGlsZUF0KEdSRUVOX0RPT1JfRU5UUkFOQ0UsIHRpbGUueCwgdGlsZS55KVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgW0dSRUVOX0RPT1JfRU5UUkFOQ0VdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICB0aGlzLmV2ZW50cy5lbWl0KCdjb21wbGV0ZWQnKTtcbiAgICAgICAgfSxcbiAgICAgICAgW0JMVUVfRE9PUl9MT0NLRURdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5pdGVtcy5pbmNsdWRlcyhCTFVFX0tFWSkpIHtcbiAgICAgICAgICAgIHRoaXMuYWN0aW9uc0xheWVyLnB1dFRpbGVBdChCTFVFX0RPT1JfRU5UUkFOQ0UsIHRpbGUueCwgdGlsZS55KVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgW0JMVUVfRE9PUl9FTlRSQU5DRV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucmVsb2NhdGUoYmx1ZURvb3JFeGl0VGlsZSk7XG4gICAgICAgIH0sXG4gICAgICAgIFtCTFVFX0RPT1JfRVhJVF06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIC8vIEZpbmQgdGhlIHRpbGUgaGVyZSBiZWNhdXNlIGl0IG1heSBub3QgZXhpc3QgYXQgdGhlIHN0YXJ0IG9mIHRoZSBnYW1lXG4gICAgICAgICAgY29uc3QgYmx1ZURvb3JFbnRyYW5jZVRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChCTFVFX0RPT1JfRU5UUkFOQ0UpO1xuICAgICAgICAgIHRoaXMucmVsb2NhdGUoYmx1ZURvb3JFbnRyYW5jZVRpbGUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhY3Rpb25zW3RpbGUuaW5kZXhdKHRpbGUpXG4gICAgICBcbiAgICB9LCAoX3BsYXllciwgeyBpbmRleCB9OiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgaWYgKHRoaXMuaXNEZWFkIHx8IHRoaXMucmVsb2NhdGluZykge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIGlmICghZUtleS5pc0Rvd24pIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICAvLyBBIGxpc3Qgb2YgdGhlIGludGVyYWN0aWJsZSB0aWxlc1xuICAgICAgY29uc3QgYWN0aW9ucyA9IFtSRURfS0VZLCBZRUxMT1dfS0VZLCBCTFVFX0tFWSwgR1JFRU5fS0VZLCBSRURfRE9PUl9MT0NLRUQsIFJFRF9ET09SX0VOVFJBTkNFLCBSRURfRE9PUl9FWElULCBZRUxMT1dfRE9PUl9MT0NLRUQsIFlFTExPV19ET09SX0VOVFJBTkNFLCBZRUxMT1dfRE9PUl9FWElULCBCTFVFX0RPT1JfTE9DS0VELCBCTFVFX0RPT1JfRU5UUkFOQ0UsIEJMVUVfRE9PUl9FWElULCBHUkVFTl9ET09SX0xPQ0tFRCwgR1JFRU5fRE9PUl9FTlRSQU5DRSwgR1JFRU5fRE9PUl9FWElUXTtcbiAgICAgIHJldHVybiBhY3Rpb25zLmluY2x1ZGVzKGluZGV4KVxuICAgIH0pXG4gICAgLyoqICAgIFxuICAgICAqIFdoZW4gdGhlIHNwYWNlIGtleSBpcyBwcmVzc2VkLCBpZiBncmF2aXR5IGNhbiBiZSBmbGlwcGVkOlxuICAgICAqIEZsaXAgaXQgYW5kIGludmVydCB0aGUgcGxheWVycyBncmF2aXR5IGFuZCBkaXNhYmxlIGdyYXZpdHkgZmxpcHBpbmcgdW50aWwgdGhlcmUgaXMgYSBjb2xsaXNpb24gd2l0aCB0aGUgZ3JvdW5kLiAgICBcbiAgICAgKi8gICAgIFxuICAgIHNwYWNlS2V5Lm9uKFwiZG93blwiLCAoKSA9PiB0aGlzLmZsaXAoKSk7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIHNldCB0aGUgY2FtZXJhIHRvIG5vdCBnbyBvdXQgb2YgdGhlIGJvdW5kcyBidXQgZm9sbG93IHRoZSBwbGF5ZXIsIGtlZXBpbmcgdGhlbSBpbiB0aGUgY2VudGVyLiAgICBcbiAgICAgKi8gICAgIFxuICAgIC8vIHRoaXMuY2FtZXJhcy5tYWluLnNldEJvdW5kcygwLCAwLCA4MDAsIDYwMCk7XG4gICAgdGhpcy5jYW1lcmFzLm1haW4uc3RhcnRGb2xsb3codGhpcy5wbGF5ZXIpO1xuICAgIHRoaXMuY2FtZXJhcy5tYWluLnNldFpvb20oMik7XG4gICAgXG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIENyZWF0ZSBlbmVtaWVzICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLnNwaWtlc0xheWVyLmZvckVhY2hUaWxlKCh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgaWYgKHRpbGUuaW5kZXggPT09IFdJWkFSRCkge1xuICAgICAgICB0aGlzLnNwaWtlc0xheWVyLnB1dFRpbGVBdChCTEFOSywgdGlsZS54LCB0aWxlLnkpO1xuICAgICAgICBjb25zdCB3aXphcmQgPSBuZXcgV2l6YXJkKHRoaXMsIHRpbGUucGl4ZWxYLCB0aWxlLnBpeGVsWSwgJ3RpbGVzJylcbiAgICAgICAgdGhpcy5hZGQuZXhpc3Rpbmcod2l6YXJkKVxuICAgICAgfTtcbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSBTUElERVIpIHtcbiAgICAgICAgdGhpcy5zcGlrZXNMYXllci5wdXRUaWxlQXQoQkxBTkssIHRpbGUueCwgdGlsZS55KTtcbiAgICAgICAgY29uc3Qgc3BpZGVyID0gbmV3IFNwaWRlcih0aGlzLCB0aWxlLnBpeGVsWCwgdGlsZS5waXhlbFksICd0aWxlcycpXG4gICAgICAgIHRoaXMuYWRkLmV4aXN0aW5nKHNwaWRlcilcbiAgICAgICAgdGhpcy5waHlzaWNzLmFkZC5leGlzdGluZyhzcGlkZXIpXG4gICAgICAgIHNwaWRlci5zZXRWZWxvY2l0eVkoMTAwKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBcbiAgcHVibGljIHVwZGF0ZSgpIHsgICBcbiAgICBpZiAodGhpcy5pc0RlYWQgfHwgdGhpcy5yZWxvY2F0aW5nKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKHRoaXMuY3Vyc29ycy51cC5pc0Rvd24pIHtcbiAgICAgIHRoaXMuanVtcCgpO1xuICAgIH1cbiAgICBpZiAodGhpcy5jdXJzb3JzLmxlZnQuaXNEb3duICYmICF0aGlzLmN1cnNvcnMucmlnaHQuaXNEb3duKSB7XG4gICAgICB0aGlzLnBsYXllci5hbmltcy5wbGF5KCdydW5uaW5nJywgdHJ1ZSlcbiAgICAgIGlmICghdGhpcy5pc0ZsaXBwZWQpIHtcbiAgICAgICAgdGhpcy5tb3ZlQ291bnRlckNsb2Nrd2lzZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5tb3ZlQ2xvY2t3aXNlKCk7XG4gICAgICB9XG4gICAgICBcbiAgICB9IGVsc2UgaWYgKHRoaXMuY3Vyc29ycy5yaWdodC5pc0Rvd24gJiYgIXRoaXMuY3Vyc29ycy5sZWZ0LmlzRG93bikge1xuICAgICAgdGhpcy5wbGF5ZXIuYW5pbXMucGxheSgncnVubmluZycsIHRydWUpXG4gICAgICBpZiAodGhpcy5pc0ZsaXBwZWQpIHtcbiAgICAgICAgdGhpcy5tb3ZlQ291bnRlckNsb2Nrd2lzZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5tb3ZlQ2xvY2t3aXNlKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc3RvcE1vdmluZygpXG4gICAgfVxuICB9XG4gIFxuICBwcml2YXRlIG1vdmVDb3VudGVyQ2xvY2t3aXNlKCkge1xuICAgIHRoaXMucGxheWVyLnNldEZsaXBYKCF0aGlzLmlzRmxpcHBlZCk7XG4gICAgY29uc3QgZGlyZWN0aW9ucyA9IFtcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkoLXRoaXMuY29uZmlnLnNwZWVkLCB0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LnkpXG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSh0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LngsIC10aGlzLmNvbmZpZy5zcGVlZClcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMuY29uZmlnLnNwZWVkLCB0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LnkpXG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSgtdGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS54LCB0aGlzLmNvbmZpZy5zcGVlZClcbiAgICAgIH0sICBcbiAgICBdXG4gICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBtb3ZlQ2xvY2t3aXNlKCkge1xuICAgIHRoaXMucGxheWVyLnNldEZsaXBYKHRoaXMuaXNGbGlwcGVkKTtcbiAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSh0aGlzLmNvbmZpZy5zcGVlZCwgdGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS55KTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueCwgdGhpcy5jb25maWcuc3BlZWQpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkoLXRoaXMuY29uZmlnLnNwZWVkLCB0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LnkpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkodGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS54LCAtdGhpcy5jb25maWcuc3BlZWQpO1xuICAgICAgfVxuICAgIF1cbiAgICBkaXJlY3Rpb25zW3RoaXMuZGlyZWN0aW9uXSgpO1xuICB9XG4gIFxuICBwcml2YXRlIHN0b3BNb3ZpbmcoKSB7XG4gICAgdGhpcy5wbGF5ZXIuYW5pbXMuc3RvcCgpO1xuICAgIGNvbnN0IGRpcmVjdGlvbnMgPSBbXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KDAsIHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueSk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSh0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LngsIDApO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkoMCwgdGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS55KTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueCwgMCk7XG4gICAgICB9XG4gICAgXVxuICAgIGRpcmVjdGlvbnNbdGhpcy5kaXJlY3Rpb25dKCk7XG4gIH1cbiAgXG4gIHByaXZhdGUganVtcCgpIHtcbiAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5wbGF5ZXIuYm9keS5ibG9ja2VkLmRvd24pIHtcbiAgICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eVkoLXRoaXMuY29uZmlnLmp1bXBGb3JjZSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnBsYXllci5ib2R5LmJsb2NrZWQubGVmdCkge1xuICAgICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5WCh0aGlzLmNvbmZpZy5qdW1wRm9yY2UpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAodGhpcy5wbGF5ZXIuYm9keS5ibG9ja2VkLnVwKSB7XG4gICAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHlZKHRoaXMuY29uZmlnLmp1bXBGb3JjZSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnBsYXllci5ib2R5LmJsb2NrZWQucmlnaHQpIHtcbiAgICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eVgoLXRoaXMuY29uZmlnLmp1bXBGb3JjZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBdXG4gICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBjaGVja1JvdGF0aW9uKHsgaW5kZXgsIC4uLnRpbGV9LCB7eCwgeSAuLi5wbGF5ZXJ9KSB7XG4gICAgaWYgKHRoaXMucm90YXRpbmcpIHJldHVybjtcbiAgICBcbiAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAoaW5kZXggPT09IFRPUF9SSUdIVCAmJiB4ID49IHRpbGUucGl4ZWxYICsgMjAgJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueCA+IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHggKyA0LCB5ICsgOClcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IFRPUF9MRUZUICYmIHggPD0gdGlsZS5waXhlbFggJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueCA8IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4IC0gOCwgeSArIDgpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09PSBSSUdIVCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IExFRlQpIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4LCB5KVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTV9SSUdIVCAmJiB5ID49IHRpbGUucGl4ZWxZICsgMjAgJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueSA+IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHggLSA4LCB5KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gVE9QX1JJR0hUICYmIHkgPD0gdGlsZS5waXhlbFkgJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueSA8IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4IC0gOCwgeSAtIDgpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09PSBCT1RUT00pIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09PSBUT1ApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4LCB5KVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTV9MRUZUICYmIHggPD0gdGlsZS5waXhlbFggJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueCA8IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHggLSA4LCB5IC0gOClcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTV9SSUdIVCAmJiB4ID49IHRpbGUucGl4ZWxYICsgMjAgJiYgcGxheWVyLmJvZHkudmVsb2NpdHkueCA+IDApIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4LCB5IC0gOClcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IFJJR0hUKSB7XG4gICAgICAgICAgdGhpcy5oYW5kbGVSb3RhdGlvbigtMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IExFRlQpIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmIChpbmRleCA9PT0gVE9QX0xFRlQgJiYgeSA8PSB0aWxlLnBpeGVsWSAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS55IDwgMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCArIDgsIHkgLSA4KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTV9MRUZUICYmIHkgPj0gdGlsZS5waXhlbFkgKyAyMCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS55ID4gMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHggKyA4LCB5KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTSAmJiAhdGhpcy5yb3RhdGluZykge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09PSBUT1AgJiYgIXRoaXMucm90YXRpbmcpIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKDEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICBdXG4gICAgXG4gICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBoYW5kbGVSb3RhdGlvbihkZWx0YTogbnVtYmVyLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICAgIHRoaXMucGxheWVyLmJvZHkuc2V0QWxsb3dHcmF2aXR5KGZhbHNlKTtcbiAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSgwLCAwKTtcbiAgICB0aGlzLnJvdGF0aW5nID0gdHJ1ZTtcbiAgICB0aGlzLnR3ZWVucy5hZGQoe1xuICAgICAgdGFyZ2V0czogW3RoaXMucGxheWVyXSxcbiAgICAgIGFuZ2xlOiB0aGlzLnBsYXllci5hbmdsZSArIDkwICogZGVsdGEsXG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIGR1cmF0aW9uOiAyMDAsXG4gICAgICBvbkNvbXBsZXRlOiAoKSA9PiB7XG4gICAgICAgIHRoaXMucm90YXRpbmcgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5wbGF5ZXIuYm9keS5zZXRBbGxvd0dyYXZpdHkodHJ1ZSk7XG4gICAgICAgIHRoaXMuZGlyZWN0aW9uID0gUGhhc2VyLk1hdGguV3JhcCh0aGlzLmRpcmVjdGlvbiArIGRlbHRhLCAwLCA0KSAgYXMgMCB8IDEgfCAyIHwgMyA7XG4gICAgICAgIHRoaXMuc2V0R3Jhdml0eSgpO1xuICAgICAgfVxuICAgIH0pXG4gIH1cbiAgXG4gIHByaXZhdGUgc2V0R3Jhdml0eSgpIHtcbiAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRHcmF2aXR5KDAsIHRoaXMuY29uZmlnLmdyYXZpdHkpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0R3Jhdml0eSgtdGhpcy5jb25maWcuZ3Jhdml0eSwgMCk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRHcmF2aXR5KDAsIC10aGlzLmNvbmZpZy5ncmF2aXR5KTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldEdyYXZpdHkodGhpcy5jb25maWcuZ3Jhdml0eSwgMCk7XG4gICAgICB9XG4gICAgXVxuICAgIGRpcmVjdGlvbnNbdGhpcy5kaXJlY3Rpb25dKCk7XG4gIH1cbiAgXG4gIHB1YmxpYyBmbGlwKCkge1xuICAgIGlmICh0aGlzLmlzRGVhZCkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmICh0aGlzLmNhbkZsaXBHcmF2aXR5KSB7XG4gICAgICB0aGlzLmNhbkZsaXBHcmF2aXR5ID0gZmFsc2U7XG4gICAgICBpZiAodGhpcy5kaXJlY3Rpb24gPT09IDAgfHwgdGhpcy5kaXJlY3Rpb24gPT09IDIpIHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuYm9keS5ncmF2aXR5LnkgKj0gLTE7XG4gICAgICAgIHRoaXMucGxheWVyLmJvZHkuZ3Jhdml0eS54ID0gMFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuYm9keS5ncmF2aXR5LnggKj0gLTE7XG4gICAgICAgIHRoaXMucGxheWVyLmJvZHkuZ3Jhdml0eS55ID0gMFxuICAgICAgfVxuICAgICAgdGhpcy5wbGF5ZXIuc2V0RmxpcFkoIXRoaXMuaXNGbGlwcGVkKVxuICAgICAgY29uc3QgZGlyZWN0aW9uczogQXJyYXk8MCB8IDEgfCAyIHwgMz4gPSBbMiwgMywgMCwgMV1cbiAgICAgIHRoaXMuZGlyZWN0aW9uID0gZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl1cbiAgICAgIHRoaXMuaXNGbGlwcGVkID0gIXRoaXMuaXNGbGlwcGVkXG4gICAgfVxuICB9XG4gIFxuICBwcml2YXRlIHJlbG9jYXRlKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlLCBjYWxsYmFjaz86ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4gdm9pZCwgY2FsbGJhY2syPzogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB2b2lkKSB7XG4gICAgdGhpcy5yZWxvY2F0aW5nID0gdHJ1ZTtcbiAgICB0aGlzLnBsYXllci5ib2R5LnNldEFsbG93R3Jhdml0eShmYWxzZSk7XG4gICAgdGhpcy50d2VlbnMuYWRkKHtcbiAgICAgIHRhcmdldHM6IFt0aGlzLnBsYXllcl0sXG4gICAgICBhbHBoYToge1xuICAgICAgICBmcm9tOiAxLFxuICAgICAgICB0bzogMFxuICAgICAgfSxcbiAgICAgIGR1cmF0aW9uOiAxMDAsXG4gICAgICBvbkNvbXBsZXRlOiAoKSA9PiB7XG4gICAgICAgIGlmIChjYWxsYmFjayAmJiB0eXBlb2YgY2FsbGJhY2sgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICBjYWxsYmFjayh0aWxlKVxuICAgICAgICB9XG4gICAgICAgIHRoaXMucmVzZXRGbGlwcGFnZSgpO1xuICAgICAgICB0aGlzLnR3ZWVucy5hZGQoe1xuICAgICAgICAgIHRhcmdldHM6IFt0aGlzLnBsYXllcl0sXG4gICAgICAgICAgeDogdGlsZS5waXhlbFggKyA4LFxuICAgICAgICAgIHk6IHRpbGUucGl4ZWxZICsgNyxcbiAgICAgICAgICBvbkNvbXBsZXRlOiAoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnR3ZWVucy5hZGQoe1xuICAgICAgICAgICAgICB0YXJnZXRzOiBbdGhpcy5wbGF5ZXJdLFxuICAgICAgICAgICAgICBhbHBoYToge1xuICAgICAgICAgICAgICAgIGZyb206IDAsXG4gICAgICAgICAgICAgICAgdG86IDEsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIG9uQ29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnBsYXllci5ib2R5LnNldEFsbG93R3Jhdml0eSh0cnVlKTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbG9jYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB0aGlzLmNoZWNrcG9pbnQgPSB0aWxlO1xuICAgICAgICAgICAgICAgIGlmIChjYWxsYmFjazIgJiYgdHlwZW9mIGNhbGxiYWNrMiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgY2FsbGJhY2syKHRpbGUpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfSlcbiAgfVxuICBcbiAgcHJpdmF0ZSBwaWNrdXBJdGVtKGl0ZW06IG51bWJlciwgdGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpIHtcbiAgICB0aGlzLmFjdGlvbnNMYXllci5wdXRUaWxlQXQoQkxBTkssIHRpbGUueCwgdGlsZS55KTtcbiAgICB0aGlzLmV2ZW50cy5lbWl0KCdwaWNrdXAnLCBpdGVtKVxuICAgIHRoaXMuaXRlbXMucHVzaChpdGVtKVxuICAgIHRoaXMuY2hlY2twb2ludCA9IHRpbGU7XG4gIH1cbiAgXG4gIHByaXZhdGUgcmV2aXZlKCkge1xuICAgIHRoaXMucmVsb2NhdGUoXG4gICAgICB0aGlzLmNoZWNrcG9pbnQsXG4gICAgICAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0RnJhbWUoQUxJVkUpO1xuICAgICAgfSxcbiAgICAgICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICB0aGlzLmlzRGVhZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIClcbiAgfVxuICBcbiAgcHJpdmF0ZSByZXNldEZsaXBwYWdlKCkge1xuICAgIHRoaXMuZGlyZWN0aW9uID0gMDtcbiAgICB0aGlzLnNldEdyYXZpdHkoKTtcbiAgICB0aGlzLmlzRmxpcHBlZCA9IGZhbHNlO1xuICAgIHRoaXMucGxheWVyLnNldEZsaXBYKGZhbHNlKTtcbiAgICB0aGlzLnBsYXllci5zZXRGbGlwWShmYWxzZSk7XG4gICAgdGhpcy5wbGF5ZXIuc2V0QW5nbGUoMCk7XG4gIH1cbiAgXG4gIHB1YmxpYyBraWxsUGxheWVyKCkge1xuICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KDAsIDApXG4gICAgdGhpcy5wbGF5ZXIuYm9keS5zZXRBbGxvd0dyYXZpdHkoZmFsc2UpXG4gICAgdGhpcy5wbGF5ZXIuYW5pbXMuc3RvcCgpXG4gICAgdGhpcy5wbGF5ZXIuc2V0RnJhbWUoREVBRClcbiAgICB0aGlzLmlzRGVhZCA9IHRydWVcbiAgICB0aGlzLnRpbWUuZGVsYXllZENhbGwoMTAwMCwgdGhpcy5yZXZpdmUsIFtdLCB0aGlzKVxuICB9XG59XG5cbnR5cGUgQ29uZmlnID0ge1xuICBncmF2aXR5OiBudW1iZXI7XG4gIHNwZWVkOiBudW1iZXI7XG4gIGdyYXZpdHlEaXJlY3Rpb246IG51bWJlcjtcbiAganVtcEZvcmNlOiBudW1iZXI7XG59IiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgKiBhcyBTdG9yZSBmcm9tICdzdG9yZSc7XG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdnYW1lLW9iamVjdHMnO1xuaW1wb3J0IHsgQ09MT1VSUywgQkxBTksgfSBmcm9tICdjb25zdGFudHMnO1xuXG5jb25zdCBmb250U3R5bGUgPSB7XG4gIGZpbGw6IENPTE9VUlMubWFyb29uLnN0cmluZyxcbiAgZm9udEZhbWlseTogJ2tlbm55MWJpdCcsXG4gIGFsaWduOiAnY2VudGVyJyxcbn1cbmNvbnN0IHNjZW5lQ29uZmlnOiBQaGFzZXIuVHlwZXMuU2NlbmVzLlNldHRpbmdzQ29uZmlnID0ge1xuICBhY3RpdmU6IGZhbHNlLFxuICB2aXNpYmxlOiBmYWxzZSxcbiAga2V5OiAnSFVEJyxcbn07XG5cbmV4cG9ydCBjbGFzcyBIVURTY2VuZSBleHRlbmRzIFBoYXNlci5TY2VuZSB7XG4gIHRpbWVUZXh0OiBQaGFzZXIuR2FtZU9iamVjdHMuVGV4dDtcbiAgbWF4VGltZTogbnVtYmVyO1xuICB0aW1lVGl0bGU6IFBoYXNlci5HYW1lT2JqZWN0cy5UZXh0O1xuICBpdGVtczogQXJyYXk8bnVtYmVyPjtcbiAgbWFwOiBQaGFzZXIuVGlsZW1hcHMuVGlsZW1hcDtcbiAgdGlsZXM6IFBoYXNlci5UaWxlbWFwcy5UaWxlc2V0O1xuICB0aW1lZEV2ZW50OiBQaGFzZXIuVGltZS5UaW1lckV2ZW50O1xuICB0aW1lcjogbnVtYmVyO1xuICBjb21wbGV0ZWRUZXh0OiBQaGFzZXIuR2FtZU9iamVjdHMuVGV4dDtcbiAgbGV2ZWw6IG51bWJlcjtcbiAgbmV4dExldmVsQnV0dG9uOiBCdXR0b247XG4gIHRoYW5reW91VGV4dDogR2FtZU9iamVjdCB8IEdyb3VwO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihzY2VuZUNvbmZpZyk7ICBcbiAgfVxuICBcbiAgcHVibGljIGluaXQoeyBsZXZlbCB9OiB7XG4gICAgbGV2ZWw6IG51bWJlcjtcbiAgfSkge1xuICAgIHRoaXMubGV2ZWwgPSBsZXZlbDtcbiAgICB0aGlzLnRpbWVyID0gMDtcbiAgfVxuICBcbiAgLyoqXG4gICAqIGNyZWF0ZVxuICAgKi9cbiAgcHVibGljIGNyZWF0ZSgpIHtcbiAgICBjb25zdCB7IEVOVEVSIH0gPSBQaGFzZXIuSW5wdXQuS2V5Ym9hcmQuS2V5Q29kZXM7XG4gICAgY29uc3QgZW50ZXJLZXkgPSB0aGlzLmlucHV0LmtleWJvYXJkLmFkZEtleShFTlRFUik7XG4gICAgXG4gICAgdGhpcy5pdGVtcyA9IFtdXG4gICAgdGhpcy5tYXAgPSB0aGlzLm1ha2UudGlsZW1hcCh7IGtleTogYG1hcCR7dGhpcy5sZXZlbH1gIH0pO1xuICAgIHRoaXMudGlsZXMgPSB0aGlzLm1hcC5hZGRUaWxlc2V0SW1hZ2UoJ3RpbGVzJyk7XG4gICAgY29uc3QgaHVkR3JhcGhpY3MgPSB0aGlzLmFkZC5ncmFwaGljcyh7XG4gICAgICBmaWxsU3R5bGU6IHtcbiAgICAgICAgYWxwaGE6IDAuOSxcbiAgICAgICAgY29sb3I6IENPTE9VUlMud2hpdGUubnVtYmVyXG4gICAgICB9LFxuICAgIH0pLnNldFNjcm9sbEZhY3RvcigwKTtcbiAgICBjb25zdCBpdGVtR3JhcGhpY3MgPSB0aGlzLmFkZC5ncmFwaGljcyh7XG4gICAgICBmaWxsU3R5bGU6IHtcbiAgICAgICAgY29sb3I6IENPTE9VUlMubWFyb29uLm51bWJlclxuICAgICAgfVxuICAgIH0pXG4gICAgY29uc3QgaHVkQmcgPSBuZXcgUGhhc2VyLkdlb20uUmVjdGFuZ2xlKDY1MCwgMCwgMTUwLCA2MDApXG4gICAgaHVkR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShodWRCZylcbiAgICB0aGlzLnRpbWVUaXRsZSA9IHRoaXMuYWRkLnRleHQoNjcwLCAxMCwgJyB0aW1lJywgZm9udFN0eWxlKVxuICAgIHRoaXMudGltZVRleHQgPSB0aGlzLmFkZC50ZXh0KDY3MCwgNTAsICcnLCBmb250U3R5bGUpXG5cbiAgICB0aGlzLmNvbXBsZXRlZFRleHQgPSB0aGlzLmFkZC50ZXh0KDQwMCwgMzAwLCAnIGxldmVsIGNvbXBsZXRlZCEnLCB7XG4gICAgICAuLi5mb250U3R5bGUsXG4gICAgICBmaWxsOiBDT0xPVVJTLmdyZWVuLnN0cmluZyxcbiAgICB9KS5zZXRPcmlnaW4oMC41KS5zZXRBbHBoYSgwKVxuICAgIHRoaXMudGhhbmt5b3VUZXh0ID0gdGhpcy5hZGQudGV4dCg0MDAsIDM1MCwgJyB0aGFuayB5b3UgZm9yIHBsYXlpbmcgbXkgZ2FtZScsIHtcbiAgICAgIC4uLmZvbnRTdHlsZSxcbiAgICAgIGZpbGw6IENPTE9VUlMuZ3JlZW4uc3RyaW5nLFxuICAgIH0pLnNldE9yaWdpbigwLjUpLnNldEFscGhhKDApXG4gICAgdGhpcy5uZXh0TGV2ZWxCdXR0b24gPSBuZXcgQnV0dG9uKHRoaXMsIDQwMCwgMzUwLCAnIG5leHQgbGV2ZWwgLSBoaXQgZW50ZXInLCB7XG4gICAgICBmaWxsOiBDT0xPVVJTLndoaXRlLnN0cmluZyxcbiAgICAgIGZvbnRGYW1pbHk6ICdrZW5ueTFiaXQnLFxuICAgICAgYWxpZ246ICdjZW50ZXInLFxuICAgIH0sIHtcbiAgICAgIHBvaW50ZXJ1cDogKCkgPT4gdGhpcy5uZXh0TGV2ZWwoKSxcbiAgICB9KS5zZXRPcmlnaW4oMC41KTtcbiAgICBjb25zdCBzbG90MSA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNjcwLCAxNTAsIDUwLCA1MClcbiAgICBjb25zdCBzbG90MiA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNzMwLCAxNTAsIDUwLCA1MClcbiAgICBjb25zdCBzbG90MyA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNjcwLCAyMTAsIDUwLCA1MClcbiAgICBjb25zdCBzbG90NCA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNzMwLCAyMTAsIDUwLCA1MClcbiAgICBjb25zdCBzbG90NSA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNjcwLCAyNzAsIDUwLCA1MClcbiAgICBjb25zdCBzbG90NiA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNzMwLCAyNzAsIDUwLCA1MClcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90MSlcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90MilcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90MylcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90NClcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90NSlcbiAgICBpdGVtR3JhcGhpY3MuZmlsbFJlY3RTaGFwZShzbG90NilcbiAgICBjb25zdCBpdGVtU3ByaXRlcyA9IFtcbiAgICAgIHRoaXMuYWRkLnNwcml0ZSg2OTUsIDE3NSwgJ3RpbGVzJywgQkxBTkspLnNldFNjYWxlKDIpLFxuICAgICAgdGhpcy5hZGQuc3ByaXRlKDc1NSwgMTc1LCAndGlsZXMnLCBCTEFOSykuc2V0U2NhbGUoMiksXG4gICAgICB0aGlzLmFkZC5zcHJpdGUoNjk1LCAyMzUsICd0aWxlcycsIEJMQU5LKS5zZXRTY2FsZSgyKSxcbiAgICAgIHRoaXMuYWRkLnNwcml0ZSg3NTUsIDIzNSwgJ3RpbGVzJywgQkxBTkspLnNldFNjYWxlKDIpLFxuICAgICAgdGhpcy5hZGQuc3ByaXRlKDY5NSwgMTk1LCAndGlsZXMnLCBCTEFOSykuc2V0U2NhbGUoMiksXG4gICAgICB0aGlzLmFkZC5zcHJpdGUoNzU1LCAxOTUsICd0aWxlcycsIEJMQU5LKS5zZXRTY2FsZSgyKSxcbiAgICBdXG4gICAgXG4gICAgdGhpcy5zY2VuZS5nZXQoJ0dhbWUnKS5ldmVudHMub24oJ3BpY2t1cCcsIChpdGVtOiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5pdGVtcy5sZW5ndGg7XG4gICAgICB0aGlzLml0ZW1zLnB1c2goaXRlbSlcbiAgICAgIGl0ZW1TcHJpdGVzW2luZGV4XS5zZXRGcmFtZShpdGVtIC0gMSlcbiAgICB9KTtcbiAgICBcbiAgICB0aGlzLnNjZW5lLmdldCgnR2FtZScpLmV2ZW50cy5vbignY29tcGxldGVkJywgKCkgPT4ge1xuICAgICAgU3RvcmUuc2V0KCdoaWdoZXN0TGV2ZWwnLCB0aGlzLmxldmVsICsgMSlcbiAgICAgIHRoaXMudGltZWRFdmVudC5kZXN0cm95KCk7XG4gICAgICB0aGlzLmNvbXBsZXRlZFRleHQuc2V0QWxwaGEoMSk7XG4gICAgICBpZiAodGhpcy5sZXZlbCA9PT0gOSkge1xuICAgICAgICB0aGlzLmFkZC5leGlzdGluZyh0aGlzLnRoYW5reW91VGV4dClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuYWRkLmV4aXN0aW5nKHRoaXMubmV4dExldmVsQnV0dG9uKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgXG4gICAgfSk7XG4gICAgXG4gICAgdGhpcy50aW1lZEV2ZW50ID0gdGhpcy50aW1lLmFkZEV2ZW50KHsgZGVsYXk6IDEwMDAsIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICB0aGlzLnRpbWVyICs9IDE7XG4gICAgICB0aGlzLnRpbWVUZXh0LnNldFRleHQoYCAke3RoaXMudGltZXJ9YClcbiAgICB9LCBjYWxsYmFja1Njb3BlOiB0aGlzLCBsb29wOiB0cnVlIH0pO1xuICAgIFxuICAgIGVudGVyS2V5Lm9uKFwiZG93blwiLCAoKSA9PiB0aGlzLm5leHRMZXZlbCgpKTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBuZXh0TGV2ZWwgKCkge1xuICAgIGNvbnN0IGxldmVsID0gdGhpcy5sZXZlbCArIDE7XG4gICAgY29uc3QgZ2FtZVNjZW5lID0gdGhpcy5zY2VuZS5nZXQoJ0dhbWUnKVxuICAgIGdhbWVTY2VuZS5ldmVudHMucmVtb3ZlTGlzdGVuZXIoJ3BpY2t1cCcpO1xuICAgIGdhbWVTY2VuZS5ldmVudHMucmVtb3ZlTGlzdGVuZXIoJ2NvbXBsZXRlZCcpO1xuICAgIGdhbWVTY2VuZS5zY2VuZS5yZXN0YXJ0KHsgbGV2ZWwgfSlcbiAgICB0aGlzLnNjZW5lLnJlc3RhcnQoeyBsZXZlbCB9KVxuICB9XG4gIFxufVxuIiwiaW1wb3J0IHsgQm9vdFNjZW5lIH0gZnJvbSAnLi9ib290JztcbmltcG9ydCB7IEdhbWVTY2VuZSB9IGZyb20gJy4vZ2FtZSc7XG5pbXBvcnQgeyBIVURTY2VuZSB9IGZyb20gJy4vaHVkJztcbmltcG9ydCB7IFRpdGxlU2NlbmUgfSBmcm9tICcuL3RpdGxlJztcblxuZXhwb3J0IGRlZmF1bHQgW1xuICBCb290U2NlbmUsXG4gIEdhbWVTY2VuZSxcbiAgSFVEU2NlbmUsXG4gIFRpdGxlU2NlbmUsXG5dO1xuIiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgKiBhcyBTdG9yZSBmcm9tICdzdG9yZSc7XG5pbXBvcnQgeyBDT0xPVVJTLCBaRVJPLCBDVVJTT1IsIEJMQU5LIH0gZnJvbSAnY29uc3RhbnRzJztcblxuY29uc3Qgc2NlbmVDb25maWc6IFBoYXNlci5UeXBlcy5TY2VuZXMuU2V0dGluZ3NDb25maWcgPSB7XG4gIGFjdGl2ZTogZmFsc2UsXG4gIHZpc2libGU6IGZhbHNlLFxuICBrZXk6ICdUaXRsZScsXG59O1xuXG5leHBvcnQgY2xhc3MgVGl0bGVTY2VuZSBleHRlbmRzIFBoYXNlci5TY2VuZSB7XG4gIGN1cnNvcnM6IFBoYXNlci5UeXBlcy5JbnB1dC5LZXlib2FyZC5DdXJzb3JLZXlzO1xuICBtYXA6IFBoYXNlci5UaWxlbWFwcy5UaWxlbWFwO1xuICB0aWxlczogUGhhc2VyLlRpbGVtYXBzLlRpbGVzZXQ7XG4gIGJnTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5TdGF0aWNUaWxlbWFwTGF5ZXI7XG4gIHNwaWtlc0xheWVyOiBQaGFzZXIuVGlsZW1hcHMuU3RhdGljVGlsZW1hcExheWVyO1xuICBhY3Rpb25zTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5EeW5hbWljVGlsZW1hcExheWVyO1xuICBjdXJzb3I6IFBoYXNlci5HYW1lT2JqZWN0cy5TcHJpdGU7XG4gIHNlbGVjdGVkOiBudW1iZXI7XG4gIG51bWJlckxheWVyOiBQaGFzZXIuVGlsZW1hcHMuU3RhdGljVGlsZW1hcExheWVyO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihzY2VuZUNvbmZpZyk7XG4gIH1cblxuICBwdWJsaWMgY3JlYXRlKCkge1xuICAgIGNvbnN0IHsgRU5URVIgfSA9IFBoYXNlci5JbnB1dC5LZXlib2FyZC5LZXlDb2RlcztcbiAgICBjb25zdCBlbnRlcktleSA9IHRoaXMuaW5wdXQua2V5Ym9hcmQuYWRkS2V5KEVOVEVSKTtcbiAgICBjb25zdCBoaWdoZXN0TGV2ZWwgPSBTdG9yZS5nZXQoJ2hpZ2hlc3RMZXZlbCcpIHx8IDA7XG4gICAgdGhpcy5zZWxlY3RlZCA9IGhpZ2hlc3RMZXZlbDtcbiAgICB0aGlzLmN1cnNvcnMgPSB0aGlzLmlucHV0LmtleWJvYXJkLmNyZWF0ZUN1cnNvcktleXMoKTtcbiAgICB0aGlzLm1hcCA9IHRoaXMubWFrZS50aWxlbWFwKHsga2V5OiBgdGl0bGVgIH0pO1xuICAgIHRoaXMudGlsZXMgPSB0aGlzLm1hcC5hZGRUaWxlc2V0SW1hZ2UoJ3RpbGVzJyk7XG4gICAgdGhpcy5iZ0xheWVyID0gdGhpcy5tYXAuY3JlYXRlU3RhdGljTGF5ZXIoJ0JhY2tncm91bmQnLCB0aGlzLnRpbGVzKVxuICAgIHRoaXMubnVtYmVyTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVTdGF0aWNMYXllcignTnVtYmVycycsIHRoaXMudGlsZXMpXG4gICAgdGhpcy5hY3Rpb25zTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVEeW5hbWljTGF5ZXIoJ0FjdGlvbnMnLCB0aGlzLnRpbGVzKVxuICAgIFxuICAgIGNvbnN0IGxldmVsVGlsZXM6IEFycmF5PFBoYXNlci5UaWxlbWFwcy5UaWxlPiA9IFtdXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgICBjb25zdCB0aWxlID0gdGhpcy5udW1iZXJMYXllci5maW5kQnlJbmRleChaRVJPICsgaSkgXG4gICAgICBpZiAoaSA8PSBoaWdoZXN0TGV2ZWwpIHtcbiAgICAgICAgdGhpcy5hY3Rpb25zTGF5ZXIucHV0VGlsZUF0KEJMQU5LLCB0aWxlLngsIHRpbGUueSk7XG4gICAgICB9XG4gICAgICBsZXZlbFRpbGVzLnB1c2godGlsZSlcbiAgICB9XG4gICAgY29uc3Qgc3RhcnRUaWxlID0gbGV2ZWxUaWxlc1t0aGlzLnNlbGVjdGVkXTtcbiAgICB0aGlzLmN1cnNvciA9IHRoaXMuYWRkLnNwcml0ZShzdGFydFRpbGUucGl4ZWxYLCBzdGFydFRpbGUucGl4ZWxZLCAndGlsZXMnLCBDVVJTT1IpLnNldE9yaWdpbigwLCAwKTtcbiAgICBcbiAgICB0aGlzLmNhbWVyYXMubWFpbi5zZXRCb3VuZHMoMCwgMCwgODAwLCA2MDApO1xuICAgIHRoaXMuY2FtZXJhcy5tYWluLnN0YXJ0Rm9sbG93KHRoaXMuY3Vyc29yKTtcbiAgICB0aGlzLmNhbWVyYXMubWFpbi5zZXRab29tKDIpO1xuXG4gICAgdGhpcy5jdXJzb3JzLmxlZnQub24oXCJkb3duXCIsICgpID0+IHtcbiAgICAgIHRoaXMuc2VsZWN0ZWQgPSB0aGlzLnNlbGVjdGVkID09PSAwID8gaGlnaGVzdExldmVsIDogdGhpcy5zZWxlY3RlZCAtIDE7XG4gICAgICB0aGlzLmN1cnNvci5zZXRYKGxldmVsVGlsZXNbdGhpcy5zZWxlY3RlZF0ucGl4ZWxYKVxuICAgIH0pXG4gICAgdGhpcy5jdXJzb3JzLnJpZ2h0Lm9uKFwiZG93blwiLCAoKSA9PiB7XG4gICAgICB0aGlzLnNlbGVjdGVkID0gdGhpcy5zZWxlY3RlZCA9PT0gaGlnaGVzdExldmVsID8gMCA6IHRoaXMuc2VsZWN0ZWQgKyAxO1xuICAgICAgdGhpcy5jdXJzb3Iuc2V0WChsZXZlbFRpbGVzW3RoaXMuc2VsZWN0ZWRdLnBpeGVsWClcbiAgICB9KVxuXG4gICAgZW50ZXJLZXkub24oXCJkb3duXCIsICgpID0+IHtcbiAgICAgIHRoaXMuc3RhcnRHYW1lKHRoaXMuc2VsZWN0ZWQpXG4gICAgfSk7XG4gIH1cbiAgXG4gIHByaXZhdGUgc3RhcnRHYW1lKGxldmVsOiBudW1iZXIpIHtcbiAgICB0aGlzLnNjZW5lLmxhdW5jaCgnR2FtZScsIHsgbGV2ZWwgfSkubGF1bmNoKCdIVUQnLCB7IGxldmVsIH0pLnN0b3AoKTtcbiAgfVxufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==