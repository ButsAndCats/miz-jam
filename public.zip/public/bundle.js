/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"main": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push(["./src/index.ts","vendors"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/constants/index.ts":
/*!********************************!*\
  !*** ./src/constants/index.ts ***!
  \********************************/
/*! exports provided: COLOURS, SIDE_UP, SIDE_RIGHT, SIDE_DOWN, SIDE_LEFT, DEAD, ALIVE, RUN_END, TOP_LEFT, TOP, TOP_RIGHT, LEFT, RIGHT, BOTTOM_LEFT, BOTTOM, BOTTOM_RIGHT, START_DOOR, UP_SPIKE, DOWN_SPIKE, LEFT_SPIKE, RIGHT_SPIKE, WIZARD, SPIDER, SPELL, BLANK, YELLOW_KEY, BLUE_KEY, RED_KEY, GREEN_KEY, BLUE_DOOR_LOCKED, BLUE_DOOR_EXIT, BLUE_DOOR_ENTRANCE, YELLOW_DOOR_LOCKED, YELLOW_DOOR_EXIT, YELLOW_DOOR_ENTRANCE, RED_DOOR_LOCKED, RED_DOOR_EXIT, RED_DOOR_ENTRANCE, GREEN_DOOR_LOCKED, GREEN_DOOR_EXIT, GREEN_DOOR_ENTRANCE, CURSOR, ZERO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COLOURS", function() { return COLOURS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_UP", function() { return SIDE_UP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_RIGHT", function() { return SIDE_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_DOWN", function() { return SIDE_DOWN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_LEFT", function() { return SIDE_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEAD", function() { return DEAD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ALIVE", function() { return ALIVE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RUN_END", function() { return RUN_END; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP_LEFT", function() { return TOP_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP", function() { return TOP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TOP_RIGHT", function() { return TOP_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEFT", function() { return LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RIGHT", function() { return RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM_LEFT", function() { return BOTTOM_LEFT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM", function() { return BOTTOM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BOTTOM_RIGHT", function() { return BOTTOM_RIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "START_DOOR", function() { return START_DOOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UP_SPIKE", function() { return UP_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DOWN_SPIKE", function() { return DOWN_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LEFT_SPIKE", function() { return LEFT_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RIGHT_SPIKE", function() { return RIGHT_SPIKE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WIZARD", function() { return WIZARD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPIDER", function() { return SPIDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SPELL", function() { return SPELL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLANK", function() { return BLANK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_KEY", function() { return YELLOW_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_KEY", function() { return BLUE_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_KEY", function() { return RED_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_KEY", function() { return GREEN_KEY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_LOCKED", function() { return BLUE_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_EXIT", function() { return BLUE_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BLUE_DOOR_ENTRANCE", function() { return BLUE_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_LOCKED", function() { return YELLOW_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_EXIT", function() { return YELLOW_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YELLOW_DOOR_ENTRANCE", function() { return YELLOW_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_LOCKED", function() { return RED_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_EXIT", function() { return RED_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RED_DOOR_ENTRANCE", function() { return RED_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_LOCKED", function() { return GREEN_DOOR_LOCKED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_EXIT", function() { return GREEN_DOOR_EXIT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GREEN_DOOR_ENTRANCE", function() { return GREEN_DOOR_ENTRANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CURSOR", function() { return CURSOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ZERO", function() { return ZERO; });
var COLOURS = {
    white: {
        string: '#CFC6B8',
        number: 0xCFC6B8
    },
    darkGray: {
        string: '#000000',
        number: 0x000000,
    },
    maroon: {
        string: '#4b2a3c',
        number: 0x4B2A3C,
    },
    green: {
        string: '#38D973',
        number: 0x38D973,
    }
};
var SIDE_UP = 0;
var SIDE_RIGHT = 1;
var SIDE_DOWN = 2;
var SIDE_LEFT = 3;
var DEAD = 407;
var ALIVE = 402;
var RUN_END = 406;
var TOP_LEFT = 19;
var TOP = 20;
var TOP_RIGHT = 21;
var LEFT = 67;
var RIGHT = 69;
var BOTTOM_LEFT = 115;
var BOTTOM = 116;
var BOTTOM_RIGHT = 117;
var START_DOOR = 489;
var UP_SPIKE = 23;
var DOWN_SPIKE = 25;
var LEFT_SPIKE = 74;
var RIGHT_SPIKE = 73;
var WIZARD = 80;
var SPIDER = 269;
var SPELL = 557;
var BLANK = 0;
var YELLOW_KEY = 561;
var BLUE_KEY = 562;
var RED_KEY = 563;
var GREEN_KEY = 564;
var BLUE_DOOR_LOCKED = 433;
var BLUE_DOOR_EXIT = 434;
var BLUE_DOOR_ENTRANCE = 435;
var YELLOW_DOOR_LOCKED = 436;
var YELLOW_DOOR_EXIT = 437;
var YELLOW_DOOR_ENTRANCE = 438;
var RED_DOOR_LOCKED = 439;
var RED_DOOR_EXIT = 440;
var RED_DOOR_ENTRANCE = 441;
var GREEN_DOOR_LOCKED = 442;
var GREEN_DOOR_EXIT = 443;
var GREEN_DOOR_ENTRANCE = 444;
var CURSOR = 713;
var ZERO = 852;


/***/ }),

/***/ "./src/game-objects/button.ts":
/*!************************************!*\
  !*** ./src/game-objects/button.ts ***!
  \************************************/
/*! exports provided: Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Button = (function (_super) {
    __extends(Button, _super);
    function Button(scene, x, y, text, style, callbacks) {
        var _this = _super.call(this, scene, x, y, text, style) || this;
        _this.defaultStyle = style;
        _this.setInteractive({ useHandCursor: true })
            .on('pointerover', function () {
            _this.buttonOver();
            if (callbacks && typeof callbacks.pointerover === 'function') {
                callbacks.pointerover();
            }
        })
            .on('pointerout', function () {
            _this.buttonOut();
            if (callbacks && typeof callbacks.pointerout === 'function') {
                callbacks.pointerout();
            }
        })
            .on('pointerdown', function () {
            _this.buttonDown();
            if (callbacks && typeof callbacks.pointerdown === 'function') {
                callbacks.pointerdown();
            }
        })
            .on('pointerup', function () {
            if (callbacks && typeof callbacks.pointerup === 'function') {
                callbacks.pointerup();
            }
        });
        return _this;
    }
    Button.prototype.buttonOver = function () {
        this.setStyle({
            fill: constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].green.string,
        });
    };
    Button.prototype.buttonOut = function () {
        this.setStyle(this.defaultStyle);
    };
    Button.prototype.buttonDown = function () {
        this.setStyle({
            fill: constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].green.string,
        });
    };
    return Button;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["GameObjects"].Text));



/***/ }),

/***/ "./src/game-objects/index.ts":
/*!***********************************!*\
  !*** ./src/game-objects/index.ts ***!
  \***********************************/
/*! exports provided: Button, Wizard, Spell, Spider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./button */ "./src/game-objects/button.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return _button__WEBPACK_IMPORTED_MODULE_0__["Button"]; });

/* harmony import */ var _wizard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wizard */ "./src/game-objects/wizard.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Wizard", function() { return _wizard__WEBPACK_IMPORTED_MODULE_1__["Wizard"]; });

/* harmony import */ var _spell__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./spell */ "./src/game-objects/spell.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spell", function() { return _spell__WEBPACK_IMPORTED_MODULE_2__["Spell"]; });

/* harmony import */ var _spider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./spider */ "./src/game-objects/spider.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Spider", function() { return _spider__WEBPACK_IMPORTED_MODULE_3__["Spider"]; });







/***/ }),

/***/ "./src/game-objects/spell.ts":
/*!***********************************!*\
  !*** ./src/game-objects/spell.ts ***!
  \***********************************/
/*! exports provided: Spell */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spell", function() { return Spell; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Spell = (function (_super) {
    __extends(Spell, _super);
    function Spell(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["SPELL"]) || this;
        _this.setOrigin(0, 0);
        var angle = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Angle.Between(_this.x, _this.y, scene.player.x, scene.player.y);
        _this.setRotation(angle - 3.92699);
        scene.physics.add.overlap(_this, scene.player, function (spell, tile) {
            if (scene.isDead || scene.relocating)
                return;
            scene.killPlayer();
        });
        scene.physics.add.collider(_this, scene.groundLayer, function (spell, tile) {
            spell.destroy();
        });
        return _this;
    }
    return Spell;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Physics"].Arcade.Sprite));



/***/ }),

/***/ "./src/game-objects/spider.ts":
/*!************************************!*\
  !*** ./src/game-objects/spider.ts ***!
  \************************************/
/*! exports provided: Spider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Spider", function() { return Spider; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var Spider = (function (_super) {
    __extends(Spider, _super);
    function Spider(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["SPIDER"] - 1) || this;
        _this.direction = 2;
        _this.setOrigin(0.5, 0.5);
        scene.physics.add.collider(_this, scene.groundLayer, function (spider, tile) {
            _this.direction = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Wrap(_this.direction + 1, 0, 4);
            spider.setAngle(spider.angle + 90);
            var directions = [
                function () { return spider.setVelocity(0, -100); },
                function () { return spider.setVelocity(100, 0); },
                function () { return spider.setVelocity(0, 100); },
                function () { return spider.setVelocity(-100, 0); },
            ];
            directions[_this.direction]();
        });
        scene.physics.add.overlap(_this, scene.player, function (spider, tile) {
            if (scene.isDead || scene.relocating) {
                return;
            }
            scene.killPlayer();
        });
        return _this;
    }
    return Spider;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Physics"].Arcade.Sprite));



/***/ }),

/***/ "./src/game-objects/wizard.ts":
/*!************************************!*\
  !*** ./src/game-objects/wizard.ts ***!
  \************************************/
/*! exports provided: Wizard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Wizard", function() { return Wizard; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
/* harmony import */ var _spell__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./spell */ "./src/game-objects/spell.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var Wizard = (function (_super) {
    __extends(Wizard, _super);
    function Wizard(scene, x, y, texture) {
        var _this = _super.call(this, scene, x, y, texture, constants__WEBPACK_IMPORTED_MODULE_1__["WIZARD"] - 1) || this;
        _this.setOrigin(0, 0);
        _this.shootingTimer = scene.time.addEvent({ delay: 1000, callback: function () {
                if (scene.isDead || scene.relocating)
                    return;
                var spell = new _spell__WEBPACK_IMPORTED_MODULE_2__["Spell"](scene, x, y, texture);
                scene.add.existing(spell);
                scene.physics.add.existing(spell);
                scene.physics.moveToObject(spell, scene.player);
                spell.body.setSize(2, 2, true);
            }, callbackScope: _this, loop: true });
        return _this;
    }
    return Wizard;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["GameObjects"].Sprite));



/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/*! exports provided: game */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "game", function() { return game; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var scenes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! scenes */ "./src/scenes/index.ts");


var config = {
    title: 'Miz jam',
    type: phaser__WEBPACK_IMPORTED_MODULE_0__["AUTO"],
    zoom: 2,
    scale: {
        parent: 'game',
        width: 800,
        height: 600,
        autoCenter: phaser__WEBPACK_IMPORTED_MODULE_0__["Scale"].CENTER_BOTH,
        mode: phaser__WEBPACK_IMPORTED_MODULE_0__["Scale"].FIT,
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: {
                y: 0
            },
        }
    },
    scene: scenes__WEBPACK_IMPORTED_MODULE_1__["default"],
    parent: 'game',
    backgroundColor: 0x4B2A3C,
};
var game = new phaser__WEBPACK_IMPORTED_MODULE_0__["Game"](config);


/***/ }),

/***/ "./src/scenes/boot.ts":
/*!****************************!*\
  !*** ./src/scenes/boot.ts ***!
  \****************************/
/*! exports provided: BootScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BootScene", function() { return BootScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var sceneConfig = {
    active: false,
    visible: false,
    key: 'Boot',
};
var BootScene = (function (_super) {
    __extends(BootScene, _super);
    function BootScene() {
        return _super.call(this, sceneConfig) || this;
    }
    BootScene.prototype.preload = function () {
        var _this = this;
        var progressBar = this.add.graphics();
        var progressBox = this.add.graphics();
        progressBox.fillStyle(_constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].darkGray.number, 0.8);
        progressBox.fillRect(240, 270, 320, 50);
        var _a = this.cameras.main, centerX = _a.centerX, centerY = _a.centerY;
        var loadingText = this.make.text({
            x: centerX,
            y: centerY,
            text: 'Loading...',
            style: {
                font: '20px monospace',
                fill: _constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].white.string
            }
        });
        loadingText.setOrigin(0.5, 0.5);
        this.load.on('progress', function (value) {
            progressBar.clear();
            progressBar.fillStyle(_constants__WEBPACK_IMPORTED_MODULE_1__["COLOURS"].white.number, 1);
            progressBar.fillRect(250, 280, 300 * value, 30);
        });
        this.load.on('fileprogress', function (file) {
            loadingText.setText(file.src);
        });
        this.load.on('complete', function () {
            progressBar.destroy();
            progressBox.destroy();
            loadingText.destroy();
            _this.scene.start('Title');
        });
        this.load.tilemapTiledJSON('title', './assets/title.json');
        this.load.tilemapTiledJSON('map0', './assets/level0.json');
        this.load.tilemapTiledJSON('map1', './assets/level1.json');
        this.load.tilemapTiledJSON('map2', './assets/level2.json');
        this.load.tilemapTiledJSON('map3', './assets/level3.json');
        this.load.tilemapTiledJSON('map4', './assets/level4.json');
        this.load.tilemapTiledJSON('map5', './assets/level5.json');
        this.load.spritesheet('tiles', './assets/tiles.png', {
            frameWidth: 16,
            frameHeight: 16,
        });
    };
    return BootScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/game.ts":
/*!****************************!*\
  !*** ./src/scenes/game.ts ***!
  \****************************/
/*! exports provided: GameScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GameScene", function() { return GameScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "./src/constants/index.ts");
/* harmony import */ var game_objects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! game-objects */ "./src/game-objects/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __rest = (undefined && undefined.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};



var sceneConfig = {
    active: false,
    visible: false,
    key: 'Game',
};
var GameScene = (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        return _super.call(this, sceneConfig) || this;
    }
    GameScene.prototype.init = function (_a) {
        var level = _a.level;
        this.level = level;
    };
    GameScene.prototype.preload = function () {
        this.isDead = false;
        this.config = {
            gravity: 1200,
            speed: 120,
            gravityDirection: 1,
            jumpForce: 255,
        };
        this.canFlipGravity = true;
        this.isFlipped = false;
        this.rotating = false;
        this.direction = _constants__WEBPACK_IMPORTED_MODULE_1__["SIDE_UP"];
        this.relocating = false;
        this.items = [];
    };
    GameScene.prototype.create = function () {
        var _this = this;
        var _a = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes, SPACE = _a.SPACE, E = _a.E;
        this.cursors = this.input.keyboard.createCursorKeys();
        var eKey = this.input.keyboard.addKey(E);
        var spaceKey = this.input.keyboard.addKey(SPACE);
        this.map = this.make.tilemap({ key: "map" + this.level });
        this.tiles = this.map.addTilesetImage('tiles');
        this.bgLayer = this.map.createStaticLayer('Background', this.tiles);
        this.groundLayer = this.map.createStaticLayer('Ground', this.tiles);
        this.spikesLayer = this.map.createDynamicLayer('Spikes', this.tiles);
        this.actionsLayer = this.map.createDynamicLayer('Actions', this.tiles);
        this.groundLayer.setCollisionByExclusion([0, 1]);
        this.physics.world.bounds.width = this.groundLayer.width;
        this.physics.world.bounds.height = this.groundLayer.height;
        var startTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["START_DOOR"]);
        var redDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"]);
        var blueDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"]);
        var yellowDoorExitTile = this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"]);
        this.checkpoint = startTile;
        this.player = this.physics.add.sprite(startTile.pixelX + 8, startTile.pixelY + 5, 'tiles', _constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"]);
        this.player.body.gravity.set(0, this.config.gravity);
        this.anims.create({
            key: 'running',
            frames: this.anims.generateFrameNumbers('tiles', { start: _constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"], end: _constants__WEBPACK_IMPORTED_MODULE_1__["RUN_END"] }),
            frameRate: 10,
            repeat: -1,
        });
        this.physics.add.collider(this.player, this.groundLayer, function (player, tile) {
            if (_this.isDead || _this.relocating) {
                return;
            }
            if (!_this.rotating) {
                _this.checkRotation(tile, player);
            }
            if (!_this.canFlipGravity) {
                _this.canFlipGravity = true;
            }
        }, function () {
            return !_this.isDead && !_this.relocating;
        });
        this.physics.add.overlap(this.player, this.spikesLayer, function (player, tile) {
            if (_this.isDead || _this.relocating) {
                return false;
            }
            _this.killPlayer();
        }, function (player, tile) {
            if (tile.index === 1 || _this.isDead || _this.relocating) {
                return false;
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["UP_SPIKE"]) {
                if (player.y > tile.pixelY - 4 && player.x >= tile.pixelX - 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["DOWN_SPIKE"]) {
                if (player.y < tile.pixelY + 15 && player.x >= tile.pixelX - 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT_SPIKE"]) {
                if (player.x >= tile.pixelX + 5) {
                    return true;
                }
            }
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT_SPIKE"]) {
                if (player.x <= tile.pixelX + 14) {
                    return true;
                }
            }
            return false;
        });
        this.physics.add.overlap(this.player, this.actionsLayer, function (_player, tile) {
            var _a;
            var actions = (_a = {},
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"]] = function (tile) {
                    _this.pickupItem(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"], tile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(redDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"]] = function (tile) {
                    var redDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"]);
                    _this.relocate(redDoorEntranceTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(yellowDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"]] = function (tile) {
                    var yellowDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"]);
                    _this.relocate(yellowDoorEntranceTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"]] = function (tile) {
                    _this.events.emit('completed');
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_LOCKED"]] = function (tile) {
                    if (_this.items.includes(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"])) {
                        _this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"], tile.x, tile.y);
                    }
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"]] = function (tile) {
                    _this.relocate(blueDoorExitTile);
                },
                _a[_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"]] = function (tile) {
                    var blueDoorEntranceTile = _this.actionsLayer.findByIndex(_constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"]);
                    _this.relocate(blueDoorEntranceTile);
                },
                _a);
            actions[tile.index](tile);
        }, function (_player, _a) {
            var index = _a.index;
            if (_this.isDead || _this.relocating) {
                return false;
            }
            if (!eKey.isDown) {
                return false;
            }
            var actions = [_constants__WEBPACK_IMPORTED_MODULE_1__["RED_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_KEY"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["RED_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["YELLOW_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["BLUE_DOOR_EXIT"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_LOCKED"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_ENTRANCE"], _constants__WEBPACK_IMPORTED_MODULE_1__["GREEN_DOOR_EXIT"]];
            return actions.includes(index);
        });
        spaceKey.on("down", function () { return _this.flip(); });
        this.cameras.main.startFollow(this.player);
        this.cameras.main.setZoom(2);
        this.spikesLayer.forEachTile(function (tile) {
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["WIZARD"]) {
                _this.spikesLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
                var wizard = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Wizard"](_this, tile.pixelX, tile.pixelY, 'tiles');
                _this.add.existing(wizard);
            }
            ;
            if (tile.index === _constants__WEBPACK_IMPORTED_MODULE_1__["SPIDER"]) {
                _this.spikesLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
                var spider = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Spider"](_this, tile.pixelX, tile.pixelY, 'tiles');
                _this.add.existing(spider);
                _this.physics.add.existing(spider);
                spider.setVelocityY(100);
            }
        });
    };
    GameScene.prototype.update = function () {
        if (this.isDead || this.relocating) {
            return;
        }
        if (this.cursors.up.isDown) {
            this.jump();
        }
        if (this.cursors.left.isDown && !this.cursors.right.isDown) {
            this.player.anims.play('running', true);
            if (!this.isFlipped) {
                this.moveCounterClockwise();
            }
            else {
                this.moveClockwise();
            }
        }
        else if (this.cursors.right.isDown && !this.cursors.left.isDown) {
            this.player.anims.play('running', true);
            if (this.isFlipped) {
                this.moveCounterClockwise();
            }
            else {
                this.moveClockwise();
            }
        }
        else {
            this.stopMoving();
        }
        this.physics.world.wrap(this.player);
    };
    GameScene.prototype.moveCounterClockwise = function () {
        var _this = this;
        this.player.setFlipX(!this.isFlipped);
        var directions = [
            function () {
                _this.player.setVelocity(-_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, -_this.config.speed);
            },
            function () {
                _this.player.setVelocity(_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(-_this.player.body.velocity.x, _this.config.speed);
            },
        ];
        directions[this.direction]();
    };
    GameScene.prototype.moveClockwise = function () {
        var _this = this;
        this.player.setFlipX(this.isFlipped);
        var directions = [
            function () {
                _this.player.setVelocity(_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, _this.config.speed);
            },
            function () {
                _this.player.setVelocity(-_this.config.speed, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, -_this.config.speed);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.stopMoving = function () {
        var _this = this;
        this.player.anims.stop();
        var directions = [
            function () {
                _this.player.setVelocity(0, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, 0);
            },
            function () {
                _this.player.setVelocity(0, _this.player.body.velocity.y);
            },
            function () {
                _this.player.setVelocity(_this.player.body.velocity.x, 0);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.jump = function () {
        var _this = this;
        var directions = [
            function () {
                if (_this.player.body.blocked.down) {
                    _this.player.setVelocityY(-_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.left) {
                    _this.player.setVelocityX(_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.up) {
                    _this.player.setVelocityY(_this.config.jumpForce);
                }
            },
            function () {
                if (_this.player.body.blocked.right) {
                    _this.player.setVelocityX(-_this.config.jumpForce);
                }
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.checkRotation = function (_a, _b) {
        var _this = this;
        var index = _a.index, tile = __rest(_a, ["index"]);
        var x = _b.x, y = _b.y, player = __rest(_b, ["x", "y"]);
        if (this.rotating)
            return;
        var directions = [
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_RIGHT"] && x >= tile.pixelX + 20 && player.body.velocity.x > 0) {
                    _this.handleRotation(1, x + 4, y + 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_LEFT"] && x <= tile.pixelX && player.body.velocity.x < 0) {
                    _this.handleRotation(-1, x - 8, y + 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT"]) {
                    _this.handleRotation(1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT"]) {
                    _this.handleRotation(-1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_RIGHT"] && y >= tile.pixelY + 20 && player.body.velocity.y > 0) {
                    _this.handleRotation(1, x - 8, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_RIGHT"] && y <= tile.pixelY && player.body.velocity.y < 0) {
                    _this.handleRotation(-1, x - 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM"]) {
                    _this.handleRotation(1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP"]) {
                    _this.handleRotation(-1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_LEFT"] && x <= tile.pixelX && player.body.velocity.x < 0) {
                    _this.handleRotation(1, x - 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_RIGHT"] && x >= tile.pixelX + 20 && player.body.velocity.x > 0) {
                    _this.handleRotation(-1, x, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["RIGHT"]) {
                    _this.handleRotation(-1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["LEFT"]) {
                    _this.handleRotation(1, x, y);
                }
            },
            function () {
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP_LEFT"] && y <= tile.pixelY && player.body.velocity.y < 0) {
                    _this.handleRotation(1, x + 8, y - 8);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM_LEFT"] && y >= tile.pixelY + 20 && player.body.velocity.y > 0) {
                    _this.handleRotation(-1, x + 8, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["BOTTOM"] && !_this.rotating) {
                    _this.handleRotation(-1, x, y);
                }
                if (index === _constants__WEBPACK_IMPORTED_MODULE_1__["TOP"] && !_this.rotating) {
                    _this.handleRotation(1, x, y);
                }
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.handleRotation = function (delta, x, y) {
        var _this = this;
        this.player.body.setAllowGravity(false);
        this.player.setVelocity(0, 0);
        this.rotating = true;
        this.tweens.add({
            targets: [this.player],
            angle: this.player.angle + 90 * delta,
            x: x,
            y: y,
            duration: 200,
            onComplete: function () {
                _this.rotating = false;
                _this.player.body.setAllowGravity(true);
                _this.direction = phaser__WEBPACK_IMPORTED_MODULE_0__["Math"].Wrap(_this.direction + delta, 0, 4);
                _this.setGravity();
            }
        });
    };
    GameScene.prototype.setGravity = function () {
        var _this = this;
        var directions = [
            function () {
                _this.player.setGravity(0, _this.config.gravity);
            },
            function () {
                _this.player.setGravity(-_this.config.gravity, 0);
            },
            function () {
                _this.player.setGravity(0, -_this.config.gravity);
            },
            function () {
                _this.player.setGravity(_this.config.gravity, 0);
            }
        ];
        directions[this.direction]();
    };
    GameScene.prototype.flip = function () {
        if (this.isDead) {
            return;
        }
        if (this.canFlipGravity) {
            this.canFlipGravity = false;
            if (this.direction === 0 || this.direction === 2) {
                this.player.body.gravity.y *= -1;
                this.player.body.gravity.x = 0;
            }
            else {
                this.player.body.gravity.x *= -1;
                this.player.body.gravity.y = 0;
            }
            this.player.setFlipY(!this.isFlipped);
            var directions = [2, 3, 0, 1];
            this.direction = directions[this.direction];
            this.isFlipped = !this.isFlipped;
        }
    };
    GameScene.prototype.relocate = function (tile, callback, callback2) {
        var _this = this;
        this.relocating = true;
        this.player.body.setAllowGravity(false);
        this.tweens.add({
            targets: [this.player],
            alpha: {
                from: 1,
                to: 0
            },
            duration: 100,
            onComplete: function () {
                if (callback && typeof callback === 'function') {
                    callback(tile);
                }
                _this.resetFlippage();
                _this.tweens.add({
                    targets: [_this.player],
                    x: tile.pixelX + 8,
                    y: tile.pixelY + 7,
                    onComplete: function () {
                        _this.tweens.add({
                            targets: [_this.player],
                            alpha: {
                                from: 0,
                                to: 1,
                            },
                            onComplete: function () {
                                _this.player.body.setAllowGravity(true);
                                _this.relocating = false;
                                _this.checkpoint = tile;
                                if (callback2 && typeof callback2 === 'function') {
                                    callback2(tile);
                                }
                            }
                        });
                    }
                });
            }
        });
    };
    GameScene.prototype.pickupItem = function (item, tile) {
        this.actionsLayer.putTileAt(_constants__WEBPACK_IMPORTED_MODULE_1__["BLANK"], tile.x, tile.y);
        this.events.emit('pickup', item);
        this.items.push(item);
        this.checkpoint = tile;
    };
    GameScene.prototype.revive = function () {
        var _this = this;
        this.relocate(this.checkpoint, function (tile) {
            _this.player.setFrame(_constants__WEBPACK_IMPORTED_MODULE_1__["ALIVE"]);
        }, function (tile) {
            _this.isDead = false;
        });
    };
    GameScene.prototype.resetFlippage = function () {
        this.direction = 0;
        this.setGravity();
        this.isFlipped = false;
        this.player.setFlipX(false);
        this.player.setFlipY(false);
        this.player.setAngle(0);
    };
    GameScene.prototype.killPlayer = function () {
        this.player.setVelocity(0, 0);
        this.player.body.setAllowGravity(false);
        this.player.anims.stop();
        this.player.setFrame(_constants__WEBPACK_IMPORTED_MODULE_1__["DEAD"]);
        this.isDead = true;
        this.time.delayedCall(1000, this.revive, [], this);
    };
    return GameScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/hud.ts":
/*!***************************!*\
  !*** ./src/scenes/hud.ts ***!
  \***************************/
/*! exports provided: HUDScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HUDScene", function() { return HUDScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! store */ "./node_modules/store/dist/store.legacy.js");
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(store__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var game_objects__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! game-objects */ "./src/game-objects/index.ts");
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};




var fontStyle = {
    fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].maroon.string,
    fontFamily: 'kenny1bit',
    align: 'center',
};
var sceneConfig = {
    active: false,
    visible: false,
    key: 'HUD',
};
var HUDScene = (function (_super) {
    __extends(HUDScene, _super);
    function HUDScene() {
        return _super.call(this, sceneConfig) || this;
    }
    HUDScene.prototype.init = function (_a) {
        var level = _a.level;
        this.level = level;
        this.timer = 0;
    };
    HUDScene.prototype.create = function () {
        var _this = this;
        var ENTER = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes.ENTER;
        var enterKey = this.input.keyboard.addKey(ENTER);
        this.items = [];
        this.map = this.make.tilemap({ key: "map" + this.level });
        this.tiles = this.map.addTilesetImage('tiles');
        var hudGraphics = this.add.graphics({
            fillStyle: {
                alpha: 0.9,
                color: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].white.number
            },
        }).setScrollFactor(0);
        var itemGraphics = this.add.graphics({
            fillStyle: {
                color: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].maroon.number
            }
        });
        var hudBg = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(650, 0, 150, 600);
        hudGraphics.fillRectShape(hudBg);
        this.timeTitle = this.add.text(670, 10, ' time', fontStyle);
        this.timeText = this.add.text(670, 50, '', fontStyle);
        this.completedText = this.add.text(400, 300, ' level completed!', __assign(__assign({}, fontStyle), { fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].green.string })).setOrigin(0.5).setAlpha(0);
        this.thankyouText = this.add.text(400, 350, ' thank you for playing my game', __assign(__assign({}, fontStyle), { fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].green.string })).setOrigin(0.5).setAlpha(0);
        this.nextLevelButton = new game_objects__WEBPACK_IMPORTED_MODULE_2__["Button"](this, 400, 350, ' next level - hit enter', {
            fill: constants__WEBPACK_IMPORTED_MODULE_3__["COLOURS"].white.string,
            fontFamily: 'kenny1bit',
            align: 'center',
        }, {
            pointerup: function () { return _this.nextLevel(); },
        }).setOrigin(0.5);
        var slot1 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 150, 50, 50);
        var slot2 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 150, 50, 50);
        var slot3 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 210, 50, 50);
        var slot4 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 210, 50, 50);
        var slot5 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(670, 270, 50, 50);
        var slot6 = new phaser__WEBPACK_IMPORTED_MODULE_0__["Geom"].Rectangle(730, 270, 50, 50);
        itemGraphics.fillRectShape(slot1);
        itemGraphics.fillRectShape(slot2);
        itemGraphics.fillRectShape(slot3);
        itemGraphics.fillRectShape(slot4);
        itemGraphics.fillRectShape(slot5);
        itemGraphics.fillRectShape(slot6);
        var itemSprites = [
            this.add.sprite(695, 175, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 175, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(695, 235, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 235, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(695, 195, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
            this.add.sprite(755, 195, 'tiles', constants__WEBPACK_IMPORTED_MODULE_3__["BLANK"]).setScale(2),
        ];
        this.scene.get('Game').events.on('pickup', function (item) {
            var index = _this.items.length;
            _this.items.push(item);
            itemSprites[index].setFrame(item - 1);
        });
        this.scene.get('Game').events.on('completed', function () {
            store__WEBPACK_IMPORTED_MODULE_1__["set"]('highestLevel', _this.level + 1);
            _this.timedEvent.destroy();
            _this.completedText.setAlpha(1);
            if (_this.level === 9) {
                _this.add.existing(_this.thankyouText);
            }
            else {
                _this.add.existing(_this.nextLevelButton);
            }
        });
        this.timedEvent = this.time.addEvent({ delay: 1000, callback: function () {
                _this.timer += 1;
                _this.timeText.setText(" " + _this.timer);
            }, callbackScope: this, loop: true });
        enterKey.on("down", function () { return _this.nextLevel(); });
    };
    HUDScene.prototype.nextLevel = function () {
        var level = this.level + 1;
        var gameScene = this.scene.get('Game');
        gameScene.events.removeListener('pickup');
        gameScene.events.removeListener('completed');
        gameScene.scene.restart({ level: level });
        this.scene.restart({ level: level });
    };
    return HUDScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ }),

/***/ "./src/scenes/index.ts":
/*!*****************************!*\
  !*** ./src/scenes/index.ts ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _boot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./boot */ "./src/scenes/boot.ts");
/* harmony import */ var _game__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./game */ "./src/scenes/game.ts");
/* harmony import */ var _hud__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./hud */ "./src/scenes/hud.ts");
/* harmony import */ var _title__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./title */ "./src/scenes/title.ts");




/* harmony default export */ __webpack_exports__["default"] = ([
    _boot__WEBPACK_IMPORTED_MODULE_0__["BootScene"],
    _game__WEBPACK_IMPORTED_MODULE_1__["GameScene"],
    _hud__WEBPACK_IMPORTED_MODULE_2__["HUDScene"],
    _title__WEBPACK_IMPORTED_MODULE_3__["TitleScene"],
]);


/***/ }),

/***/ "./src/scenes/title.ts":
/*!*****************************!*\
  !*** ./src/scenes/title.ts ***!
  \*****************************/
/*! exports provided: TitleScene */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TitleScene", function() { return TitleScene; });
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! phaser */ "./node_modules/phaser/dist/phaser.js");
/* harmony import */ var phaser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(phaser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! store */ "./node_modules/store/dist/store.legacy.js");
/* harmony import */ var store__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(store__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! constants */ "./src/constants/index.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var sceneConfig = {
    active: false,
    visible: false,
    key: 'Title',
};
var TitleScene = (function (_super) {
    __extends(TitleScene, _super);
    function TitleScene() {
        return _super.call(this, sceneConfig) || this;
    }
    TitleScene.prototype.create = function () {
        var _this = this;
        var ENTER = phaser__WEBPACK_IMPORTED_MODULE_0__["Input"].Keyboard.KeyCodes.ENTER;
        var enterKey = this.input.keyboard.addKey(ENTER);
        var highestLevel = store__WEBPACK_IMPORTED_MODULE_1__["get"]('highestLevel') || 0;
        this.selected = highestLevel;
        this.cursors = this.input.keyboard.createCursorKeys();
        this.map = this.make.tilemap({ key: "title" });
        this.tiles = this.map.addTilesetImage('tiles');
        this.bgLayer = this.map.createStaticLayer('Background', this.tiles);
        this.numberLayer = this.map.createStaticLayer('Numbers', this.tiles);
        this.actionsLayer = this.map.createDynamicLayer('Actions', this.tiles);
        var levelTiles = [];
        for (var i = 0; i < 10; i++) {
            var tile = this.numberLayer.findByIndex(constants__WEBPACK_IMPORTED_MODULE_2__["ZERO"] + i);
            if (i <= highestLevel) {
                this.actionsLayer.putTileAt(constants__WEBPACK_IMPORTED_MODULE_2__["BLANK"], tile.x, tile.y);
            }
            levelTiles.push(tile);
        }
        var startTile = levelTiles[this.selected];
        this.cursor = this.add.sprite(startTile.pixelX, startTile.pixelY, 'tiles', constants__WEBPACK_IMPORTED_MODULE_2__["CURSOR"]).setOrigin(0, 0);
        this.cameras.main.setBounds(0, 0, 800, 600);
        this.cameras.main.startFollow(this.cursor);
        this.cameras.main.setZoom(2);
        this.cursors.left.on("down", function () {
            _this.selected = _this.selected === 0 ? highestLevel : _this.selected - 1;
            _this.cursor.setX(levelTiles[_this.selected].pixelX);
        });
        this.cursors.right.on("down", function () {
            _this.selected = _this.selected === highestLevel ? 0 : _this.selected + 1;
            _this.cursor.setX(levelTiles[_this.selected].pixelX);
        });
        enterKey.on("down", function () {
            _this.startGame(_this.selected);
        });
    };
    TitleScene.prototype.startGame = function (level) {
        this.scene.launch('Game', { level: level }).launch('HUD', { level: level }).stop();
    };
    return TitleScene;
}(phaser__WEBPACK_IMPORTED_MODULE_0__["Scene"]));



/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbnN0YW50cy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvZ2FtZS1vYmplY3RzL2J1dHRvbi50cyIsIndlYnBhY2s6Ly8vLi9zcmMvZ2FtZS1vYmplY3RzL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9nYW1lLW9iamVjdHMvc3BlbGwudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2dhbWUtb2JqZWN0cy9zcGlkZXIudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2dhbWUtb2JqZWN0cy93aXphcmQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2luZGV4LnRzIiwid2VicGFjazovLy8uL3NyYy9zY2VuZXMvYm9vdC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NlbmVzL2dhbWUudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjZW5lcy9odWQudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NjZW5lcy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvc2NlbmVzL3RpdGxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLFFBQVEsb0JBQW9CO1FBQzVCO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsaUJBQWlCLDRCQUE0QjtRQUM3QztRQUNBO1FBQ0Esa0JBQWtCLDJCQUEyQjtRQUM3QztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLGdCQUFnQix1QkFBdUI7UUFDdkM7OztRQUdBO1FBQ0E7UUFDQTtRQUNBOzs7Ozs7Ozs7Ozs7O0FDdkpBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxJQUFNLE9BQU8sR0FBRztJQUNyQixLQUFLLEVBQUU7UUFDTCxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsUUFBUTtLQUNqQjtJQUNELFFBQVEsRUFBRTtRQUNSLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLE1BQU0sRUFBRSxRQUFRO0tBQ2pCO0lBQ0QsTUFBTSxFQUFFO1FBQ04sTUFBTSxFQUFFLFNBQVM7UUFDakIsTUFBTSxFQUFFLFFBQVE7S0FDakI7SUFDRCxLQUFLLEVBQUU7UUFDTCxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsUUFBUTtLQUNqQjtDQUNGO0FBRU0sSUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLElBQU0sVUFBVSxHQUFHLENBQUMsQ0FBQztBQUNyQixJQUFNLFNBQVMsR0FBRyxDQUFDLENBQUM7QUFDcEIsSUFBTSxTQUFTLEdBQUcsQ0FBQztBQUVuQixJQUFNLElBQUksR0FBRyxHQUFHLENBQUM7QUFDakIsSUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQ2xCLElBQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQztBQUVwQixJQUFNLFFBQVEsR0FBRyxFQUFFLENBQUM7QUFDcEIsSUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDO0FBQ2YsSUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQ3JCLElBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUNoQixJQUFNLEtBQUssR0FBRyxFQUFFLENBQUM7QUFDakIsSUFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDO0FBQ3hCLElBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQztBQUNuQixJQUFNLFlBQVksR0FBRyxHQUFHLENBQUM7QUFFekIsSUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDO0FBRXZCLElBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztBQUNwQixJQUFNLFVBQVUsR0FBRyxFQUFFLENBQUM7QUFDdEIsSUFBTSxVQUFVLEdBQUcsRUFBRSxDQUFDO0FBQ3RCLElBQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUN2QixJQUFNLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEIsSUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDO0FBQ25CLElBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUVsQixJQUFNLEtBQUssR0FBRyxDQUFDLENBQUM7QUFDaEIsSUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDO0FBQ3ZCLElBQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQztBQUNyQixJQUFNLE9BQU8sR0FBRyxHQUFHLENBQUM7QUFDcEIsSUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3RCLElBQU0sZ0JBQWdCLEdBQUcsR0FBRyxDQUFDO0FBQzdCLElBQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQztBQUMzQixJQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQztBQUMvQixJQUFNLGtCQUFrQixHQUFHLEdBQUcsQ0FBQztBQUMvQixJQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQztBQUM3QixJQUFNLG9CQUFvQixHQUFHLEdBQUcsQ0FBQztBQUNqQyxJQUFNLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFDNUIsSUFBTSxhQUFhLEdBQUcsR0FBRyxDQUFDO0FBQzFCLElBQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDO0FBQzlCLElBQU0saUJBQWlCLEdBQUcsR0FBRyxDQUFDO0FBQzlCLElBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUM1QixJQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUVoQyxJQUFNLE1BQU0sR0FBRyxHQUFHLENBQUM7QUFDbkIsSUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVTO0FBQ0c7QUFFcEM7SUFBNEIsMEJBQXVCO0lBQ2pELGdCQUNFLEtBQW1CLEVBQ25CLENBQVMsRUFDVCxDQUFTLEVBQ1QsSUFBWSxFQUNaLEtBQVMsRUFDVCxTQUVDO1FBUkgsWUFVRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDLFNBMEJoQztRQXpCQyxLQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUMxQixLQUFJLENBQUMsY0FBYyxDQUFDLEVBQUUsYUFBYSxFQUFFLElBQUksRUFBRSxDQUFDO2FBQzNDLEVBQUUsQ0FBQyxhQUFhLEVBQUU7WUFDakIsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7Z0JBQzVELFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxZQUFZLEVBQUU7WUFDaEIsS0FBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2pCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUU7Z0JBQzNELFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzthQUN4QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxhQUFhLEVBQUU7WUFDakIsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksU0FBUyxJQUFJLE9BQU8sU0FBUyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUU7Z0JBQzVELFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzthQUN6QjtRQUNILENBQUMsQ0FBQzthQUNELEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDZixJQUFJLFNBQVMsSUFBSSxPQUFPLFNBQVMsQ0FBQyxTQUFTLEtBQUssVUFBVSxFQUFFO2dCQUMxRCxTQUFTLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDdkI7UUFDSCxDQUFDLENBQUMsQ0FBQzs7SUFDTCxDQUFDO0lBRU0sMkJBQVUsR0FBakI7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDO1lBQ1osSUFBSSxFQUFFLGlEQUFPLENBQUMsS0FBSyxDQUFDLE1BQU07U0FDM0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLDBCQUFTLEdBQWhCO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVNLDJCQUFVLEdBQWpCO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUNaLElBQUksRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNO1NBQzNCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDSCxhQUFDO0FBQUQsQ0FBQyxDQXREMkIsa0RBQWtCLENBQUMsSUFBSSxHQXNEbEQ7Ozs7Ozs7Ozs7Ozs7O0FDekREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXdCO0FBQ0E7QUFDRDtBQUNDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSFM7QUFDQztBQUdsQztJQUEyQix5QkFBNEI7SUFDckQsZUFDRSxLQUFnQixFQUNoQixDQUFTLEVBQ1QsQ0FBUyxFQUNULE9BQWU7UUFKakIsWUFNRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsK0NBQUssQ0FBQyxTQWNuQztRQWJDLEtBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQixJQUFNLEtBQUssR0FBRywyQ0FBVyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSSxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBRXZGLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUVqQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxLQUFtQyxFQUFFLElBQTBCO1lBQzVHLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsVUFBVTtnQkFBRSxPQUFPO1lBQzdDLEtBQUssQ0FBQyxVQUFVLEVBQUU7UUFDcEIsQ0FBQyxDQUFDO1FBRUYsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUksRUFBRSxLQUFLLENBQUMsV0FBVyxFQUFFLFVBQUMsS0FBbUMsRUFBRSxJQUEwQjtZQUNsSCxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDbEIsQ0FBQyxDQUFDOztJQUNKLENBQUM7SUFFSCxZQUFDO0FBQUQsQ0FBQyxDQXZCMEIsOENBQWMsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQXVCdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0JnQztBQUNFO0FBR25DO0lBQTRCLDBCQUE0QjtJQUV0RCxnQkFDRSxLQUFnQixFQUNoQixDQUFTLEVBQ1QsQ0FBUyxFQUNULE9BQWU7UUFKakIsWUFNRSxrQkFBTSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsZ0RBQU0sR0FBRyxDQUFDLENBQUMsU0FzQnhDO1FBckJDLEtBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLEtBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRXpCLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFJLEVBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxVQUFDLE1BQW9DLEVBQUUsSUFBMEI7WUFDbkgsS0FBSSxDQUFDLFNBQVMsR0FBRywyQ0FBVyxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFtQixDQUFFO1lBQy9FLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUMsQ0FBQztZQUNuQyxJQUFNLFVBQVUsR0FBRztnQkFDakIsY0FBTSxhQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUEzQixDQUEyQjtnQkFDakMsY0FBTSxhQUFNLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsRUFBMUIsQ0FBMEI7Z0JBQ2hDLGNBQU0sYUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQTFCLENBQTBCO2dCQUNoQyxjQUFNLGFBQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQTNCLENBQTJCO2FBQ2xDO1lBQ0QsVUFBVSxDQUFDLEtBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUM5QixDQUFDLENBQUM7UUFFRixLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSSxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxNQUFvQyxFQUFFLElBQTBCO1lBQzdHLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsVUFBVSxFQUFFO2dCQUNwQyxPQUFPO2FBQ1I7WUFDRCxLQUFLLENBQUMsVUFBVSxFQUFFO1FBQ3BCLENBQUMsQ0FBQzs7SUFDSixDQUFDO0lBQ0gsYUFBQztBQUFELENBQUMsQ0EvQjJCLDhDQUFjLENBQUMsTUFBTSxDQUFDLE1BQU0sR0ErQnZEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ2dDO0FBQ0U7QUFDSDtBQUdoQztJQUE0QiwwQkFBeUI7SUFFbkQsZ0JBQ0UsS0FBZ0IsRUFDaEIsQ0FBUyxFQUNULENBQVMsRUFDVCxPQUFlO1FBSmpCLFlBTUUsa0JBQU0sS0FBSyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLGdEQUFNLEdBQUcsQ0FBQyxDQUFDLFNBV3hDO1FBVkMsS0FBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDckIsS0FBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO2dCQUNoRSxJQUFJLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxDQUFDLFVBQVU7b0JBQUUsT0FBTTtnQkFDNUMsSUFBTSxLQUFLLEdBQUcsSUFBSSw0Q0FBSyxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUM5QyxLQUFLLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDMUIsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNsQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUM7WUFFaEMsQ0FBQyxFQUFFLGFBQWEsRUFBRSxLQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7O0lBQ3hDLENBQUM7SUFDSCxhQUFDO0FBQUQsQ0FBQyxDQXBCMkIsa0RBQWtCLENBQUMsTUFBTSxHQW9CcEQ7Ozs7Ozs7Ozs7Ozs7O0FDekJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBaUM7QUFDTDtBQUU1QixJQUFNLE1BQU0sR0FBaUM7SUFDM0MsS0FBSyxFQUFFLFNBQVM7SUFDaEIsSUFBSSxFQUFFLDJDQUFXO0lBQ2pCLElBQUksRUFBRSxDQUFDO0lBQ1AsS0FBSyxFQUFFO1FBQ0wsTUFBTSxFQUFFLE1BQU07UUFDZCxLQUFLLEVBQUUsR0FBRztRQUNWLE1BQU0sRUFBRSxHQUFHO1FBQ1gsVUFBVSxFQUFFLDRDQUFZLENBQUMsV0FBVztRQUNwQyxJQUFJLEVBQUUsNENBQVksQ0FBQyxHQUFHO0tBQ3ZCO0lBQ0QsT0FBTyxFQUFFO1FBQ1AsT0FBTyxFQUFFLFFBQVE7UUFDakIsTUFBTSxFQUFFO1lBRU4sT0FBTyxFQUFFO2dCQUNQLENBQUMsRUFBRSxDQUFDO2FBQ0w7U0FFRjtLQUNGO0lBTUQsS0FBSyxFQUFFLDhDQUFNO0lBQ2IsTUFBTSxFQUFFLE1BQU07SUFDZCxlQUFlLEVBQUUsUUFBUTtDQUMxQixDQUFDO0FBRUssSUFBTSxJQUFJLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbENYO0FBQ007QUFFdkMsSUFBTSxXQUFXLEdBQXVDO0lBQ3RELE1BQU0sRUFBRSxLQUFLO0lBQ2IsT0FBTyxFQUFFLEtBQUs7SUFDZCxHQUFHLEVBQUUsTUFBTTtDQUNaLENBQUM7QUFFRjtJQUErQiw2QkFBWTtJQUN6QztlQUNFLGtCQUFNLFdBQVcsQ0FBQztJQUNwQixDQUFDO0lBRU0sMkJBQU8sR0FBZDtRQUFBLGlCQXdEQztRQXBEQyxJQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3hDLElBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDeEMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxrREFBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDcEQsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUtsQyxTQUF1QixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBdEMsT0FBTyxlQUFFLE9BQU8sYUFBc0I7UUFDOUMsSUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDakMsQ0FBQyxFQUFFLE9BQU87WUFDVixDQUFDLEVBQUUsT0FBTztZQUNWLElBQUksRUFBRSxZQUFZO1lBQ2xCLEtBQUssRUFBRTtnQkFDTCxJQUFJLEVBQUUsZ0JBQWdCO2dCQUN0QixJQUFJLEVBQUUsa0RBQU8sQ0FBQyxLQUFLLENBQUMsTUFBTTthQUMzQjtTQUNGLENBQUMsQ0FBQztRQUNILFdBQVcsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRWhDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxVQUFDLEtBQWE7WUFDckMsV0FBVyxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ3BCLFdBQVcsQ0FBQyxTQUFTLENBQUMsa0RBQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQy9DLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ2xELENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsY0FBYyxFQUFFLFVBQUMsSUFBVTtZQUN0QyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRTtZQUl2QixXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEIsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3RCLFdBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN0QixLQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztRQUtILElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztRQUMzRCxJQUFJLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxzQkFBc0IsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLHNCQUFzQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLG9CQUFvQixFQUFFO1lBQ25ELFVBQVUsRUFBRSxFQUFFO1lBQ2QsV0FBVyxFQUFFLEVBQUU7U0FDaEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUNILGdCQUFDO0FBQUQsQ0FBQyxDQTlEOEIsNENBQVksR0E4RDFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZFZ0M7QUFDeWM7QUFDNWI7QUFHOUMsSUFBTSxXQUFXLEdBQXVDO0lBQ3RELE1BQU0sRUFBRSxLQUFLO0lBQ2IsT0FBTyxFQUFFLEtBQUs7SUFDZCxHQUFHLEVBQUUsTUFBTTtDQUNaLENBQUM7QUFFRjtJQUErQiw2QkFBWTtJQW9CekM7ZUFDRSxrQkFBTSxXQUFXLENBQUM7SUFDcEIsQ0FBQztJQUVNLHdCQUFJLEdBQVgsVUFBWSxFQUVYO1lBRmEsS0FBSztRQUdqQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztJQUNyQixDQUFDO0lBRU0sMkJBQU8sR0FBZDtRQUNFLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBSXBCLElBQUksQ0FBQyxNQUFNLEdBQUc7WUFDWixPQUFPLEVBQUUsSUFBSTtZQUNiLEtBQUssRUFBRSxHQUFHO1lBQ1YsZ0JBQWdCLEVBQUUsQ0FBQztZQUNuQixTQUFTLEVBQUUsR0FBRztTQUNmO1FBTUQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7UUFDM0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7UUFLdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxrREFBTyxDQUFDO1FBTXpCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBS3hCLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO0lBQ2xCLENBQUM7SUFFTSwwQkFBTSxHQUFiO1FBQUEsaUJBNk5DO1FBNU5PLFNBQWUsNENBQVksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUEzQyxLQUFLLGFBQUUsQ0FBQyxPQUFtQyxDQUFDO1FBRXBELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUV0RCxJQUFNLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFM0MsSUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBS25ELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsUUFBTSxJQUFJLENBQUMsS0FBTyxFQUFFLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNuRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbkUsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztRQU10RSxJQUFJLENBQUMsV0FBVyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFTakQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztRQUN6RCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO1FBTTNELElBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLHFEQUFVLENBQUMsQ0FBQztRQUM1RCxJQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyx3REFBYSxDQUFDLENBQUM7UUFDckUsSUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyx5REFBYyxDQUFDLENBQUM7UUFDdkUsSUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQywyREFBZ0IsQ0FBQyxDQUFDO1FBRzNFLElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDO1FBRTVCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxnREFBSyxDQUFDLENBQUM7UUFFbEcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUtyRCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNoQixHQUFHLEVBQUUsU0FBUztZQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssRUFBRSxnREFBSyxFQUFFLEdBQUcsRUFBRSxrREFBTyxFQUFFLENBQUM7WUFDaEYsU0FBUyxFQUFFLEVBQUU7WUFDYixNQUFNLEVBQUUsQ0FBQyxDQUFDO1NBQ1gsQ0FBQztRQU1GLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxNQUEyQixFQUFFLElBQTBCO1lBQy9HLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxLQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQyxPQUFNO2FBQ1A7WUFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLFFBQVEsRUFBRTtnQkFDbEIsS0FBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDbEM7WUFDRCxJQUFJLENBQUMsS0FBSSxDQUFDLGNBQWMsRUFBRTtnQkFDeEIsS0FBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7YUFDNUI7UUFDSCxDQUFDLEVBQUU7WUFDRCxPQUFPLENBQUMsS0FBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLEtBQUksQ0FBQyxVQUFVLENBQUM7UUFDMUMsQ0FBQyxDQUFDO1FBRUYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLE1BQTJCLEVBQUUsSUFBMEI7WUFDOUcsSUFBSSxLQUFJLENBQUMsTUFBTSxJQUFJLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ2xDLE9BQU8sS0FBSzthQUNiO1lBRUQsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3BCLENBQUMsRUFBRSxVQUFDLE1BQU0sRUFBRSxJQUFJO1lBQ2QsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSSxLQUFJLENBQUMsTUFBTSxJQUFJLEtBQUksQ0FBQyxVQUFVLEVBQUU7Z0JBQ3RELE9BQU8sS0FBSzthQUNiO1lBQ0QsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLG1EQUFRLEVBQUU7Z0JBQzNCLElBQUksTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUM3RCxPQUFPLElBQUk7aUJBQ1o7YUFDRjtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxxREFBVSxFQUFFO2dCQUM3QixJQUFJLE1BQU0sQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtvQkFDOUQsT0FBTyxJQUFJO2lCQUNaO2FBQ0Y7WUFDRCxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUsscURBQVUsRUFBRTtnQkFDN0IsSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO29CQUMvQixPQUFPLElBQUk7aUJBQ1o7YUFDRjtZQUNELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxzREFBVyxFQUFFO2dCQUM5QixJQUFJLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUU7b0JBQ2hDLE9BQU8sSUFBSTtpQkFDWjthQUNGO1lBQ0QsT0FBTyxLQUFLO1FBQ2QsQ0FBQyxDQUFDO1FBTUYsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFDLE9BQU8sRUFBRSxJQUFJOztZQUNyRSxJQUFNLE9BQU87Z0JBQ1gsR0FBQyxrREFBTyxJQUFHLFVBQUMsSUFBMEI7b0JBQ3BDLEtBQUksQ0FBQyxVQUFVLENBQUMsa0RBQU8sRUFBRSxJQUFJLENBQUM7Z0JBQ2hDLENBQUM7Z0JBQ0QsR0FBQyxxREFBVSxJQUFHLFVBQUMsSUFBMEI7b0JBQ3ZDLEtBQUksQ0FBQyxVQUFVLENBQUMscURBQVUsRUFBRSxJQUFJLENBQUM7Z0JBQ25DLENBQUM7Z0JBQ0QsR0FBQyxtREFBUSxJQUFHLFVBQUMsSUFBMEI7b0JBQ3JDLEtBQUksQ0FBQyxVQUFVLENBQUMsbURBQVEsRUFBRSxJQUFJLENBQUM7Z0JBQ2pDLENBQUM7Z0JBQ0QsR0FBQyxvREFBUyxJQUFHLFVBQUMsSUFBMEI7b0JBQ3RDLEtBQUksQ0FBQyxVQUFVLENBQUMsb0RBQVMsRUFBRSxJQUFJLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsR0FBQywwREFBZSxJQUFHLFVBQUMsSUFBMEI7b0JBQzVDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsa0RBQU8sQ0FBQyxFQUFFO3dCQUNoQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw0REFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQy9EO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw0REFBaUIsSUFBRyxVQUFDLElBQTBCO29CQUM5QyxLQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO2dCQUNELEdBQUMsd0RBQWEsSUFBRyxVQUFDLElBQTBCO29CQUUxQyxJQUFNLG1CQUFtQixHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLDREQUFpQixDQUFDLENBQUM7b0JBQzdFLEtBQUksQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDckMsQ0FBQztnQkFDRCxHQUFDLDZEQUFrQixJQUFHLFVBQUMsSUFBMEI7b0JBQy9DLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMscURBQVUsQ0FBQyxFQUFFO3dCQUNuQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQywrREFBb0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2xFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQywrREFBb0IsSUFBRyxVQUFDLElBQTBCO29CQUNqRCxLQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUM7Z0JBQ3BDLENBQUM7Z0JBQ0QsR0FBQywyREFBZ0IsSUFBRyxVQUFDLElBQTBCO29CQUU3QyxJQUFNLHNCQUFzQixHQUFHLEtBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLCtEQUFvQixDQUFDLENBQUM7b0JBQ25GLEtBQUksQ0FBQyxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQztnQkFDeEMsQ0FBQztnQkFDRCxHQUFDLDREQUFpQixJQUFHLFVBQUMsSUFBMEI7b0JBQzlDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsb0RBQVMsQ0FBQyxFQUFFO3dCQUNsQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw4REFBbUIsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2pFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw4REFBbUIsSUFBRyxVQUFDLElBQTBCO29CQUNoRCxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDaEMsQ0FBQztnQkFDRCxHQUFDLDJEQUFnQixJQUFHLFVBQUMsSUFBMEI7b0JBQzdDLElBQUksS0FBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsbURBQVEsQ0FBQyxFQUFFO3dCQUNqQyxLQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyw2REFBa0IsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ2hFO2dCQUNILENBQUM7Z0JBQ0QsR0FBQyw2REFBa0IsSUFBRyxVQUFDLElBQTBCO29CQUMvQyxLQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBQ2xDLENBQUM7Z0JBQ0QsR0FBQyx5REFBYyxJQUFHLFVBQUMsSUFBMEI7b0JBRTNDLElBQU0sb0JBQW9CLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsNkRBQWtCLENBQUMsQ0FBQztvQkFDL0UsS0FBSSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO2dCQUN0QyxDQUFDO21CQUNGO1lBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFFM0IsQ0FBQyxFQUFFLFVBQUMsT0FBTyxFQUFFLEVBQStCO2dCQUE3QixLQUFLO1lBQ2xCLElBQUksS0FBSSxDQUFDLE1BQU0sSUFBSSxLQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNsQyxPQUFPLEtBQUs7YUFDYjtZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNoQixPQUFPLEtBQUs7YUFDYjtZQUVELElBQU0sT0FBTyxHQUFHLENBQUMsa0RBQU8sRUFBRSxxREFBVSxFQUFFLG1EQUFRLEVBQUUsb0RBQVMsRUFBRSwwREFBZSxFQUFFLDREQUFpQixFQUFFLHdEQUFhLEVBQUUsNkRBQWtCLEVBQUUsK0RBQW9CLEVBQUUsMkRBQWdCLEVBQUUsMkRBQWdCLEVBQUUsNkRBQWtCLEVBQUUseURBQWMsRUFBRSw0REFBaUIsRUFBRSw4REFBbUIsRUFBRSwwREFBZSxDQUFDLENBQUM7WUFDelIsT0FBTyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztRQUNoQyxDQUFDLENBQUM7UUFLRixRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxjQUFNLFlBQUksQ0FBQyxJQUFJLEVBQUUsRUFBWCxDQUFXLENBQUMsQ0FBQztRQU12QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUs3QixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxVQUFDLElBQTBCO1lBQ3RELElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxpREFBTSxFQUFFO2dCQUN6QixLQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxnREFBSyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNsRCxJQUFNLE1BQU0sR0FBRyxJQUFJLG1EQUFNLENBQUMsS0FBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7Z0JBQ2xFLEtBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQzthQUMxQjtZQUFBLENBQUM7WUFDRixJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssaURBQU0sRUFBRTtnQkFDekIsS0FBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsZ0RBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDbEQsSUFBTSxNQUFNLEdBQUcsSUFBSSxtREFBTSxDQUFDLEtBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2dCQUNsRSxLQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ3pCLEtBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7Z0JBQ2pDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDMUI7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSwwQkFBTSxHQUFiO1FBQ0UsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDbEMsT0FBTTtTQUNQO1FBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUU7WUFDMUIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1NBQ2I7UUFDRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUMxRCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztZQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDbkIsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7YUFDN0I7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ3RCO1NBRUY7YUFBTSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNqRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztZQUN2QyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO2FBQzdCO2lCQUFNO2dCQUNMLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQzthQUN0QjtTQUNGO2FBQU07WUFDTCxJQUFJLENBQUMsVUFBVSxFQUFFO1NBQ2xCO1FBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRU8sd0NBQW9CLEdBQTVCO1FBQUEsaUJBaUJDO1FBaEJDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RDLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUMxRSxDQUFDO1lBQ0Q7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQzFFLENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3pFLENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDMUUsQ0FBQztTQUNGO1FBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyxpQ0FBYSxHQUFyQjtRQUFBLGlCQWlCQztRQWhCQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDckMsSUFBTSxVQUFVLEdBQUc7WUFDakI7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFFLENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDMUUsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNFLENBQUM7WUFDRDtnQkFDRSxLQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzRSxDQUFDO1NBQ0Y7UUFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVPLDhCQUFVLEdBQWxCO1FBQUEsaUJBaUJDO1FBaEJDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ3pCLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDMUQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDMUQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDMUQsQ0FBQztTQUNGO1FBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyx3QkFBSSxHQUFaO1FBQUEsaUJBd0JDO1FBdkJDLElBQU0sVUFBVSxHQUFHO1lBQ2pCO2dCQUNFLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRTtvQkFDakMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2lCQUNsRDtZQUNILENBQUM7WUFDRDtnQkFDRSxJQUFJLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7b0JBQ2pDLEtBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2pEO1lBQ0gsQ0FBQztZQUNEO2dCQUNFLElBQUksS0FBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRTtvQkFDL0IsS0FBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDakQ7WUFDSCxDQUFDO1lBQ0Q7Z0JBQ0UsSUFBSSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFO29CQUNsQyxLQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQ2xEO1lBQ0gsQ0FBQztTQUNGO1FBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyxpQ0FBYSxHQUFyQixVQUFzQixFQUFpQixFQUFFLEVBQWdCO1FBQXpELGlCQStEQztRQS9EdUIsU0FBSyxhQUFLLElBQUksY0FBaEIsU0FBaUIsQ0FBRDtRQUFJLEtBQUMsU0FBRSxDQUFDLFNBQUksTUFBTSxjQUFmLFVBQWdCLENBQUQ7UUFDdEQsSUFBSSxJQUFJLENBQUMsUUFBUTtZQUFFLE9BQU87UUFFMUIsSUFBTSxVQUFVLEdBQUc7WUFDakI7Z0JBQ0UsSUFBSSxLQUFLLEtBQUssb0RBQVMsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDOUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQztnQkFDRCxJQUFJLEtBQUssS0FBSyxtREFBUSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3hFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN0QztnQkFDRCxJQUFJLEtBQUssS0FBSyxnREFBSyxFQUFFO29CQUNuQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM3QjtnQkFDRCxJQUFJLEtBQUssS0FBSywrQ0FBSSxFQUFFO29CQUNsQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzlCO1lBQ0gsQ0FBQztZQUNEO2dCQUNFLElBQUksS0FBSyxLQUFLLHVEQUFZLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ2pGLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUNqQztnQkFDRCxJQUFJLEtBQUssS0FBSyxvREFBUyxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3pFLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN0QztnQkFDRCxJQUFJLEtBQUssS0FBSyxpREFBTSxFQUFFO29CQUNwQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2lCQUM3QjtnQkFDRCxJQUFJLEtBQUssS0FBSyw4Q0FBRyxFQUFFO29CQUNqQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzlCO1lBQ0gsQ0FBQztZQUNEO2dCQUNFLElBQUksS0FBSyxLQUFLLHNEQUFXLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDM0UsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNyQztnQkFDRCxJQUFJLEtBQUssS0FBSyx1REFBWSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFO29CQUNqRixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNsQztnQkFDRCxJQUFJLEtBQUssS0FBSyxnREFBSyxFQUFFO29CQUNuQixLQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzlCO2dCQUNELElBQUksS0FBSyxLQUFLLCtDQUFJLEVBQUU7b0JBQ2xCLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzdCO1lBQ0gsQ0FBQztZQUNEO2dCQUNFLElBQUksS0FBSyxLQUFLLG1EQUFRLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDeEUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3RDO2dCQUNELElBQUksS0FBSyxLQUFLLHNEQUFXLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ2hGLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztpQkFDbkM7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssaURBQU0sSUFBSSxDQUFDLEtBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ3RDLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztpQkFDOUI7Z0JBQ0QsSUFBSSxLQUFLLEtBQUssOENBQUcsSUFBSSxDQUFDLEtBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ25DLEtBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7aUJBQzdCO1lBQ0gsQ0FBQztTQUNGO1FBRUQsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyxrQ0FBYyxHQUF0QixVQUF1QixLQUFhLEVBQUUsQ0FBUyxFQUFFLENBQVM7UUFBMUQsaUJBaUJDO1FBaEJDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDOUIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDckIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDZCxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1lBQ3RCLEtBQUssRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxFQUFFLEdBQUcsS0FBSztZQUNyQyxDQUFDO1lBQ0QsQ0FBQztZQUNELFFBQVEsRUFBRSxHQUFHO1lBQ2IsVUFBVSxFQUFFO2dCQUNWLEtBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUN0QixLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ3ZDLEtBQUksQ0FBQyxTQUFTLEdBQUcsMkNBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBbUIsQ0FBRTtnQkFDbkYsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLENBQUM7U0FDRixDQUFDO0lBQ0osQ0FBQztJQUVPLDhCQUFVLEdBQWxCO1FBQUEsaUJBZ0JDO1FBZkMsSUFBTSxVQUFVLEdBQUc7WUFDakI7Z0JBQ0UsS0FBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDakQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbEQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEQsQ0FBQztZQUNEO2dCQUNFLEtBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ2pELENBQUM7U0FDRjtRQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRU0sd0JBQUksR0FBWDtRQUNFLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNmLE9BQU07U0FDUDtRQUNELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEtBQUssQ0FBQyxFQUFFO2dCQUNoRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO2dCQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUM7YUFDL0I7aUJBQU07Z0JBQ0wsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO2FBQy9CO1lBQ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ3JDLElBQU0sVUFBVSxHQUF5QixDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQzNDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUztTQUNqQztJQUNILENBQUM7SUFFTyw0QkFBUSxHQUFoQixVQUFpQixJQUEwQixFQUFFLFFBQStDLEVBQUUsU0FBZ0Q7UUFBOUksaUJBdUNDO1FBdENDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztZQUNkLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDdEIsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxDQUFDO2dCQUNQLEVBQUUsRUFBRSxDQUFDO2FBQ047WUFDRCxRQUFRLEVBQUUsR0FBRztZQUNiLFVBQVUsRUFBRTtnQkFDVixJQUFJLFFBQVEsSUFBSSxPQUFPLFFBQVEsS0FBSyxVQUFVLEVBQUU7b0JBQzlDLFFBQVEsQ0FBQyxJQUFJLENBQUM7aUJBQ2Y7Z0JBQ0QsS0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNyQixLQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztvQkFDZCxPQUFPLEVBQUUsQ0FBQyxLQUFJLENBQUMsTUFBTSxDQUFDO29CQUN0QixDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO29CQUNsQixDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO29CQUNsQixVQUFVLEVBQUU7d0JBQ1YsS0FBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7NEJBQ2QsT0FBTyxFQUFFLENBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQzs0QkFDdEIsS0FBSyxFQUFFO2dDQUNMLElBQUksRUFBRSxDQUFDO2dDQUNQLEVBQUUsRUFBRSxDQUFDOzZCQUNOOzRCQUNELFVBQVUsRUFBRTtnQ0FDVixLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7Z0NBQ3ZDLEtBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2dDQUN4QixLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztnQ0FDdkIsSUFBSSxTQUFTLElBQUksT0FBTyxTQUFTLEtBQUssVUFBVSxFQUFFO29DQUNoRCxTQUFTLENBQUMsSUFBSSxDQUFDO2lDQUNoQjs0QkFDSCxDQUFDO3lCQUNGLENBQUMsQ0FBQztvQkFDTCxDQUFDO2lCQUNGLENBQUM7WUFDSixDQUFDO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFTyw4QkFBVSxHQUFsQixVQUFtQixJQUFZLEVBQUUsSUFBMEI7UUFDekQsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsZ0RBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDO1FBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztJQUN6QixDQUFDO0lBRU8sMEJBQU0sR0FBZDtRQUFBLGlCQVVDO1FBVEMsSUFBSSxDQUFDLFFBQVEsQ0FDWCxJQUFJLENBQUMsVUFBVSxFQUNmLFVBQUMsSUFBMEI7WUFDekIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0RBQUssQ0FBQyxDQUFDO1FBQzlCLENBQUMsRUFDRCxVQUFDLElBQTBCO1lBQ3pCLEtBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLENBQUMsQ0FDRjtJQUNILENBQUM7SUFFTyxpQ0FBYSxHQUFyQjtRQUNFLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRU0sOEJBQVUsR0FBakI7UUFDRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7UUFDdkMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFO1FBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLCtDQUFJLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJO1FBQ2xCLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUM7SUFDcEQsQ0FBQztJQUNILGdCQUFDO0FBQUQsQ0FBQyxDQXhsQjhCLDRDQUFZLEdBd2xCMUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNubUJnQztBQUNGO0FBQ087QUFDSztBQUUzQyxJQUFNLFNBQVMsR0FBRztJQUNoQixJQUFJLEVBQUUsaURBQU8sQ0FBQyxNQUFNLENBQUMsTUFBTTtJQUMzQixVQUFVLEVBQUUsV0FBVztJQUN2QixLQUFLLEVBQUUsUUFBUTtDQUNoQjtBQUNELElBQU0sV0FBVyxHQUF1QztJQUN0RCxNQUFNLEVBQUUsS0FBSztJQUNiLE9BQU8sRUFBRSxLQUFLO0lBQ2QsR0FBRyxFQUFFLEtBQUs7Q0FDWCxDQUFDO0FBRUY7SUFBOEIsNEJBQVk7SUFheEM7ZUFDRSxrQkFBTSxXQUFXLENBQUM7SUFDcEIsQ0FBQztJQUVNLHVCQUFJLEdBQVgsVUFBWSxFQUVYO1lBRmEsS0FBSztRQUdqQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUNqQixDQUFDO0lBS00seUJBQU0sR0FBYjtRQUFBLGlCQW9GQztRQW5GUyxTQUFLLEdBQUssNENBQVksQ0FBQyxRQUFRLENBQUMsUUFBUSxNQUFuQyxDQUFvQztRQUNqRCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFbkQsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFO1FBQ2YsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEdBQUcsRUFBRSxRQUFNLElBQUksQ0FBQyxLQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDL0MsSUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7WUFDcEMsU0FBUyxFQUFFO2dCQUNULEtBQUssRUFBRSxHQUFHO2dCQUNWLEtBQUssRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNO2FBQzVCO1NBQ0YsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN0QixJQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztZQUNyQyxTQUFTLEVBQUU7Z0JBQ1QsS0FBSyxFQUFFLGlEQUFPLENBQUMsTUFBTSxDQUFDLE1BQU07YUFDN0I7U0FDRixDQUFDO1FBQ0YsSUFBTSxLQUFLLEdBQUcsSUFBSSwyQ0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7UUFDekQsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUM7UUFDM0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLENBQUM7UUFFckQsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLG1CQUFtQix3QkFDM0QsU0FBUyxLQUNaLElBQUksRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQzFCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLGdDQUFnQyx3QkFDdkUsU0FBUyxLQUNaLElBQUksRUFBRSxpREFBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQzFCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLG1EQUFNLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUseUJBQXlCLEVBQUU7WUFDM0UsSUFBSSxFQUFFLGlEQUFPLENBQUMsS0FBSyxDQUFDLE1BQU07WUFDMUIsVUFBVSxFQUFFLFdBQVc7WUFDdkIsS0FBSyxFQUFFLFFBQVE7U0FDaEIsRUFBRTtZQUNELFNBQVMsRUFBRSxjQUFNLFlBQUksQ0FBQyxTQUFTLEVBQUUsRUFBaEIsQ0FBZ0I7U0FDbEMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxJQUFNLEtBQUssR0FBRyxJQUFJLDJDQUFXLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RCxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNqQyxJQUFNLFdBQVcsR0FBRztZQUNsQixJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSwrQ0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztTQUN0RDtRQUVELElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFVBQUMsSUFBWTtZQUN0RCxJQUFNLEtBQUssR0FBRyxLQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUNoQyxLQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDckIsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUU7WUFDNUMseUNBQVMsQ0FBQyxjQUFjLEVBQUUsS0FBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7WUFDekMsS0FBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMxQixLQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMvQixJQUFJLEtBQUksQ0FBQyxLQUFLLEtBQUssQ0FBQyxFQUFFO2dCQUNwQixLQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFJLENBQUMsWUFBWSxDQUFDO2FBQ3JDO2lCQUFNO2dCQUNMLEtBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzthQUN6QztRQUdILENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO2dCQUM1RCxLQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQztnQkFDaEIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBSSxLQUFJLENBQUMsS0FBTyxDQUFDO1lBQ3pDLENBQUMsRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBRXRDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLGNBQU0sWUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFoQixDQUFnQixDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVPLDRCQUFTLEdBQWpCO1FBQ0UsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDN0IsSUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQ3hDLFNBQVMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzdDLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsS0FBSyxTQUFFLENBQUM7UUFDbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxLQUFLLFNBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUgsZUFBQztBQUFELENBQUMsQ0ExSDZCLDRDQUFZLEdBMEh6Qzs7Ozs7Ozs7Ozs7Ozs7QUMxSUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFtQztBQUNBO0FBQ0Y7QUFDSTtBQUV0QjtJQUNiLCtDQUFTO0lBQ1QsK0NBQVM7SUFDVCw2Q0FBUTtJQUNSLGlEQUFVO0NBQ1gsRUFBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVitCO0FBQ0Y7QUFDMEI7QUFFekQsSUFBTSxXQUFXLEdBQXVDO0lBQ3RELE1BQU0sRUFBRSxLQUFLO0lBQ2IsT0FBTyxFQUFFLEtBQUs7SUFDZCxHQUFHLEVBQUUsT0FBTztDQUNiLENBQUM7QUFFRjtJQUFnQyw4QkFBWTtJQVUxQztlQUNFLGtCQUFNLFdBQVcsQ0FBQztJQUNwQixDQUFDO0lBRU0sMkJBQU0sR0FBYjtRQUFBLGlCQXVDQztRQXRDUyxTQUFLLEdBQUssNENBQVksQ0FBQyxRQUFRLENBQUMsUUFBUSxNQUFuQyxDQUFvQztRQUNqRCxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkQsSUFBTSxZQUFZLEdBQUcseUNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDcEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxZQUFZLENBQUM7UUFDN0IsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQ3RELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNuRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDcEUsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO1FBRXRFLElBQU0sVUFBVSxHQUFnQyxFQUFFO1FBQ2xELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDM0IsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsOENBQUksR0FBRyxDQUFDLENBQUM7WUFDbkQsSUFBSSxDQUFDLElBQUksWUFBWSxFQUFFO2dCQUNyQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQywrQ0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO1lBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDdEI7UUFDRCxJQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzVDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxnREFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUVuRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDNUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFN0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRTtZQUMzQixLQUFJLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1lBQ3ZFLEtBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQ3BELENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUU7WUFDNUIsS0FBSSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsUUFBUSxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQztZQUN2RSxLQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNwRCxDQUFDLENBQUM7UUFFRixRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRTtZQUNsQixLQUFJLENBQUMsU0FBUyxDQUFDLEtBQUksQ0FBQyxRQUFRLENBQUM7UUFDL0IsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sOEJBQVMsR0FBakIsVUFBa0IsS0FBYTtRQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsRUFBRSxLQUFLLFNBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsRUFBRSxLQUFLLFNBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3ZFLENBQUM7SUFDSCxpQkFBQztBQUFELENBQUMsQ0ExRCtCLDRDQUFZLEdBMEQzQyIsImZpbGUiOiJidW5kbGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBpbnN0YWxsIGEgSlNPTlAgY2FsbGJhY2sgZm9yIGNodW5rIGxvYWRpbmdcbiBcdGZ1bmN0aW9uIHdlYnBhY2tKc29ucENhbGxiYWNrKGRhdGEpIHtcbiBcdFx0dmFyIGNodW5rSWRzID0gZGF0YVswXTtcbiBcdFx0dmFyIG1vcmVNb2R1bGVzID0gZGF0YVsxXTtcbiBcdFx0dmFyIGV4ZWN1dGVNb2R1bGVzID0gZGF0YVsyXTtcblxuIFx0XHQvLyBhZGQgXCJtb3JlTW9kdWxlc1wiIHRvIHRoZSBtb2R1bGVzIG9iamVjdCxcbiBcdFx0Ly8gdGhlbiBmbGFnIGFsbCBcImNodW5rSWRzXCIgYXMgbG9hZGVkIGFuZCBmaXJlIGNhbGxiYWNrXG4gXHRcdHZhciBtb2R1bGVJZCwgY2h1bmtJZCwgaSA9IDAsIHJlc29sdmVzID0gW107XG4gXHRcdGZvcig7aSA8IGNodW5rSWRzLmxlbmd0aDsgaSsrKSB7XG4gXHRcdFx0Y2h1bmtJZCA9IGNodW5rSWRzW2ldO1xuIFx0XHRcdGlmKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpICYmIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuIFx0XHRcdFx0cmVzb2x2ZXMucHVzaChpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF1bMF0pO1xuIFx0XHRcdH1cbiBcdFx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSAwO1xuIFx0XHR9XG4gXHRcdGZvcihtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuIFx0XHRcdGlmKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChtb3JlTW9kdWxlcywgbW9kdWxlSWQpKSB7XG4gXHRcdFx0XHRtb2R1bGVzW21vZHVsZUlkXSA9IG1vcmVNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0XHR9XG4gXHRcdH1cbiBcdFx0aWYocGFyZW50SnNvbnBGdW5jdGlvbikgcGFyZW50SnNvbnBGdW5jdGlvbihkYXRhKTtcblxuIFx0XHR3aGlsZShyZXNvbHZlcy5sZW5ndGgpIHtcbiBcdFx0XHRyZXNvbHZlcy5zaGlmdCgpKCk7XG4gXHRcdH1cblxuIFx0XHQvLyBhZGQgZW50cnkgbW9kdWxlcyBmcm9tIGxvYWRlZCBjaHVuayB0byBkZWZlcnJlZCBsaXN0XG4gXHRcdGRlZmVycmVkTW9kdWxlcy5wdXNoLmFwcGx5KGRlZmVycmVkTW9kdWxlcywgZXhlY3V0ZU1vZHVsZXMgfHwgW10pO1xuXG4gXHRcdC8vIHJ1biBkZWZlcnJlZCBtb2R1bGVzIHdoZW4gYWxsIGNodW5rcyByZWFkeVxuIFx0XHRyZXR1cm4gY2hlY2tEZWZlcnJlZE1vZHVsZXMoKTtcbiBcdH07XG4gXHRmdW5jdGlvbiBjaGVja0RlZmVycmVkTW9kdWxlcygpIHtcbiBcdFx0dmFyIHJlc3VsdDtcbiBcdFx0Zm9yKHZhciBpID0gMDsgaSA8IGRlZmVycmVkTW9kdWxlcy5sZW5ndGg7IGkrKykge1xuIFx0XHRcdHZhciBkZWZlcnJlZE1vZHVsZSA9IGRlZmVycmVkTW9kdWxlc1tpXTtcbiBcdFx0XHR2YXIgZnVsZmlsbGVkID0gdHJ1ZTtcbiBcdFx0XHRmb3IodmFyIGogPSAxOyBqIDwgZGVmZXJyZWRNb2R1bGUubGVuZ3RoOyBqKyspIHtcbiBcdFx0XHRcdHZhciBkZXBJZCA9IGRlZmVycmVkTW9kdWxlW2pdO1xuIFx0XHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtzW2RlcElkXSAhPT0gMCkgZnVsZmlsbGVkID0gZmFsc2U7XG4gXHRcdFx0fVxuIFx0XHRcdGlmKGZ1bGZpbGxlZCkge1xuIFx0XHRcdFx0ZGVmZXJyZWRNb2R1bGVzLnNwbGljZShpLS0sIDEpO1xuIFx0XHRcdFx0cmVzdWx0ID0gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBkZWZlcnJlZE1vZHVsZVswXSk7XG4gXHRcdFx0fVxuIFx0XHR9XG5cbiBcdFx0cmV0dXJuIHJlc3VsdDtcbiBcdH1cblxuIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gb2JqZWN0IHRvIHN0b3JlIGxvYWRlZCBhbmQgbG9hZGluZyBjaHVua3NcbiBcdC8vIHVuZGVmaW5lZCA9IGNodW5rIG5vdCBsb2FkZWQsIG51bGwgPSBjaHVuayBwcmVsb2FkZWQvcHJlZmV0Y2hlZFxuIFx0Ly8gUHJvbWlzZSA9IGNodW5rIGxvYWRpbmcsIDAgPSBjaHVuayBsb2FkZWRcbiBcdHZhciBpbnN0YWxsZWRDaHVua3MgPSB7XG4gXHRcdFwibWFpblwiOiAwXG4gXHR9O1xuXG4gXHR2YXIgZGVmZXJyZWRNb2R1bGVzID0gW107XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdHZhciBqc29ucEFycmF5ID0gd2luZG93W1wid2VicGFja0pzb25wXCJdID0gd2luZG93W1wid2VicGFja0pzb25wXCJdIHx8IFtdO1xuIFx0dmFyIG9sZEpzb25wRnVuY3Rpb24gPSBqc29ucEFycmF5LnB1c2guYmluZChqc29ucEFycmF5KTtcbiBcdGpzb25wQXJyYXkucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrO1xuIFx0anNvbnBBcnJheSA9IGpzb25wQXJyYXkuc2xpY2UoKTtcbiBcdGZvcih2YXIgaSA9IDA7IGkgPCBqc29ucEFycmF5Lmxlbmd0aDsgaSsrKSB3ZWJwYWNrSnNvbnBDYWxsYmFjayhqc29ucEFycmF5W2ldKTtcbiBcdHZhciBwYXJlbnRKc29ucEZ1bmN0aW9uID0gb2xkSnNvbnBGdW5jdGlvbjtcblxuXG4gXHQvLyBhZGQgZW50cnkgbW9kdWxlIHRvIGRlZmVycmVkIGxpc3RcbiBcdGRlZmVycmVkTW9kdWxlcy5wdXNoKFtcIi4vc3JjL2luZGV4LnRzXCIsXCJ2ZW5kb3JzXCJdKTtcbiBcdC8vIHJ1biBkZWZlcnJlZCBtb2R1bGVzIHdoZW4gcmVhZHlcbiBcdHJldHVybiBjaGVja0RlZmVycmVkTW9kdWxlcygpO1xuIiwiZXhwb3J0IGNvbnN0IENPTE9VUlMgPSB7XG4gIHdoaXRlOiB7XG4gICAgc3RyaW5nOiAnI0NGQzZCOCcsXG4gICAgbnVtYmVyOiAweENGQzZCOFxuICB9LFxuICBkYXJrR3JheToge1xuICAgIHN0cmluZzogJyMwMDAwMDAnLFxuICAgIG51bWJlcjogMHgwMDAwMDAsXG4gIH0sXG4gIG1hcm9vbjoge1xuICAgIHN0cmluZzogJyM0YjJhM2MnLFxuICAgIG51bWJlcjogMHg0QjJBM0MsXG4gIH0sXG4gIGdyZWVuOiB7XG4gICAgc3RyaW5nOiAnIzM4RDk3MycsXG4gICAgbnVtYmVyOiAweDM4RDk3MyxcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgU0lERV9VUCA9IDA7XG5leHBvcnQgY29uc3QgU0lERV9SSUdIVCA9IDE7XG5leHBvcnQgY29uc3QgU0lERV9ET1dOID0gMjtcbmV4cG9ydCBjb25zdCBTSURFX0xFRlQgPSAzXG5cbmV4cG9ydCBjb25zdCBERUFEID0gNDA3O1xuZXhwb3J0IGNvbnN0IEFMSVZFID0gNDAyO1xuZXhwb3J0IGNvbnN0IFJVTl9FTkQgPSA0MDY7XG5cbmV4cG9ydCBjb25zdCBUT1BfTEVGVCA9IDE5O1xuZXhwb3J0IGNvbnN0IFRPUCA9IDIwO1xuZXhwb3J0IGNvbnN0IFRPUF9SSUdIVCA9IDIxO1xuZXhwb3J0IGNvbnN0IExFRlQgPSA2NztcbmV4cG9ydCBjb25zdCBSSUdIVCA9IDY5O1xuZXhwb3J0IGNvbnN0IEJPVFRPTV9MRUZUID0gMTE1O1xuZXhwb3J0IGNvbnN0IEJPVFRPTSA9IDExNjtcbmV4cG9ydCBjb25zdCBCT1RUT01fUklHSFQgPSAxMTc7XG5cbmV4cG9ydCBjb25zdCBTVEFSVF9ET09SID0gNDg5O1xuXG5leHBvcnQgY29uc3QgVVBfU1BJS0UgPSAyMztcbmV4cG9ydCBjb25zdCBET1dOX1NQSUtFID0gMjU7XG5leHBvcnQgY29uc3QgTEVGVF9TUElLRSA9IDc0O1xuZXhwb3J0IGNvbnN0IFJJR0hUX1NQSUtFID0gNzM7XG5leHBvcnQgY29uc3QgV0laQVJEID0gODA7XG5leHBvcnQgY29uc3QgU1BJREVSID0gMjY5O1xuZXhwb3J0IGNvbnN0IFNQRUxMID0gNTU3O1xuXG5leHBvcnQgY29uc3QgQkxBTksgPSAwO1xuZXhwb3J0IGNvbnN0IFlFTExPV19LRVkgPSA1NjE7XG5leHBvcnQgY29uc3QgQkxVRV9LRVkgPSA1NjI7XG5leHBvcnQgY29uc3QgUkVEX0tFWSA9IDU2MztcbmV4cG9ydCBjb25zdCBHUkVFTl9LRVkgPSA1NjQ7XG5leHBvcnQgY29uc3QgQkxVRV9ET09SX0xPQ0tFRCA9IDQzMztcbmV4cG9ydCBjb25zdCBCTFVFX0RPT1JfRVhJVCA9IDQzNDtcbmV4cG9ydCBjb25zdCBCTFVFX0RPT1JfRU5UUkFOQ0UgPSA0MzU7XG5leHBvcnQgY29uc3QgWUVMTE9XX0RPT1JfTE9DS0VEID0gNDM2O1xuZXhwb3J0IGNvbnN0IFlFTExPV19ET09SX0VYSVQgPSA0Mzc7XG5leHBvcnQgY29uc3QgWUVMTE9XX0RPT1JfRU5UUkFOQ0UgPSA0Mzg7XG5leHBvcnQgY29uc3QgUkVEX0RPT1JfTE9DS0VEID0gNDM5O1xuZXhwb3J0IGNvbnN0IFJFRF9ET09SX0VYSVQgPSA0NDA7XG5leHBvcnQgY29uc3QgUkVEX0RPT1JfRU5UUkFOQ0UgPSA0NDE7XG5leHBvcnQgY29uc3QgR1JFRU5fRE9PUl9MT0NLRUQgPSA0NDI7XG5leHBvcnQgY29uc3QgR1JFRU5fRE9PUl9FWElUID0gNDQzO1xuZXhwb3J0IGNvbnN0IEdSRUVOX0RPT1JfRU5UUkFOQ0UgPSA0NDQ7XG5cbmV4cG9ydCBjb25zdCBDVVJTT1IgPSA3MTM7XG5leHBvcnQgY29uc3QgWkVSTyA9IDg1MjtcblxuXG4iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCB7IENPTE9VUlMgfSBmcm9tICdjb25zdGFudHMnO1xuXG5leHBvcnQgY2xhc3MgQnV0dG9uIGV4dGVuZHMgUGhhc2VyLkdhbWVPYmplY3RzLlRleHQge1xuICBjb25zdHJ1Y3RvcihcbiAgICBzY2VuZTogUGhhc2VyLlNjZW5lLFxuICAgIHg6IG51bWJlcixcbiAgICB5OiBudW1iZXIsXG4gICAgdGV4dDogc3RyaW5nLFxuICAgIHN0eWxlOiB7fSxcbiAgICBjYWxsYmFja3M6IHtcbiAgICAgIFtrZXk6IHN0cmluZ106ICgpID0+IHZvaWQ7XG4gICAgfSxcbiAgKSB7XG4gICAgc3VwZXIoc2NlbmUsIHgsIHksIHRleHQsIHN0eWxlKTtcbiAgICB0aGlzLmRlZmF1bHRTdHlsZSA9IHN0eWxlO1xuICAgIHRoaXMuc2V0SW50ZXJhY3RpdmUoeyB1c2VIYW5kQ3Vyc29yOiB0cnVlIH0pXG4gICAgLm9uKCdwb2ludGVyb3ZlcicsICgpID0+IHtcbiAgICAgIHRoaXMuYnV0dG9uT3ZlcigpO1xuICAgICAgaWYgKGNhbGxiYWNrcyAmJiB0eXBlb2YgY2FsbGJhY2tzLnBvaW50ZXJvdmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wb2ludGVyb3ZlcigpO1xuICAgICAgfVxuICAgIH0pXG4gICAgLm9uKCdwb2ludGVyb3V0JywgKCkgPT4ge1xuICAgICAgdGhpcy5idXR0b25PdXQoKTtcbiAgICAgIGlmIChjYWxsYmFja3MgJiYgdHlwZW9mIGNhbGxiYWNrcy5wb2ludGVyb3V0ID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wb2ludGVyb3V0KCk7XG4gICAgICB9XG4gICAgfSlcbiAgICAub24oJ3BvaW50ZXJkb3duJywgKCkgPT4ge1xuICAgICAgdGhpcy5idXR0b25Eb3duKCk7XG4gICAgICBpZiAoY2FsbGJhY2tzICYmIHR5cGVvZiBjYWxsYmFja3MucG9pbnRlcmRvd24gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgY2FsbGJhY2tzLnBvaW50ZXJkb3duKCk7XG4gICAgICB9XG4gICAgfSlcbiAgICAub24oJ3BvaW50ZXJ1cCcsICgpID0+IHtcbiAgICAgIGlmIChjYWxsYmFja3MgJiYgdHlwZW9mIGNhbGxiYWNrcy5wb2ludGVydXAgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgY2FsbGJhY2tzLnBvaW50ZXJ1cCgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGJ1dHRvbk92ZXIoKSB7XG4gICAgdGhpcy5zZXRTdHlsZSh7XG4gICAgICBmaWxsOiBDT0xPVVJTLmdyZWVuLnN0cmluZyxcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBidXR0b25PdXQoKSB7XG4gICAgdGhpcy5zZXRTdHlsZSh0aGlzLmRlZmF1bHRTdHlsZSk7XG4gIH1cblxuICBwdWJsaWMgYnV0dG9uRG93bigpIHtcbiAgICB0aGlzLnNldFN0eWxlKHtcbiAgICAgIGZpbGw6IENPTE9VUlMuZ3JlZW4uc3RyaW5nLFxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQnV0dG9uIHtcbiAgZGVmYXVsdFN0eWxlOiB7fTtcbn0iLCJleHBvcnQgKiBmcm9tICcuL2J1dHRvbidcbmV4cG9ydCAqIGZyb20gJy4vd2l6YXJkJ1xuZXhwb3J0ICogZnJvbSAnLi9zcGVsbCdcbmV4cG9ydCAqIGZyb20gJy4vc3BpZGVyJyIsImltcG9ydCAqIGFzIFBoYXNlciBmcm9tICdwaGFzZXInO1xuaW1wb3J0IHsgU1BFTEwgfSBmcm9tICdjb25zdGFudHMnO1xuaW1wb3J0IHsgR2FtZVNjZW5lIH0gZnJvbSAnc3JjL3NjZW5lcy9nYW1lJztcblxuZXhwb3J0IGNsYXNzIFNwZWxsIGV4dGVuZHMgUGhhc2VyLlBoeXNpY3MuQXJjYWRlLlNwcml0ZSB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHNjZW5lOiBHYW1lU2NlbmUsXG4gICAgeDogbnVtYmVyLFxuICAgIHk6IG51bWJlcixcbiAgICB0ZXh0dXJlOiBzdHJpbmdcbiAgKSB7XG4gICAgc3VwZXIoc2NlbmUsIHgsIHksIHRleHR1cmUsIFNQRUxMKTtcbiAgICB0aGlzLnNldE9yaWdpbigwLCAwKVxuICAgIGNvbnN0IGFuZ2xlID0gUGhhc2VyLk1hdGguQW5nbGUuQmV0d2Vlbih0aGlzLngsIHRoaXMueSwgc2NlbmUucGxheWVyLngsIHNjZW5lLnBsYXllci55KVxuICAgIC8vIGFkZCA0NSBkZWdyZWVzIHRvIG9mZnNldCB0aGUgc3ByaXRlXG4gICAgdGhpcy5zZXRSb3RhdGlvbihhbmdsZSAtIDMuOTI2OTkpXG4gICAgXG4gICAgc2NlbmUucGh5c2ljcy5hZGQub3ZlcmxhcCh0aGlzLCBzY2VuZS5wbGF5ZXIsIChzcGVsbDogUGhhc2VyLlBoeXNpY3MuQXJjYWRlLlNwcml0ZSwgdGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgIGlmIChzY2VuZS5pc0RlYWQgfHwgc2NlbmUucmVsb2NhdGluZykgcmV0dXJuO1xuICAgICAgc2NlbmUua2lsbFBsYXllcigpXG4gICAgfSlcbiAgICBcbiAgICBzY2VuZS5waHlzaWNzLmFkZC5jb2xsaWRlcih0aGlzLCBzY2VuZS5ncm91bmRMYXllciwgKHNwZWxsOiBQaGFzZXIuUGh5c2ljcy5BcmNhZGUuU3ByaXRlLCB0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgc3BlbGwuZGVzdHJveSgpO1xuICAgIH0pXG4gIH1cbiAgXG59IiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgeyBTUElERVIgfSBmcm9tICdjb25zdGFudHMnO1xuaW1wb3J0IHsgR2FtZVNjZW5lIH0gZnJvbSAnc3JjL3NjZW5lcy9nYW1lJztcblxuZXhwb3J0IGNsYXNzIFNwaWRlciBleHRlbmRzIFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGUge1xuICBkaXJlY3Rpb246IDAgfCAxIHwgMiB8IDM7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHNjZW5lOiBHYW1lU2NlbmUsXG4gICAgeDogbnVtYmVyLFxuICAgIHk6IG51bWJlcixcbiAgICB0ZXh0dXJlOiBzdHJpbmdcbiAgKSB7XG4gICAgc3VwZXIoc2NlbmUsIHgsIHksIHRleHR1cmUsIFNQSURFUiAtIDEpO1xuICAgIHRoaXMuZGlyZWN0aW9uID0gMjtcbiAgICB0aGlzLnNldE9yaWdpbigwLjUsIDAuNSk7XG5cbiAgICBzY2VuZS5waHlzaWNzLmFkZC5jb2xsaWRlcih0aGlzLCBzY2VuZS5ncm91bmRMYXllciwgKHNwaWRlcjogUGhhc2VyLlBoeXNpY3MuQXJjYWRlLlNwcml0ZSwgdGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgIHRoaXMuZGlyZWN0aW9uID0gUGhhc2VyLk1hdGguV3JhcCh0aGlzLmRpcmVjdGlvbiArIDEsIDAsIDQpICBhcyAwIHwgMSB8IDIgfCAzIDtcbiAgICAgIHNwaWRlci5zZXRBbmdsZShzcGlkZXIuYW5nbGUgKyA5MCk7XG4gICAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgICAoKSA9PiBzcGlkZXIuc2V0VmVsb2NpdHkoMCwgLTEwMCksXG4gICAgICAgICgpID0+IHNwaWRlci5zZXRWZWxvY2l0eSgxMDAsIDApLFxuICAgICAgICAoKSA9PiBzcGlkZXIuc2V0VmVsb2NpdHkoMCwgMTAwKSxcbiAgICAgICAgKCkgPT4gc3BpZGVyLnNldFZlbG9jaXR5KC0xMDAsIDApLFxuICAgICAgXVxuICAgICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKVxuICAgIH0pXG4gICAgXG4gICAgc2NlbmUucGh5c2ljcy5hZGQub3ZlcmxhcCh0aGlzLCBzY2VuZS5wbGF5ZXIsIChzcGlkZXI6IFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGUsIHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICBpZiAoc2NlbmUuaXNEZWFkIHx8IHNjZW5lLnJlbG9jYXRpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2NlbmUua2lsbFBsYXllcigpXG4gICAgfSlcbiAgfVxufSIsImltcG9ydCAqIGFzIFBoYXNlciBmcm9tICdwaGFzZXInO1xuaW1wb3J0IHsgV0laQVJEIH0gZnJvbSAnY29uc3RhbnRzJztcbmltcG9ydCB7IFNwZWxsIH0gZnJvbSAnLi9zcGVsbCc7XG5pbXBvcnQgeyBHYW1lU2NlbmUgfSBmcm9tICdzcmMvc2NlbmVzL2dhbWUnO1xuXG5leHBvcnQgY2xhc3MgV2l6YXJkIGV4dGVuZHMgUGhhc2VyLkdhbWVPYmplY3RzLlNwcml0ZSB7XG4gIHNob290aW5nVGltZXI6IFBoYXNlci5UaW1lLlRpbWVyRXZlbnQ7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHNjZW5lOiBHYW1lU2NlbmUsXG4gICAgeDogbnVtYmVyLFxuICAgIHk6IG51bWJlcixcbiAgICB0ZXh0dXJlOiBzdHJpbmdcbiAgKSB7XG4gICAgc3VwZXIoc2NlbmUsIHgsIHksIHRleHR1cmUsIFdJWkFSRCAtIDEpO1xuICAgIHRoaXMuc2V0T3JpZ2luKDAsIDApO1xuICAgIHRoaXMuc2hvb3RpbmdUaW1lciA9IHNjZW5lLnRpbWUuYWRkRXZlbnQoeyBkZWxheTogMTAwMCwgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgIGlmIChzY2VuZS5pc0RlYWQgfHwgc2NlbmUucmVsb2NhdGluZykgcmV0dXJuXG4gICAgICBjb25zdCBzcGVsbCA9IG5ldyBTcGVsbChzY2VuZSwgeCwgeSwgdGV4dHVyZSk7XG4gICAgICBzY2VuZS5hZGQuZXhpc3Rpbmcoc3BlbGwpO1xuICAgICAgc2NlbmUucGh5c2ljcy5hZGQuZXhpc3Rpbmcoc3BlbGwpO1xuICAgICAgc2NlbmUucGh5c2ljcy5tb3ZlVG9PYmplY3Qoc3BlbGwsIHNjZW5lLnBsYXllcilcbiAgICAgIHNwZWxsLmJvZHkuc2V0U2l6ZSgyLCAyLCB0cnVlKVxuICAgICAgLy8gc3BlbGwuc2V0VmVsb2NpdHlYKC0xMDApO1xuICAgIH0sIGNhbGxiYWNrU2NvcGU6IHRoaXMsIGxvb3A6IHRydWUgfSk7XG4gIH1cbn0iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCBTY2VuZXMgZnJvbSAnc2NlbmVzJztcblxuY29uc3QgY29uZmlnOiBQaGFzZXIuVHlwZXMuQ29yZS5HYW1lQ29uZmlnID0ge1xuICB0aXRsZTogJ01peiBqYW0nLFxuICB0eXBlOiBQaGFzZXIuQVVUTyxcbiAgem9vbTogMixcbiAgc2NhbGU6IHtcbiAgICBwYXJlbnQ6ICdnYW1lJyxcbiAgICB3aWR0aDogODAwLFxuICAgIGhlaWdodDogNjAwLFxuICAgIGF1dG9DZW50ZXI6IFBoYXNlci5TY2FsZS5DRU5URVJfQk9USCxcbiAgICBtb2RlOiBQaGFzZXIuU2NhbGUuRklULFxuICB9LFxuICBwaHlzaWNzOiB7XG4gICAgZGVmYXVsdDogJ2FyY2FkZScsXG4gICAgYXJjYWRlOiB7XG4gICAgICAvLyB0aW1lU2NhbGU6IDQsXG4gICAgICBncmF2aXR5OiB7XG4gICAgICAgIHk6IDBcbiAgICAgIH0sXG4gICAgICAvLyBkZWJ1ZzogdHJ1ZVxuICAgIH1cbiAgfSxcbiAgLy8gY2FsbGJhY2tzOiB7XG4gIC8vICAgcG9zdEJvb3Q6IGZ1bmN0aW9uIChnYW1lKSB7XG4gIC8vICAgICBnYW1lLnNjZW5lLmR1bXAoKTtcbiAgLy8gICB9XG4gIC8vIH0sXG4gIHNjZW5lOiBTY2VuZXMsXG4gIHBhcmVudDogJ2dhbWUnLFxuICBiYWNrZ3JvdW5kQ29sb3I6IDB4NEIyQTNDLFxufTtcblxuZXhwb3J0IGNvbnN0IGdhbWUgPSBuZXcgUGhhc2VyLkdhbWUoY29uZmlnKTtcblxuIiwiaW1wb3J0ICogYXMgUGhhc2VyIGZyb20gJ3BoYXNlcic7XG5pbXBvcnQgeyBDT0xPVVJTIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcblxuY29uc3Qgc2NlbmVDb25maWc6IFBoYXNlci5UeXBlcy5TY2VuZXMuU2V0dGluZ3NDb25maWcgPSB7XG4gIGFjdGl2ZTogZmFsc2UsXG4gIHZpc2libGU6IGZhbHNlLFxuICBrZXk6ICdCb290Jyxcbn07XG5cbmV4cG9ydCBjbGFzcyBCb290U2NlbmUgZXh0ZW5kcyBQaGFzZXIuU2NlbmUge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcihzY2VuZUNvbmZpZyk7XG4gIH1cblxuICBwdWJsaWMgcHJlbG9hZCgpIHtcbiAgICAvKiogICAgXG4gICAgICogQ3JlYXRlIGEgcHJvZ3Jlc3MgYmFyIGdyYXBoaWNzICAgIFxuICAgICAqLyAgICAgXG4gICAgY29uc3QgcHJvZ3Jlc3NCYXIgPSB0aGlzLmFkZC5ncmFwaGljcygpO1xuICAgIGNvbnN0IHByb2dyZXNzQm94ID0gdGhpcy5hZGQuZ3JhcGhpY3MoKTtcbiAgICBwcm9ncmVzc0JveC5maWxsU3R5bGUoQ09MT1VSUy5kYXJrR3JheS5udW1iZXIsIDAuOCk7XG4gICAgcHJvZ3Jlc3NCb3guZmlsbFJlY3QoMjQwLCAyNzAsIDMyMCwgNTApO1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBBZGQgdGV4dCB0byB0aGUgbG9hZGVyICAgIFxuICAgICAqL1xuICAgIGNvbnN0IHsgY2VudGVyWCwgY2VudGVyWSB9ID0gdGhpcy5jYW1lcmFzLm1haW5cbiAgICBjb25zdCBsb2FkaW5nVGV4dCA9IHRoaXMubWFrZS50ZXh0KHtcbiAgICAgIHg6IGNlbnRlclgsXG4gICAgICB5OiBjZW50ZXJZLFxuICAgICAgdGV4dDogJ0xvYWRpbmcuLi4nLFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgZm9udDogJzIwcHggbW9ub3NwYWNlJyxcbiAgICAgICAgZmlsbDogQ09MT1VSUy53aGl0ZS5zdHJpbmdcbiAgICAgIH1cbiAgICB9KTtcbiAgICBsb2FkaW5nVGV4dC5zZXRPcmlnaW4oMC41LCAwLjUpO1xuICAgIFxuICAgIHRoaXMubG9hZC5vbigncHJvZ3Jlc3MnLCAodmFsdWU6IG51bWJlcikgPT4ge1xuICAgICAgcHJvZ3Jlc3NCYXIuY2xlYXIoKTtcbiAgICAgIHByb2dyZXNzQmFyLmZpbGxTdHlsZShDT0xPVVJTLndoaXRlLm51bWJlciwgMSk7XG4gICAgICBwcm9ncmVzc0Jhci5maWxsUmVjdCgyNTAsIDI4MCwgMzAwICogdmFsdWUsIDMwKTtcbiAgICB9KTtcbiAgICB0aGlzLmxvYWQub24oJ2ZpbGVwcm9ncmVzcycsIChmaWxlOiBGaWxlKSA9PiB7XG4gICAgICBsb2FkaW5nVGV4dC5zZXRUZXh0KGZpbGUuc3JjKTtcbiAgICB9KTtcbiAgICB0aGlzLmxvYWQub24oJ2NvbXBsZXRlJywgKCkgPT4ge1xuICAgICAgLyoqICAgICAgXG4gICAgICAgKiBEZXN0cm95IHRoZSBsb2FkaW5nIGJhciBncmFwaGljcyAgICAgIFxuICAgICAgICovICAgICAgIFxuICAgICAgcHJvZ3Jlc3NCYXIuZGVzdHJveSgpO1xuICAgICAgcHJvZ3Jlc3NCb3guZGVzdHJveSgpO1xuICAgICAgbG9hZGluZ1RleHQuZGVzdHJveSgpO1xuICAgICAgdGhpcy5zY2VuZS5zdGFydCgnVGl0bGUnKTtcbiAgICB9KTtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogTG9hZCB0aGUgYXNzZXRzICAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5sb2FkLnRpbGVtYXBUaWxlZEpTT04oJ3RpdGxlJywgJy4vYXNzZXRzL3RpdGxlLmpzb24nKTtcbiAgICB0aGlzLmxvYWQudGlsZW1hcFRpbGVkSlNPTignbWFwMCcsICcuL2Fzc2V0cy9sZXZlbDAuanNvbicpO1xuICAgIHRoaXMubG9hZC50aWxlbWFwVGlsZWRKU09OKCdtYXAxJywgJy4vYXNzZXRzL2xldmVsMS5qc29uJyk7XG4gICAgdGhpcy5sb2FkLnRpbGVtYXBUaWxlZEpTT04oJ21hcDInLCAnLi9hc3NldHMvbGV2ZWwyLmpzb24nKTtcbiAgICB0aGlzLmxvYWQudGlsZW1hcFRpbGVkSlNPTignbWFwMycsICcuL2Fzc2V0cy9sZXZlbDMuanNvbicpO1xuICAgIHRoaXMubG9hZC50aWxlbWFwVGlsZWRKU09OKCdtYXA0JywgJy4vYXNzZXRzL2xldmVsNC5qc29uJyk7XG4gICAgdGhpcy5sb2FkLnRpbGVtYXBUaWxlZEpTT04oJ21hcDUnLCAnLi9hc3NldHMvbGV2ZWw1Lmpzb24nKTtcbiAgICB0aGlzLmxvYWQuc3ByaXRlc2hlZXQoJ3RpbGVzJywgJy4vYXNzZXRzL3RpbGVzLnBuZycsIHsgXG4gICAgICBmcmFtZVdpZHRoOiAxNixcbiAgICAgIGZyYW1lSGVpZ2h0OiAxNixcbiAgICB9KTtcbiAgfVxufVxuXG50eXBlIEZpbGUgPSB7IFxuICBzcmM6IHN0cmluZ1xufSIsImltcG9ydCAqIGFzIFBoYXNlciBmcm9tICdwaGFzZXInO1xuaW1wb3J0IHsgU0lERV9VUCwgVE9QX0xFRlQsIFRPUCwgVE9QX1JJR0hULCBCT1RUT01fUklHSFQsIEJPVFRPTV9MRUZULCBMRUZULCBCT1RUT00sIFJJR0hULCBTVEFSVF9ET09SLCBET1dOX1NQSUtFLCBVUF9TUElLRSwgTEVGVF9TUElLRSwgUklHSFRfU1BJS0UsIENPTE9VUlMsIFJFRF9LRVksIEJMQU5LLCBSRURfRE9PUl9MT0NLRUQsIFJFRF9ET09SX0VOVFJBTkNFLCBSRURfRE9PUl9FWElULCBZRUxMT1dfS0VZLCBZRUxMT1dfRE9PUl9MT0NLRUQsIFlFTExPV19ET09SX0VOVFJBTkNFLCBZRUxMT1dfRE9PUl9FWElULCBCTFVFX0RPT1JfRVhJVCwgR1JFRU5fRE9PUl9FWElULCBCTFVFX0tFWSwgR1JFRU5fRE9PUl9MT0NLRUQsIEdSRUVOX0RPT1JfRU5UUkFOQ0UsIEJMVUVfRE9PUl9MT0NLRUQsIEJMVUVfRE9PUl9FTlRSQU5DRSwgR1JFRU5fS0VZLCBERUFELCBBTElWRSwgUlVOX0VORCwgV0laQVJELCBTUElERVIgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgV2l6YXJkLCBTcGlkZXIgfSBmcm9tICdnYW1lLW9iamVjdHMnO1xuIFxuXG5jb25zdCBzY2VuZUNvbmZpZzogUGhhc2VyLlR5cGVzLlNjZW5lcy5TZXR0aW5nc0NvbmZpZyA9IHtcbiAgYWN0aXZlOiBmYWxzZSxcbiAgdmlzaWJsZTogZmFsc2UsXG4gIGtleTogJ0dhbWUnLFxufTtcblxuZXhwb3J0IGNsYXNzIEdhbWVTY2VuZSBleHRlbmRzIFBoYXNlci5TY2VuZSB7XG4gIG1hcDogUGhhc2VyLlRpbGVtYXBzLlRpbGVtYXA7XG4gIHRpbGVzOiBQaGFzZXIuVGlsZW1hcHMuVGlsZXNldDtcbiAgZ3JvdW5kTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5TdGF0aWNUaWxlbWFwTGF5ZXI7XG4gIGNvbmZpZzogQ29uZmlnO1xuICBwbGF5ZXI6IFBoYXNlci5QaHlzaWNzLkFyY2FkZS5TcHJpdGU7XG4gIGRlYnVnR3JhcGhpYzogUGhhc2VyLkdhbWVPYmplY3RzLkdyYXBoaWNzO1xuICBjYW5GbGlwR3Jhdml0eTogYm9vbGVhbjtcbiAgY3Vyc29yczogUGhhc2VyLlR5cGVzLklucHV0LktleWJvYXJkLkN1cnNvcktleXM7XG4gIHJvdGF0aW5nOiBib29sZWFuO1xuICBkaXJlY3Rpb246IDAgfCAxIHwgMiB8IDM7XG4gIGlzRmxpcHBlZDogYm9vbGVhbjtcbiAgYmdMYXllcjogUGhhc2VyLlRpbGVtYXBzLlN0YXRpY1RpbGVtYXBMYXllcjtcbiAgc3Bpa2VzTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5EeW5hbWljVGlsZW1hcExheWVyO1xuICBpc0RlYWQ6IGJvb2xlYW47XG4gIGFjdGlvbnNMYXllcjogUGhhc2VyLlRpbGVtYXBzLkR5bmFtaWNUaWxlbWFwTGF5ZXI7XG4gIGl0ZW1zOiBhbnlbXTtcbiAgcmVsb2NhdGluZzogYm9vbGVhbjtcbiAgY2hlY2twb2ludDogUGhhc2VyLlRpbGVtYXBzLlRpbGU7XG4gIGxldmVsOiBudW1iZXI7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHNjZW5lQ29uZmlnKTtcbiAgfVxuICBcbiAgcHVibGljIGluaXQoeyBsZXZlbCB9OiB7XG4gICAgbGV2ZWw6IG51bWJlcjtcbiAgfSkge1xuICAgIHRoaXMubGV2ZWwgPSBsZXZlbDtcbiAgfVxuICBcbiAgcHVibGljIHByZWxvYWQoKSB7XG4gICAgdGhpcy5pc0RlYWQgPSBmYWxzZTtcbiAgICAvKiogICAgXG4gICAgICogVXNlIHRoZXNlIHRvIGNvbnRyb2wgdGhlIHNwZWVkIGFuZCBncmF2aXR5IG9mIHRoZSBwbGF5ZXIgICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLmNvbmZpZyA9IHtcbiAgICAgIGdyYXZpdHk6IDEyMDAsXG4gICAgICBzcGVlZDogMTIwLFxuICAgICAgZ3Jhdml0eURpcmVjdGlvbjogMSxcbiAgICAgIGp1bXBGb3JjZTogMjU1LFxuICAgIH1cbiAgICBcbiAgICAvKiogICAgXG4gICAgICogVGhpcyB3aWxsIGJlIHNldCB0byBmYWxzZSB3aGlsc3QgdGhlIGNoYXJhY3RlciBpcyBmYWxsaW5nIHNvIHRoYXQgdGhleSBjYW5ub3QgZmxpcCBncmF2aXR5IGhhbGZcbiAgICAgKiB3YXkgdGhyb3VnaCBmYWxsaW5nLiAgICBcbiAgICAgKi8gICAgIFxuICAgIHRoaXMuY2FuRmxpcEdyYXZpdHkgPSB0cnVlO1xuICAgIHRoaXMuaXNGbGlwcGVkID0gZmFsc2U7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIFdlIHdpbGwgdXNlIHRoZXNlIHZhbHVlcyB0byByb3RhdGUgdGhlIHNwcml0ZSBhcm91bmQgY29ybmVyc1xuICAgICAqLyAgICAgXG4gICAgdGhpcy5yb3RhdGluZyA9IGZhbHNlO1xuICAgIHRoaXMuZGlyZWN0aW9uID0gU0lERV9VUDtcbiAgICBcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogV2Ugd2lsbCB1c2UgdGhpcyB2YWx1ZSB0byBkZWZpbmUgd2hldGhlciBvciBub3QgdGhlIHVzZSBpcyBtb3ZpbmcgYmV0d2VlbiAyIGRvb3JzLiAgICBcbiAgICAgKi8gICAgIFxuICAgIHRoaXMucmVsb2NhdGluZyA9IGZhbHNlO1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBBbnkgaXRlbXMgdGhhdCB0aGUgcGxheWVyIHBpY2tzIHVwIHdpbGwgYmUgc3RvcmVkIGluIHRoaXMgYXJyYXkgICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLml0ZW1zID0gW107XG4gIH1cbiAgXG4gIHB1YmxpYyBjcmVhdGUoKSB7XG4gICAgY29uc3QgeyBTUEFDRSwgRSB9ID0gUGhhc2VyLklucHV0LktleWJvYXJkLktleUNvZGVzO1xuICAgIC8vIERlZmluZSB0aGUgYXJyb3cga2V5c1xuICAgIHRoaXMuY3Vyc29ycyA9IHRoaXMuaW5wdXQua2V5Ym9hcmQuY3JlYXRlQ3Vyc29yS2V5cygpO1xuICAgIC8vIERlZmluZSBFIGtleVxuICAgIGNvbnN0IGVLZXkgPSB0aGlzLmlucHV0LmtleWJvYXJkLmFkZEtleShFKTtcbiAgICAvLyBEZWZpbmUgc3BhY2ViYXIga2V5XG4gICAgY29uc3Qgc3BhY2VLZXkgPSB0aGlzLmlucHV0LmtleWJvYXJkLmFkZEtleShTUEFDRSk7XG4gICAgXG4gICAgLyoqICAgIFxuICAgICAqIENyZWF0ZSB0aGUgbWFwIGFuZCB0aGUgcGxhdGZvcm0gbGF5ZXIgICAgXG4gICAgICovICAgICBcbiAgICB0aGlzLm1hcCA9IHRoaXMubWFrZS50aWxlbWFwKHsga2V5OiBgbWFwJHt0aGlzLmxldmVsfWAgfSk7XG4gICAgdGhpcy50aWxlcyA9IHRoaXMubWFwLmFkZFRpbGVzZXRJbWFnZSgndGlsZXMnKTtcbiAgICB0aGlzLmJnTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVTdGF0aWNMYXllcignQmFja2dyb3VuZCcsIHRoaXMudGlsZXMpXG4gICAgdGhpcy5ncm91bmRMYXllciA9IHRoaXMubWFwLmNyZWF0ZVN0YXRpY0xheWVyKCdHcm91bmQnLCB0aGlzLnRpbGVzKVxuICAgIHRoaXMuc3Bpa2VzTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVEeW5hbWljTGF5ZXIoJ1NwaWtlcycsIHRoaXMudGlsZXMpXG4gICAgdGhpcy5hY3Rpb25zTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVEeW5hbWljTGF5ZXIoJ0FjdGlvbnMnLCB0aGlzLnRpbGVzKVxuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBTZXQgdGhlIGdyb3VuZCBsYXllciB0byBiZSBoYXZlIGFueSB0aWxlcyB3aXRoIGluZGV4IDEgb3IgMCBub3QgYmUgY29saWRhYmxlLlxuICAgICAqIFRpbGVzIDEgYW5kIDAgYXJlIHRoZSBiYWNrZ3JvdW5kLyBibGFuayB0aWxlcy4gICAgIFxuICAgICAqL1xuICAgIHRoaXMuZ3JvdW5kTGF5ZXIuc2V0Q29sbGlzaW9uQnlFeGNsdXNpb24oWzAsIDFdKTtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogVGhlIHRpbGVzIHdpbGwgcHJvYmFibHkgZ28gYWxsIHRoZSB3YXkgYXJvdW5kIHRoZSBlZGdlIG9mIHRoZSBtYXAgdG9cbiAgICAgKiBwcmV2ZW50IHRoZSBwbGF5ZXIgZnJvbSBnb2luZyBvZmYgY2FudmFzLlxuICAgICAqIEp1c3QgaW4gY2FzZSB0aG91Z2ggbWFrZSB0aGV5IHBsYXllciBjb2xsaWRlIHdpdGggdGhlIGJvdW5kcy5cbiAgICAgKiBIZXJlIHdlIGFyZSBqdXN0IGNyZWF0aW5nIHRoZSBib3VuZHMgYmFzZWQgb24gdGhlIHRpbGVtYXAgc2l6ZS5cbiAgICAgKiBMYXRlciB3ZSB3aWxsIGFkZCBhIGNvbGxpc2lvbiAgXG4gICAgICovICAgICBcbiAgICB0aGlzLnBoeXNpY3Mud29ybGQuYm91bmRzLndpZHRoID0gdGhpcy5ncm91bmRMYXllci53aWR0aDtcbiAgICB0aGlzLnBoeXNpY3Mud29ybGQuYm91bmRzLmhlaWdodCA9IHRoaXMuZ3JvdW5kTGF5ZXIuaGVpZ2h0O1xuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBDcmVhdGUgYSBuZXcgc3ByaXRlIGFuZCBhZGQgaXQgdG8gdGhlIHBoeXNpY3Mgb2YgdGhlIHNjZW5lLiBcbiAgICAgKiBXZSB0aGVuIHNldCB0aGUgdmVydGljYWwgZ3Jhdml0eSBvZiB0aGUgc3ByaXRlIHNvIHRoYXQgaXQgZmFsbHMuICBcbiAgICAgKi8gICBcbiAgICBjb25zdCBzdGFydFRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChTVEFSVF9ET09SKTsgIFxuICAgIGNvbnN0IHJlZERvb3JFeGl0VGlsZSA9IHRoaXMuYWN0aW9uc0xheWVyLmZpbmRCeUluZGV4KFJFRF9ET09SX0VYSVQpO1xuICAgIGNvbnN0IGJsdWVEb29yRXhpdFRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChCTFVFX0RPT1JfRVhJVCk7XG4gICAgY29uc3QgeWVsbG93RG9vckV4aXRUaWxlID0gdGhpcy5hY3Rpb25zTGF5ZXIuZmluZEJ5SW5kZXgoWUVMTE9XX0RPT1JfRVhJVCk7XG4gICAgXG4gICAgXG4gICAgdGhpcy5jaGVja3BvaW50ID0gc3RhcnRUaWxlO1xuICAgIFxuICAgIHRoaXMucGxheWVyID0gdGhpcy5waHlzaWNzLmFkZC5zcHJpdGUoc3RhcnRUaWxlLnBpeGVsWCArIDgsIHN0YXJ0VGlsZS5waXhlbFkgKyA1LCAndGlsZXMnLCBBTElWRSk7XG4gICAgLy8gdGhpcy5wbGF5ZXIuc2V0T3JpZ2luKDAsIDApXG4gICAgdGhpcy5wbGF5ZXIuYm9keS5ncmF2aXR5LnNldCgwLCB0aGlzLmNvbmZpZy5ncmF2aXR5KTtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogQ3JlYXRlIHdhbGtpbmcgYW5pbWF0aW9ucyAgICBcbiAgICAgKi8gICAgIFxuICAgIHRoaXMuYW5pbXMuY3JlYXRlKHtcbiAgICAgIGtleTogJ3J1bm5pbmcnLFxuICAgICAgZnJhbWVzOiB0aGlzLmFuaW1zLmdlbmVyYXRlRnJhbWVOdW1iZXJzKCd0aWxlcycsIHsgc3RhcnQ6IEFMSVZFLCBlbmQ6IFJVTl9FTkQgfSksXG4gICAgICBmcmFtZVJhdGU6IDEwLFxuICAgICAgcmVwZWF0OiAtMSxcbiAgICB9KVxuICAgIFxuICAgIC8qKiAgICBcbiAgICAgKiBDb2xsaWRlIHRoZSBwbGF5ZXIgd2l0aCB0aGUgY29saWRhYmxlIHRpbGVzIGluIHRoZSB0aWxlbWFwICAgIFxuICAgICAqLyAgICAgXG4gICAgLy8gdGhpcy5wbGF5ZXIuc2V0Q29sbGlkZVdvcmxkQm91bmRzKHRydWUpO1xuICAgIHRoaXMucGh5c2ljcy5hZGQuY29sbGlkZXIodGhpcy5wbGF5ZXIsIHRoaXMuZ3JvdW5kTGF5ZXIsIChwbGF5ZXI6IEdhbWVTY2VuZVsncGxheWVyJ10sIHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICBpZiAodGhpcy5pc0RlYWQgfHwgdGhpcy5yZWxvY2F0aW5nKSB7XG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLnJvdGF0aW5nKSB7XG4gICAgICAgIHRoaXMuY2hlY2tSb3RhdGlvbih0aWxlLCBwbGF5ZXIpO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLmNhbkZsaXBHcmF2aXR5KSB7XG4gICAgICAgIHRoaXMuY2FuRmxpcEdyYXZpdHkgPSB0cnVlO1xuICAgICAgfVxuICAgIH0sICgpID0+IHtcbiAgICAgIHJldHVybiAhdGhpcy5pc0RlYWQgJiYgIXRoaXMucmVsb2NhdGluZztcbiAgICB9KVxuICAgIFxuICAgIHRoaXMucGh5c2ljcy5hZGQub3ZlcmxhcCh0aGlzLnBsYXllciwgdGhpcy5zcGlrZXNMYXllciwgKHBsYXllcjogR2FtZVNjZW5lWydwbGF5ZXInXSwgdGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgIGlmICh0aGlzLmlzRGVhZCB8fCB0aGlzLnJlbG9jYXRpbmcpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICBcbiAgICAgIHRoaXMua2lsbFBsYXllcigpO1xuICAgIH0sIChwbGF5ZXIsIHRpbGUpID0+IHtcbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSAxIHx8IHRoaXMuaXNEZWFkIHx8IHRoaXMucmVsb2NhdGluZykge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSBVUF9TUElLRSkge1xuICAgICAgICBpZiAocGxheWVyLnkgPiB0aWxlLnBpeGVsWSAtIDQgJiYgcGxheWVyLnggPj0gdGlsZS5waXhlbFggLSA1KSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHRpbGUuaW5kZXggPT09IERPV05fU1BJS0UpIHtcbiAgICAgICAgaWYgKHBsYXllci55IDwgdGlsZS5waXhlbFkgKyAxNSAmJiBwbGF5ZXIueCA+PSB0aWxlLnBpeGVsWCAtIDUpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAodGlsZS5pbmRleCA9PT0gTEVGVF9TUElLRSkge1xuICAgICAgICBpZiAocGxheWVyLnggPj0gdGlsZS5waXhlbFggKyA1KSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHRpbGUuaW5kZXggPT09IFJJR0hUX1NQSUtFKSB7XG4gICAgICAgIGlmIChwbGF5ZXIueCA8PSB0aWxlLnBpeGVsWCArIDE0KSB7XG4gICAgICAgICAgcmV0dXJuIHRydWVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSlcbiAgICBcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogRmlyZWQgd2hlbiB0aGUgcGxheWVyIG92ZXJsYXBzIHdpdGggdGhlIGFjdGlvbiB0aWxlczogZG9vcnMgYW5kIGtleXMgZXRjICAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5waHlzaWNzLmFkZC5vdmVybGFwKHRoaXMucGxheWVyLCB0aGlzLmFjdGlvbnNMYXllciwgKF9wbGF5ZXIsIHRpbGUpID0+IHtcbiAgICAgIGNvbnN0IGFjdGlvbnMgPSB7XG4gICAgICAgIFtSRURfS0VZXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgdGhpcy5waWNrdXBJdGVtKFJFRF9LRVksIHRpbGUpXG4gICAgICAgIH0sXG4gICAgICAgIFtZRUxMT1dfS0VZXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgdGhpcy5waWNrdXBJdGVtKFlFTExPV19LRVksIHRpbGUpXG4gICAgICAgIH0sXG4gICAgICAgIFtCTFVFX0tFWV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGlja3VwSXRlbShCTFVFX0tFWSwgdGlsZSlcbiAgICAgICAgfSxcbiAgICAgICAgW0dSRUVOX0tFWV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucGlja3VwSXRlbShHUkVFTl9LRVksIHRpbGUpXG4gICAgICAgIH0sXG4gICAgICAgIFtSRURfRE9PUl9MT0NLRURdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5pdGVtcy5pbmNsdWRlcyhSRURfS0VZKSkge1xuICAgICAgICAgICAgdGhpcy5hY3Rpb25zTGF5ZXIucHV0VGlsZUF0KFJFRF9ET09SX0VOVFJBTkNFLCB0aWxlLngsIHRpbGUueSlcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFtSRURfRE9PUl9FTlRSQU5DRV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMucmVsb2NhdGUocmVkRG9vckV4aXRUaWxlKTtcbiAgICAgICAgfSxcbiAgICAgICAgW1JFRF9ET09SX0VYSVRdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICAvLyBGaW5kIHRoZSB0aWxlIGhlcmUgYmVjYXVzZSBpdCBtYXkgbm90IGV4aXN0IGF0IHRoZSBzdGFydCBvZiB0aGUgZ2FtZVxuICAgICAgICAgIGNvbnN0IHJlZERvb3JFbnRyYW5jZVRpbGUgPSB0aGlzLmFjdGlvbnNMYXllci5maW5kQnlJbmRleChSRURfRE9PUl9FTlRSQU5DRSk7XG4gICAgICAgICAgdGhpcy5yZWxvY2F0ZShyZWREb29yRW50cmFuY2VUaWxlKTtcbiAgICAgICAgfSxcbiAgICAgICAgW1lFTExPV19ET09SX0xPQ0tFRF06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLml0ZW1zLmluY2x1ZGVzKFlFTExPV19LRVkpKSB7XG4gICAgICAgICAgICB0aGlzLmFjdGlvbnNMYXllci5wdXRUaWxlQXQoWUVMTE9XX0RPT1JfRU5UUkFOQ0UsIHRpbGUueCwgdGlsZS55KVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgW1lFTExPV19ET09SX0VOVFJBTkNFXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZWxvY2F0ZSh5ZWxsb3dEb29yRXhpdFRpbGUpO1xuICAgICAgICB9LFxuICAgICAgICBbWUVMTE9XX0RPT1JfRVhJVF06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIC8vIEZpbmQgdGhlIHRpbGUgaGVyZSBiZWNhdXNlIGl0IG1heSBub3QgZXhpc3QgYXQgdGhlIHN0YXJ0IG9mIHRoZSBnYW1lXG4gICAgICAgICAgY29uc3QgeWVsbG93RG9vckVudHJhbmNlVGlsZSA9IHRoaXMuYWN0aW9uc0xheWVyLmZpbmRCeUluZGV4KFlFTExPV19ET09SX0VOVFJBTkNFKTtcbiAgICAgICAgICB0aGlzLnJlbG9jYXRlKHllbGxvd0Rvb3JFbnRyYW5jZVRpbGUpO1xuICAgICAgICB9LFxuICAgICAgICBbR1JFRU5fRE9PUl9MT0NLRURdOiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgICAgICBpZiAodGhpcy5pdGVtcy5pbmNsdWRlcyhHUkVFTl9LRVkpKSB7XG4gICAgICAgICAgICB0aGlzLmFjdGlvbnNMYXllci5wdXRUaWxlQXQoR1JFRU5fRE9PUl9FTlRSQU5DRSwgdGlsZS54LCB0aWxlLnkpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbR1JFRU5fRE9PUl9FTlRSQU5DRV06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIHRoaXMuZXZlbnRzLmVtaXQoJ2NvbXBsZXRlZCcpO1xuICAgICAgICB9LFxuICAgICAgICBbQkxVRV9ET09SX0xPQ0tFRF06ICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLml0ZW1zLmluY2x1ZGVzKEJMVUVfS0VZKSkge1xuICAgICAgICAgICAgdGhpcy5hY3Rpb25zTGF5ZXIucHV0VGlsZUF0KEJMVUVfRE9PUl9FTlRSQU5DRSwgdGlsZS54LCB0aWxlLnkpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBbQkxVRV9ET09SX0VOVFJBTkNFXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZWxvY2F0ZShibHVlRG9vckV4aXRUaWxlKTtcbiAgICAgICAgfSxcbiAgICAgICAgW0JMVUVfRE9PUl9FWElUXTogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgICAgLy8gRmluZCB0aGUgdGlsZSBoZXJlIGJlY2F1c2UgaXQgbWF5IG5vdCBleGlzdCBhdCB0aGUgc3RhcnQgb2YgdGhlIGdhbWVcbiAgICAgICAgICBjb25zdCBibHVlRG9vckVudHJhbmNlVGlsZSA9IHRoaXMuYWN0aW9uc0xheWVyLmZpbmRCeUluZGV4KEJMVUVfRE9PUl9FTlRSQU5DRSk7XG4gICAgICAgICAgdGhpcy5yZWxvY2F0ZShibHVlRG9vckVudHJhbmNlVGlsZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGFjdGlvbnNbdGlsZS5pbmRleF0odGlsZSlcbiAgICAgIFxuICAgIH0sIChfcGxheWVyLCB7IGluZGV4IH06IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICBpZiAodGhpcy5pc0RlYWQgfHwgdGhpcy5yZWxvY2F0aW5nKSB7XG4gICAgICAgIHJldHVybiBmYWxzZVxuICAgICAgfVxuICAgICAgaWYgKCFlS2V5LmlzRG93bikge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICAgIC8vIEEgbGlzdCBvZiB0aGUgaW50ZXJhY3RpYmxlIHRpbGVzXG4gICAgICBjb25zdCBhY3Rpb25zID0gW1JFRF9LRVksIFlFTExPV19LRVksIEJMVUVfS0VZLCBHUkVFTl9LRVksIFJFRF9ET09SX0xPQ0tFRCwgUkVEX0RPT1JfRU5UUkFOQ0UsIFJFRF9ET09SX0VYSVQsIFlFTExPV19ET09SX0xPQ0tFRCwgWUVMTE9XX0RPT1JfRU5UUkFOQ0UsIFlFTExPV19ET09SX0VYSVQsIEJMVUVfRE9PUl9MT0NLRUQsIEJMVUVfRE9PUl9FTlRSQU5DRSwgQkxVRV9ET09SX0VYSVQsIEdSRUVOX0RPT1JfTE9DS0VELCBHUkVFTl9ET09SX0VOVFJBTkNFLCBHUkVFTl9ET09SX0VYSVRdO1xuICAgICAgcmV0dXJuIGFjdGlvbnMuaW5jbHVkZXMoaW5kZXgpXG4gICAgfSlcbiAgICAvKiogICAgXG4gICAgICogV2hlbiB0aGUgc3BhY2Uga2V5IGlzIHByZXNzZWQsIGlmIGdyYXZpdHkgY2FuIGJlIGZsaXBwZWQ6XG4gICAgICogRmxpcCBpdCBhbmQgaW52ZXJ0IHRoZSBwbGF5ZXJzIGdyYXZpdHkgYW5kIGRpc2FibGUgZ3Jhdml0eSBmbGlwcGluZyB1bnRpbCB0aGVyZSBpcyBhIGNvbGxpc2lvbiB3aXRoIHRoZSBncm91bmQuICAgIFxuICAgICAqLyAgICAgXG4gICAgc3BhY2VLZXkub24oXCJkb3duXCIsICgpID0+IHRoaXMuZmxpcCgpKTtcbiAgICBcbiAgICAvKiogICAgXG4gICAgICogc2V0IHRoZSBjYW1lcmEgdG8gbm90IGdvIG91dCBvZiB0aGUgYm91bmRzIGJ1dCBmb2xsb3cgdGhlIHBsYXllciwga2VlcGluZyB0aGVtIGluIHRoZSBjZW50ZXIuICAgIFxuICAgICAqLyAgICAgXG4gICAgLy8gdGhpcy5jYW1lcmFzLm1haW4uc2V0Qm91bmRzKDAsIDAsIDgwMCwgNjAwKTtcbiAgICB0aGlzLmNhbWVyYXMubWFpbi5zdGFydEZvbGxvdyh0aGlzLnBsYXllcik7XG4gICAgdGhpcy5jYW1lcmFzLm1haW4uc2V0Wm9vbSgyKTtcbiAgICBcbiAgICAvKipcbiAgICAgKiBDcmVhdGUgZW5lbWllcyAgIFxuICAgICAqLyAgICAgXG4gICAgdGhpcy5zcGlrZXNMYXllci5mb3JFYWNoVGlsZSgodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHtcbiAgICAgIGlmICh0aWxlLmluZGV4ID09PSBXSVpBUkQpIHtcbiAgICAgICAgdGhpcy5zcGlrZXNMYXllci5wdXRUaWxlQXQoQkxBTkssIHRpbGUueCwgdGlsZS55KTtcbiAgICAgICAgY29uc3Qgd2l6YXJkID0gbmV3IFdpemFyZCh0aGlzLCB0aWxlLnBpeGVsWCwgdGlsZS5waXhlbFksICd0aWxlcycpXG4gICAgICAgIHRoaXMuYWRkLmV4aXN0aW5nKHdpemFyZClcbiAgICAgIH07XG4gICAgICBpZiAodGlsZS5pbmRleCA9PT0gU1BJREVSKSB7XG4gICAgICAgIHRoaXMuc3Bpa2VzTGF5ZXIucHV0VGlsZUF0KEJMQU5LLCB0aWxlLngsIHRpbGUueSk7XG4gICAgICAgIGNvbnN0IHNwaWRlciA9IG5ldyBTcGlkZXIodGhpcywgdGlsZS5waXhlbFgsIHRpbGUucGl4ZWxZLCAndGlsZXMnKVxuICAgICAgICB0aGlzLmFkZC5leGlzdGluZyhzcGlkZXIpXG4gICAgICAgIHRoaXMucGh5c2ljcy5hZGQuZXhpc3Rpbmcoc3BpZGVyKVxuICAgICAgICBzcGlkZXIuc2V0VmVsb2NpdHlZKDEwMCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgXG4gIHB1YmxpYyB1cGRhdGUoKSB7ICAgXG4gICAgaWYgKHRoaXMuaXNEZWFkIHx8IHRoaXMucmVsb2NhdGluZykge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmICh0aGlzLmN1cnNvcnMudXAuaXNEb3duKSB7XG4gICAgICB0aGlzLmp1bXAoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuY3Vyc29ycy5sZWZ0LmlzRG93biAmJiAhdGhpcy5jdXJzb3JzLnJpZ2h0LmlzRG93bikge1xuICAgICAgdGhpcy5wbGF5ZXIuYW5pbXMucGxheSgncnVubmluZycsIHRydWUpXG4gICAgICBpZiAoIXRoaXMuaXNGbGlwcGVkKSB7XG4gICAgICAgIHRoaXMubW92ZUNvdW50ZXJDbG9ja3dpc2UoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubW92ZUNsb2Nrd2lzZSgpO1xuICAgICAgfVxuICAgICAgXG4gICAgfSBlbHNlIGlmICh0aGlzLmN1cnNvcnMucmlnaHQuaXNEb3duICYmICF0aGlzLmN1cnNvcnMubGVmdC5pc0Rvd24pIHtcbiAgICAgIHRoaXMucGxheWVyLmFuaW1zLnBsYXkoJ3J1bm5pbmcnLCB0cnVlKVxuICAgICAgaWYgKHRoaXMuaXNGbGlwcGVkKSB7XG4gICAgICAgIHRoaXMubW92ZUNvdW50ZXJDbG9ja3dpc2UoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubW92ZUNsb2Nrd2lzZSgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnN0b3BNb3ZpbmcoKVxuICAgIH1cbiAgICB0aGlzLnBoeXNpY3Mud29ybGQud3JhcCh0aGlzLnBsYXllcik7XG4gIH1cbiAgXG4gIHByaXZhdGUgbW92ZUNvdW50ZXJDbG9ja3dpc2UoKSB7XG4gICAgdGhpcy5wbGF5ZXIuc2V0RmxpcFgoIXRoaXMuaXNGbGlwcGVkKTtcbiAgICBjb25zdCBkaXJlY3Rpb25zID0gW1xuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSgtdGhpcy5jb25maWcuc3BlZWQsIHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueSlcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueCwgLXRoaXMuY29uZmlnLnNwZWVkKVxuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkodGhpcy5jb25maWcuc3BlZWQsIHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueSlcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KC10aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LngsIHRoaXMuY29uZmlnLnNwZWVkKVxuICAgICAgfSwgIFxuICAgIF1cbiAgICBkaXJlY3Rpb25zW3RoaXMuZGlyZWN0aW9uXSgpO1xuICB9XG4gIFxuICBwcml2YXRlIG1vdmVDbG9ja3dpc2UoKSB7XG4gICAgdGhpcy5wbGF5ZXIuc2V0RmxpcFgodGhpcy5pc0ZsaXBwZWQpO1xuICAgIGNvbnN0IGRpcmVjdGlvbnMgPSBbXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMuY29uZmlnLnNwZWVkLCB0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LnkpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkodGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS54LCB0aGlzLmNvbmZpZy5zcGVlZCk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSgtdGhpcy5jb25maWcuc3BlZWQsIHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueSk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSh0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LngsIC10aGlzLmNvbmZpZy5zcGVlZCk7XG4gICAgICB9XG4gICAgXVxuICAgIGRpcmVjdGlvbnNbdGhpcy5kaXJlY3Rpb25dKCk7XG4gIH1cbiAgXG4gIHByaXZhdGUgc3RvcE1vdmluZygpIHtcbiAgICB0aGlzLnBsYXllci5hbmltcy5zdG9wKCk7XG4gICAgY29uc3QgZGlyZWN0aW9ucyA9IFtcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkoMCwgdGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS55KTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KHRoaXMucGxheWVyLmJvZHkudmVsb2NpdHkueCwgMCk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eSgwLCB0aGlzLnBsYXllci5ib2R5LnZlbG9jaXR5LnkpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkodGhpcy5wbGF5ZXIuYm9keS52ZWxvY2l0eS54LCAwKTtcbiAgICAgIH1cbiAgICBdXG4gICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBqdW1wKCkge1xuICAgIGNvbnN0IGRpcmVjdGlvbnMgPSBbXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnBsYXllci5ib2R5LmJsb2NrZWQuZG93bikge1xuICAgICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5WSgtdGhpcy5jb25maWcuanVtcEZvcmNlKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMucGxheWVyLmJvZHkuYmxvY2tlZC5sZWZ0KSB7XG4gICAgICAgICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHlYKHRoaXMuY29uZmlnLmp1bXBGb3JjZSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLnBsYXllci5ib2R5LmJsb2NrZWQudXApIHtcbiAgICAgICAgICB0aGlzLnBsYXllci5zZXRWZWxvY2l0eVkodGhpcy5jb25maWcuanVtcEZvcmNlKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMucGxheWVyLmJvZHkuYmxvY2tlZC5yaWdodCkge1xuICAgICAgICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5WCgtdGhpcy5jb25maWcuanVtcEZvcmNlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIF1cbiAgICBkaXJlY3Rpb25zW3RoaXMuZGlyZWN0aW9uXSgpO1xuICB9XG4gIFxuICBwcml2YXRlIGNoZWNrUm90YXRpb24oeyBpbmRleCwgLi4udGlsZX0sIHt4LCB5IC4uLnBsYXllcn0pIHtcbiAgICBpZiAodGhpcy5yb3RhdGluZykgcmV0dXJuO1xuICAgIFxuICAgIGNvbnN0IGRpcmVjdGlvbnMgPSBbXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmIChpbmRleCA9PT0gVE9QX1JJR0hUICYmIHggPj0gdGlsZS5waXhlbFggKyAyMCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS54ID4gMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCArIDQsIHkgKyA4KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gVE9QX0xFRlQgJiYgeCA8PSB0aWxlLnBpeGVsWCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS54IDwgMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHggLSA4LCB5ICsgOClcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IFJJR0hUKSB7XG4gICAgICAgICAgdGhpcy5oYW5kbGVSb3RhdGlvbigxLCB4LCB5KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gTEVGVCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmIChpbmRleCA9PT0gQk9UVE9NX1JJR0hUICYmIHkgPj0gdGlsZS5waXhlbFkgKyAyMCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS55ID4gMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCAtIDgsIHkpXG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluZGV4ID09PSBUT1BfUklHSFQgJiYgeSA8PSB0aWxlLnBpeGVsWSAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS55IDwgMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHggLSA4LCB5IC0gOClcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IEJPVFRPTSkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IFRPUCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHgsIHkpXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGlmIChpbmRleCA9PT0gQk9UVE9NX0xFRlQgJiYgeCA8PSB0aWxlLnBpeGVsWCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS54IDwgMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCAtIDgsIHkgLSA4KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gQk9UVE9NX1JJR0hUICYmIHggPj0gdGlsZS5waXhlbFggKyAyMCAmJiBwbGF5ZXIuYm9keS52ZWxvY2l0eS54ID4gMCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oLTEsIHgsIHkgLSA4KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gUklHSFQpIHtcbiAgICAgICAgICB0aGlzLmhhbmRsZVJvdGF0aW9uKC0xLCB4LCB5KVxuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gTEVGVCkge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgaWYgKGluZGV4ID09PSBUT1BfTEVGVCAmJiB5IDw9IHRpbGUucGl4ZWxZICYmIHBsYXllci5ib2R5LnZlbG9jaXR5LnkgPCAwKSB7XG4gICAgICAgICAgdGhpcy5oYW5kbGVSb3RhdGlvbigxLCB4ICsgOCwgeSAtIDgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gQk9UVE9NX0xFRlQgJiYgeSA+PSB0aWxlLnBpeGVsWSArIDIwICYmIHBsYXllci5ib2R5LnZlbG9jaXR5LnkgPiAwKSB7XG4gICAgICAgICAgdGhpcy5oYW5kbGVSb3RhdGlvbigtMSwgeCArIDgsIHkpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbmRleCA9PT0gQk9UVE9NICYmICF0aGlzLnJvdGF0aW5nKSB7XG4gICAgICAgICAgdGhpcy5oYW5kbGVSb3RhdGlvbigtMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5kZXggPT09IFRPUCAmJiAhdGhpcy5yb3RhdGluZykge1xuICAgICAgICAgIHRoaXMuaGFuZGxlUm90YXRpb24oMSwgeCwgeSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIF1cbiAgICBcbiAgICBkaXJlY3Rpb25zW3RoaXMuZGlyZWN0aW9uXSgpO1xuICB9XG4gIFxuICBwcml2YXRlIGhhbmRsZVJvdGF0aW9uKGRlbHRhOiBudW1iZXIsIHg6IG51bWJlciwgeTogbnVtYmVyKSB7XG4gICAgdGhpcy5wbGF5ZXIuYm9keS5zZXRBbGxvd0dyYXZpdHkoZmFsc2UpO1xuICAgIHRoaXMucGxheWVyLnNldFZlbG9jaXR5KDAsIDApO1xuICAgIHRoaXMucm90YXRpbmcgPSB0cnVlO1xuICAgIHRoaXMudHdlZW5zLmFkZCh7XG4gICAgICB0YXJnZXRzOiBbdGhpcy5wbGF5ZXJdLFxuICAgICAgYW5nbGU6IHRoaXMucGxheWVyLmFuZ2xlICsgOTAgKiBkZWx0YSxcbiAgICAgIHgsXG4gICAgICB5LFxuICAgICAgZHVyYXRpb246IDIwMCxcbiAgICAgIG9uQ29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgdGhpcy5yb3RhdGluZyA9IGZhbHNlO1xuICAgICAgICB0aGlzLnBsYXllci5ib2R5LnNldEFsbG93R3Jhdml0eSh0cnVlKTtcbiAgICAgICAgdGhpcy5kaXJlY3Rpb24gPSBQaGFzZXIuTWF0aC5XcmFwKHRoaXMuZGlyZWN0aW9uICsgZGVsdGEsIDAsIDQpICBhcyAwIHwgMSB8IDIgfCAzIDtcbiAgICAgICAgdGhpcy5zZXRHcmF2aXR5KCk7XG4gICAgICB9XG4gICAgfSlcbiAgfVxuICBcbiAgcHJpdmF0ZSBzZXRHcmF2aXR5KCkge1xuICAgIGNvbnN0IGRpcmVjdGlvbnMgPSBbXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldEdyYXZpdHkoMCwgdGhpcy5jb25maWcuZ3Jhdml0eSk7XG4gICAgICB9LFxuICAgICAgKCkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRHcmF2aXR5KC10aGlzLmNvbmZpZy5ncmF2aXR5LCAwKTtcbiAgICAgIH0sXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHRoaXMucGxheWVyLnNldEdyYXZpdHkoMCwgLXRoaXMuY29uZmlnLmdyYXZpdHkpO1xuICAgICAgfSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgdGhpcy5wbGF5ZXIuc2V0R3Jhdml0eSh0aGlzLmNvbmZpZy5ncmF2aXR5LCAwKTtcbiAgICAgIH1cbiAgICBdXG4gICAgZGlyZWN0aW9uc1t0aGlzLmRpcmVjdGlvbl0oKTtcbiAgfVxuICBcbiAgcHVibGljIGZsaXAoKSB7XG4gICAgaWYgKHRoaXMuaXNEZWFkKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgaWYgKHRoaXMuY2FuRmxpcEdyYXZpdHkpIHtcbiAgICAgIHRoaXMuY2FuRmxpcEdyYXZpdHkgPSBmYWxzZTtcbiAgICAgIGlmICh0aGlzLmRpcmVjdGlvbiA9PT0gMCB8fCB0aGlzLmRpcmVjdGlvbiA9PT0gMikge1xuICAgICAgICB0aGlzLnBsYXllci5ib2R5LmdyYXZpdHkueSAqPSAtMTtcbiAgICAgICAgdGhpcy5wbGF5ZXIuYm9keS5ncmF2aXR5LnggPSAwXG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnBsYXllci5ib2R5LmdyYXZpdHkueCAqPSAtMTtcbiAgICAgICAgdGhpcy5wbGF5ZXIuYm9keS5ncmF2aXR5LnkgPSAwXG4gICAgICB9XG4gICAgICB0aGlzLnBsYXllci5zZXRGbGlwWSghdGhpcy5pc0ZsaXBwZWQpXG4gICAgICBjb25zdCBkaXJlY3Rpb25zOiBBcnJheTwwIHwgMSB8IDIgfCAzPiA9IFsyLCAzLCAwLCAxXVxuICAgICAgdGhpcy5kaXJlY3Rpb24gPSBkaXJlY3Rpb25zW3RoaXMuZGlyZWN0aW9uXVxuICAgICAgdGhpcy5pc0ZsaXBwZWQgPSAhdGhpcy5pc0ZsaXBwZWRcbiAgICB9XG4gIH1cbiAgXG4gIHByaXZhdGUgcmVsb2NhdGUodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUsIGNhbGxiYWNrPzogKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB2b2lkLCBjYWxsYmFjazI/OiAodGlsZTogUGhhc2VyLlRpbGVtYXBzLlRpbGUpID0+IHZvaWQpIHtcbiAgICB0aGlzLnJlbG9jYXRpbmcgPSB0cnVlO1xuICAgIHRoaXMucGxheWVyLmJvZHkuc2V0QWxsb3dHcmF2aXR5KGZhbHNlKTtcbiAgICB0aGlzLnR3ZWVucy5hZGQoe1xuICAgICAgdGFyZ2V0czogW3RoaXMucGxheWVyXSxcbiAgICAgIGFscGhhOiB7XG4gICAgICAgIGZyb206IDEsXG4gICAgICAgIHRvOiAwXG4gICAgICB9LFxuICAgICAgZHVyYXRpb246IDEwMCxcbiAgICAgIG9uQ29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgaWYgKGNhbGxiYWNrICYmIHR5cGVvZiBjYWxsYmFjayA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgIGNhbGxiYWNrKHRpbGUpXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5yZXNldEZsaXBwYWdlKCk7XG4gICAgICAgIHRoaXMudHdlZW5zLmFkZCh7XG4gICAgICAgICAgdGFyZ2V0czogW3RoaXMucGxheWVyXSxcbiAgICAgICAgICB4OiB0aWxlLnBpeGVsWCArIDgsXG4gICAgICAgICAgeTogdGlsZS5waXhlbFkgKyA3LFxuICAgICAgICAgIG9uQ29tcGxldGU6ICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMudHdlZW5zLmFkZCh7XG4gICAgICAgICAgICAgIHRhcmdldHM6IFt0aGlzLnBsYXllcl0sXG4gICAgICAgICAgICAgIGFscGhhOiB7XG4gICAgICAgICAgICAgICAgZnJvbTogMCxcbiAgICAgICAgICAgICAgICB0bzogMSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgb25Db21wbGV0ZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMucGxheWVyLmJvZHkuc2V0QWxsb3dHcmF2aXR5KHRydWUpO1xuICAgICAgICAgICAgICAgIHRoaXMucmVsb2NhdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHRoaXMuY2hlY2twb2ludCA9IHRpbGU7XG4gICAgICAgICAgICAgICAgaWYgKGNhbGxiYWNrMiAmJiB0eXBlb2YgY2FsbGJhY2syID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICBjYWxsYmFjazIodGlsZSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG4gIFxuICBwcml2YXRlIHBpY2t1cEl0ZW0oaXRlbTogbnVtYmVyLCB0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkge1xuICAgIHRoaXMuYWN0aW9uc0xheWVyLnB1dFRpbGVBdChCTEFOSywgdGlsZS54LCB0aWxlLnkpO1xuICAgIHRoaXMuZXZlbnRzLmVtaXQoJ3BpY2t1cCcsIGl0ZW0pXG4gICAgdGhpcy5pdGVtcy5wdXNoKGl0ZW0pXG4gICAgdGhpcy5jaGVja3BvaW50ID0gdGlsZTtcbiAgfVxuICBcbiAgcHJpdmF0ZSByZXZpdmUoKSB7XG4gICAgdGhpcy5yZWxvY2F0ZShcbiAgICAgIHRoaXMuY2hlY2twb2ludCxcbiAgICAgICh0aWxlOiBQaGFzZXIuVGlsZW1hcHMuVGlsZSkgPT4ge1xuICAgICAgICB0aGlzLnBsYXllci5zZXRGcmFtZShBTElWRSk7XG4gICAgICB9LFxuICAgICAgKHRpbGU6IFBoYXNlci5UaWxlbWFwcy5UaWxlKSA9PiB7XG4gICAgICAgIHRoaXMuaXNEZWFkID0gZmFsc2U7XG4gICAgICB9XG4gICAgKVxuICB9XG4gIFxuICBwcml2YXRlIHJlc2V0RmxpcHBhZ2UoKSB7XG4gICAgdGhpcy5kaXJlY3Rpb24gPSAwO1xuICAgIHRoaXMuc2V0R3Jhdml0eSgpO1xuICAgIHRoaXMuaXNGbGlwcGVkID0gZmFsc2U7XG4gICAgdGhpcy5wbGF5ZXIuc2V0RmxpcFgoZmFsc2UpO1xuICAgIHRoaXMucGxheWVyLnNldEZsaXBZKGZhbHNlKTtcbiAgICB0aGlzLnBsYXllci5zZXRBbmdsZSgwKTtcbiAgfVxuICBcbiAgcHVibGljIGtpbGxQbGF5ZXIoKSB7XG4gICAgdGhpcy5wbGF5ZXIuc2V0VmVsb2NpdHkoMCwgMClcbiAgICB0aGlzLnBsYXllci5ib2R5LnNldEFsbG93R3Jhdml0eShmYWxzZSlcbiAgICB0aGlzLnBsYXllci5hbmltcy5zdG9wKClcbiAgICB0aGlzLnBsYXllci5zZXRGcmFtZShERUFEKVxuICAgIHRoaXMuaXNEZWFkID0gdHJ1ZVxuICAgIHRoaXMudGltZS5kZWxheWVkQ2FsbCgxMDAwLCB0aGlzLnJldml2ZSwgW10sIHRoaXMpXG4gIH1cbn1cblxudHlwZSBDb25maWcgPSB7XG4gIGdyYXZpdHk6IG51bWJlcjtcbiAgc3BlZWQ6IG51bWJlcjtcbiAgZ3Jhdml0eURpcmVjdGlvbjogbnVtYmVyO1xuICBqdW1wRm9yY2U6IG51bWJlcjtcbn0iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCAqIGFzIFN0b3JlIGZyb20gJ3N0b3JlJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ2dhbWUtb2JqZWN0cyc7XG5pbXBvcnQgeyBDT0xPVVJTLCBCTEFOSyB9IGZyb20gJ2NvbnN0YW50cyc7XG5cbmNvbnN0IGZvbnRTdHlsZSA9IHtcbiAgZmlsbDogQ09MT1VSUy5tYXJvb24uc3RyaW5nLFxuICBmb250RmFtaWx5OiAna2VubnkxYml0JyxcbiAgYWxpZ246ICdjZW50ZXInLFxufVxuY29uc3Qgc2NlbmVDb25maWc6IFBoYXNlci5UeXBlcy5TY2VuZXMuU2V0dGluZ3NDb25maWcgPSB7XG4gIGFjdGl2ZTogZmFsc2UsXG4gIHZpc2libGU6IGZhbHNlLFxuICBrZXk6ICdIVUQnLFxufTtcblxuZXhwb3J0IGNsYXNzIEhVRFNjZW5lIGV4dGVuZHMgUGhhc2VyLlNjZW5lIHtcbiAgdGltZVRleHQ6IFBoYXNlci5HYW1lT2JqZWN0cy5UZXh0O1xuICBtYXhUaW1lOiBudW1iZXI7XG4gIHRpbWVUaXRsZTogUGhhc2VyLkdhbWVPYmplY3RzLlRleHQ7XG4gIGl0ZW1zOiBBcnJheTxudW1iZXI+O1xuICBtYXA6IFBoYXNlci5UaWxlbWFwcy5UaWxlbWFwO1xuICB0aWxlczogUGhhc2VyLlRpbGVtYXBzLlRpbGVzZXQ7XG4gIHRpbWVkRXZlbnQ6IFBoYXNlci5UaW1lLlRpbWVyRXZlbnQ7XG4gIHRpbWVyOiBudW1iZXI7XG4gIGNvbXBsZXRlZFRleHQ6IFBoYXNlci5HYW1lT2JqZWN0cy5UZXh0O1xuICBsZXZlbDogbnVtYmVyO1xuICBuZXh0TGV2ZWxCdXR0b246IEJ1dHRvbjtcbiAgdGhhbmt5b3VUZXh0OiBHYW1lT2JqZWN0IHwgR3JvdXA7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHNjZW5lQ29uZmlnKTsgIFxuICB9XG4gIFxuICBwdWJsaWMgaW5pdCh7IGxldmVsIH06IHtcbiAgICBsZXZlbDogbnVtYmVyO1xuICB9KSB7XG4gICAgdGhpcy5sZXZlbCA9IGxldmVsO1xuICAgIHRoaXMudGltZXIgPSAwO1xuICB9XG4gIFxuICAvKipcbiAgICogY3JlYXRlXG4gICAqL1xuICBwdWJsaWMgY3JlYXRlKCkge1xuICAgIGNvbnN0IHsgRU5URVIgfSA9IFBoYXNlci5JbnB1dC5LZXlib2FyZC5LZXlDb2RlcztcbiAgICBjb25zdCBlbnRlcktleSA9IHRoaXMuaW5wdXQua2V5Ym9hcmQuYWRkS2V5KEVOVEVSKTtcbiAgICBcbiAgICB0aGlzLml0ZW1zID0gW11cbiAgICB0aGlzLm1hcCA9IHRoaXMubWFrZS50aWxlbWFwKHsga2V5OiBgbWFwJHt0aGlzLmxldmVsfWAgfSk7XG4gICAgdGhpcy50aWxlcyA9IHRoaXMubWFwLmFkZFRpbGVzZXRJbWFnZSgndGlsZXMnKTtcbiAgICBjb25zdCBodWRHcmFwaGljcyA9IHRoaXMuYWRkLmdyYXBoaWNzKHtcbiAgICAgIGZpbGxTdHlsZToge1xuICAgICAgICBhbHBoYTogMC45LFxuICAgICAgICBjb2xvcjogQ09MT1VSUy53aGl0ZS5udW1iZXJcbiAgICAgIH0sXG4gICAgfSkuc2V0U2Nyb2xsRmFjdG9yKDApO1xuICAgIGNvbnN0IGl0ZW1HcmFwaGljcyA9IHRoaXMuYWRkLmdyYXBoaWNzKHtcbiAgICAgIGZpbGxTdHlsZToge1xuICAgICAgICBjb2xvcjogQ09MT1VSUy5tYXJvb24ubnVtYmVyXG4gICAgICB9XG4gICAgfSlcbiAgICBjb25zdCBodWRCZyA9IG5ldyBQaGFzZXIuR2VvbS5SZWN0YW5nbGUoNjUwLCAwLCAxNTAsIDYwMClcbiAgICBodWRHcmFwaGljcy5maWxsUmVjdFNoYXBlKGh1ZEJnKVxuICAgIHRoaXMudGltZVRpdGxlID0gdGhpcy5hZGQudGV4dCg2NzAsIDEwLCAnIHRpbWUnLCBmb250U3R5bGUpXG4gICAgdGhpcy50aW1lVGV4dCA9IHRoaXMuYWRkLnRleHQoNjcwLCA1MCwgJycsIGZvbnRTdHlsZSlcblxuICAgIHRoaXMuY29tcGxldGVkVGV4dCA9IHRoaXMuYWRkLnRleHQoNDAwLCAzMDAsICcgbGV2ZWwgY29tcGxldGVkIScsIHtcbiAgICAgIC4uLmZvbnRTdHlsZSxcbiAgICAgIGZpbGw6IENPTE9VUlMuZ3JlZW4uc3RyaW5nLFxuICAgIH0pLnNldE9yaWdpbigwLjUpLnNldEFscGhhKDApXG4gICAgdGhpcy50aGFua3lvdVRleHQgPSB0aGlzLmFkZC50ZXh0KDQwMCwgMzUwLCAnIHRoYW5rIHlvdSBmb3IgcGxheWluZyBteSBnYW1lJywge1xuICAgICAgLi4uZm9udFN0eWxlLFxuICAgICAgZmlsbDogQ09MT1VSUy5ncmVlbi5zdHJpbmcsXG4gICAgfSkuc2V0T3JpZ2luKDAuNSkuc2V0QWxwaGEoMClcbiAgICB0aGlzLm5leHRMZXZlbEJ1dHRvbiA9IG5ldyBCdXR0b24odGhpcywgNDAwLCAzNTAsICcgbmV4dCBsZXZlbCAtIGhpdCBlbnRlcicsIHtcbiAgICAgIGZpbGw6IENPTE9VUlMud2hpdGUuc3RyaW5nLFxuICAgICAgZm9udEZhbWlseTogJ2tlbm55MWJpdCcsXG4gICAgICBhbGlnbjogJ2NlbnRlcicsXG4gICAgfSwge1xuICAgICAgcG9pbnRlcnVwOiAoKSA9PiB0aGlzLm5leHRMZXZlbCgpLFxuICAgIH0pLnNldE9yaWdpbigwLjUpO1xuICAgIGNvbnN0IHNsb3QxID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg2NzAsIDE1MCwgNTAsIDUwKVxuICAgIGNvbnN0IHNsb3QyID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg3MzAsIDE1MCwgNTAsIDUwKVxuICAgIGNvbnN0IHNsb3QzID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg2NzAsIDIxMCwgNTAsIDUwKVxuICAgIGNvbnN0IHNsb3Q0ID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg3MzAsIDIxMCwgNTAsIDUwKVxuICAgIGNvbnN0IHNsb3Q1ID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg2NzAsIDI3MCwgNTAsIDUwKVxuICAgIGNvbnN0IHNsb3Q2ID0gbmV3IFBoYXNlci5HZW9tLlJlY3RhbmdsZSg3MzAsIDI3MCwgNTAsIDUwKVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3QxKVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3QyKVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3QzKVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3Q0KVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3Q1KVxuICAgIGl0ZW1HcmFwaGljcy5maWxsUmVjdFNoYXBlKHNsb3Q2KVxuICAgIGNvbnN0IGl0ZW1TcHJpdGVzID0gW1xuICAgICAgdGhpcy5hZGQuc3ByaXRlKDY5NSwgMTc1LCAndGlsZXMnLCBCTEFOSykuc2V0U2NhbGUoMiksXG4gICAgICB0aGlzLmFkZC5zcHJpdGUoNzU1LCAxNzUsICd0aWxlcycsIEJMQU5LKS5zZXRTY2FsZSgyKSxcbiAgICAgIHRoaXMuYWRkLnNwcml0ZSg2OTUsIDIzNSwgJ3RpbGVzJywgQkxBTkspLnNldFNjYWxlKDIpLFxuICAgICAgdGhpcy5hZGQuc3ByaXRlKDc1NSwgMjM1LCAndGlsZXMnLCBCTEFOSykuc2V0U2NhbGUoMiksXG4gICAgICB0aGlzLmFkZC5zcHJpdGUoNjk1LCAxOTUsICd0aWxlcycsIEJMQU5LKS5zZXRTY2FsZSgyKSxcbiAgICAgIHRoaXMuYWRkLnNwcml0ZSg3NTUsIDE5NSwgJ3RpbGVzJywgQkxBTkspLnNldFNjYWxlKDIpLFxuICAgIF1cbiAgICBcbiAgICB0aGlzLnNjZW5lLmdldCgnR2FtZScpLmV2ZW50cy5vbigncGlja3VwJywgKGl0ZW06IG51bWJlcikgPT4ge1xuICAgICAgY29uc3QgaW5kZXggPSB0aGlzLml0ZW1zLmxlbmd0aDtcbiAgICAgIHRoaXMuaXRlbXMucHVzaChpdGVtKVxuICAgICAgaXRlbVNwcml0ZXNbaW5kZXhdLnNldEZyYW1lKGl0ZW0gLSAxKVxuICAgIH0pO1xuICAgIFxuICAgIHRoaXMuc2NlbmUuZ2V0KCdHYW1lJykuZXZlbnRzLm9uKCdjb21wbGV0ZWQnLCAoKSA9PiB7XG4gICAgICBTdG9yZS5zZXQoJ2hpZ2hlc3RMZXZlbCcsIHRoaXMubGV2ZWwgKyAxKVxuICAgICAgdGhpcy50aW1lZEV2ZW50LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuY29tcGxldGVkVGV4dC5zZXRBbHBoYSgxKTtcbiAgICAgIGlmICh0aGlzLmxldmVsID09PSA5KSB7XG4gICAgICAgIHRoaXMuYWRkLmV4aXN0aW5nKHRoaXMudGhhbmt5b3VUZXh0KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5hZGQuZXhpc3RpbmcodGhpcy5uZXh0TGV2ZWxCdXR0b24pO1xuICAgICAgfVxuICAgICAgXG4gICAgICBcbiAgICB9KTtcbiAgICBcbiAgICB0aGlzLnRpbWVkRXZlbnQgPSB0aGlzLnRpbWUuYWRkRXZlbnQoeyBkZWxheTogMTAwMCwgY2FsbGJhY2s6ICgpID0+IHtcbiAgICAgIHRoaXMudGltZXIgKz0gMTtcbiAgICAgIHRoaXMudGltZVRleHQuc2V0VGV4dChgICR7dGhpcy50aW1lcn1gKVxuICAgIH0sIGNhbGxiYWNrU2NvcGU6IHRoaXMsIGxvb3A6IHRydWUgfSk7XG4gICAgXG4gICAgZW50ZXJLZXkub24oXCJkb3duXCIsICgpID0+IHRoaXMubmV4dExldmVsKCkpO1xuICB9XG4gIFxuICBwcml2YXRlIG5leHRMZXZlbCAoKSB7XG4gICAgY29uc3QgbGV2ZWwgPSB0aGlzLmxldmVsICsgMTtcbiAgICBjb25zdCBnYW1lU2NlbmUgPSB0aGlzLnNjZW5lLmdldCgnR2FtZScpXG4gICAgZ2FtZVNjZW5lLmV2ZW50cy5yZW1vdmVMaXN0ZW5lcigncGlja3VwJyk7XG4gICAgZ2FtZVNjZW5lLmV2ZW50cy5yZW1vdmVMaXN0ZW5lcignY29tcGxldGVkJyk7XG4gICAgZ2FtZVNjZW5lLnNjZW5lLnJlc3RhcnQoeyBsZXZlbCB9KVxuICAgIHRoaXMuc2NlbmUucmVzdGFydCh7IGxldmVsIH0pXG4gIH1cbiAgXG59XG4iLCJpbXBvcnQgeyBCb290U2NlbmUgfSBmcm9tICcuL2Jvb3QnO1xuaW1wb3J0IHsgR2FtZVNjZW5lIH0gZnJvbSAnLi9nYW1lJztcbmltcG9ydCB7IEhVRFNjZW5lIH0gZnJvbSAnLi9odWQnO1xuaW1wb3J0IHsgVGl0bGVTY2VuZSB9IGZyb20gJy4vdGl0bGUnO1xuXG5leHBvcnQgZGVmYXVsdCBbXG4gIEJvb3RTY2VuZSxcbiAgR2FtZVNjZW5lLFxuICBIVURTY2VuZSxcbiAgVGl0bGVTY2VuZSxcbl07XG4iLCJpbXBvcnQgKiBhcyBQaGFzZXIgZnJvbSAncGhhc2VyJztcbmltcG9ydCAqIGFzIFN0b3JlIGZyb20gJ3N0b3JlJztcbmltcG9ydCB7IENPTE9VUlMsIFpFUk8sIENVUlNPUiwgQkxBTksgfSBmcm9tICdjb25zdGFudHMnO1xuXG5jb25zdCBzY2VuZUNvbmZpZzogUGhhc2VyLlR5cGVzLlNjZW5lcy5TZXR0aW5nc0NvbmZpZyA9IHtcbiAgYWN0aXZlOiBmYWxzZSxcbiAgdmlzaWJsZTogZmFsc2UsXG4gIGtleTogJ1RpdGxlJyxcbn07XG5cbmV4cG9ydCBjbGFzcyBUaXRsZVNjZW5lIGV4dGVuZHMgUGhhc2VyLlNjZW5lIHtcbiAgY3Vyc29yczogUGhhc2VyLlR5cGVzLklucHV0LktleWJvYXJkLkN1cnNvcktleXM7XG4gIG1hcDogUGhhc2VyLlRpbGVtYXBzLlRpbGVtYXA7XG4gIHRpbGVzOiBQaGFzZXIuVGlsZW1hcHMuVGlsZXNldDtcbiAgYmdMYXllcjogUGhhc2VyLlRpbGVtYXBzLlN0YXRpY1RpbGVtYXBMYXllcjtcbiAgc3Bpa2VzTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5TdGF0aWNUaWxlbWFwTGF5ZXI7XG4gIGFjdGlvbnNMYXllcjogUGhhc2VyLlRpbGVtYXBzLkR5bmFtaWNUaWxlbWFwTGF5ZXI7XG4gIGN1cnNvcjogUGhhc2VyLkdhbWVPYmplY3RzLlNwcml0ZTtcbiAgc2VsZWN0ZWQ6IG51bWJlcjtcbiAgbnVtYmVyTGF5ZXI6IFBoYXNlci5UaWxlbWFwcy5TdGF0aWNUaWxlbWFwTGF5ZXI7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKHNjZW5lQ29uZmlnKTtcbiAgfVxuXG4gIHB1YmxpYyBjcmVhdGUoKSB7XG4gICAgY29uc3QgeyBFTlRFUiB9ID0gUGhhc2VyLklucHV0LktleWJvYXJkLktleUNvZGVzO1xuICAgIGNvbnN0IGVudGVyS2V5ID0gdGhpcy5pbnB1dC5rZXlib2FyZC5hZGRLZXkoRU5URVIpO1xuICAgIGNvbnN0IGhpZ2hlc3RMZXZlbCA9IFN0b3JlLmdldCgnaGlnaGVzdExldmVsJykgfHwgMDtcbiAgICB0aGlzLnNlbGVjdGVkID0gaGlnaGVzdExldmVsO1xuICAgIHRoaXMuY3Vyc29ycyA9IHRoaXMuaW5wdXQua2V5Ym9hcmQuY3JlYXRlQ3Vyc29yS2V5cygpO1xuICAgIHRoaXMubWFwID0gdGhpcy5tYWtlLnRpbGVtYXAoeyBrZXk6IGB0aXRsZWAgfSk7XG4gICAgdGhpcy50aWxlcyA9IHRoaXMubWFwLmFkZFRpbGVzZXRJbWFnZSgndGlsZXMnKTtcbiAgICB0aGlzLmJnTGF5ZXIgPSB0aGlzLm1hcC5jcmVhdGVTdGF0aWNMYXllcignQmFja2dyb3VuZCcsIHRoaXMudGlsZXMpXG4gICAgdGhpcy5udW1iZXJMYXllciA9IHRoaXMubWFwLmNyZWF0ZVN0YXRpY0xheWVyKCdOdW1iZXJzJywgdGhpcy50aWxlcylcbiAgICB0aGlzLmFjdGlvbnNMYXllciA9IHRoaXMubWFwLmNyZWF0ZUR5bmFtaWNMYXllcignQWN0aW9ucycsIHRoaXMudGlsZXMpXG4gICAgXG4gICAgY29uc3QgbGV2ZWxUaWxlczogQXJyYXk8UGhhc2VyLlRpbGVtYXBzLlRpbGU+ID0gW11cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcbiAgICAgIGNvbnN0IHRpbGUgPSB0aGlzLm51bWJlckxheWVyLmZpbmRCeUluZGV4KFpFUk8gKyBpKSBcbiAgICAgIGlmIChpIDw9IGhpZ2hlc3RMZXZlbCkge1xuICAgICAgICB0aGlzLmFjdGlvbnNMYXllci5wdXRUaWxlQXQoQkxBTkssIHRpbGUueCwgdGlsZS55KTtcbiAgICAgIH1cbiAgICAgIGxldmVsVGlsZXMucHVzaCh0aWxlKVxuICAgIH1cbiAgICBjb25zdCBzdGFydFRpbGUgPSBsZXZlbFRpbGVzW3RoaXMuc2VsZWN0ZWRdO1xuICAgIHRoaXMuY3Vyc29yID0gdGhpcy5hZGQuc3ByaXRlKHN0YXJ0VGlsZS5waXhlbFgsIHN0YXJ0VGlsZS5waXhlbFksICd0aWxlcycsIENVUlNPUikuc2V0T3JpZ2luKDAsIDApO1xuICAgIFxuICAgIHRoaXMuY2FtZXJhcy5tYWluLnNldEJvdW5kcygwLCAwLCA4MDAsIDYwMCk7XG4gICAgdGhpcy5jYW1lcmFzLm1haW4uc3RhcnRGb2xsb3codGhpcy5jdXJzb3IpO1xuICAgIHRoaXMuY2FtZXJhcy5tYWluLnNldFpvb20oMik7XG5cbiAgICB0aGlzLmN1cnNvcnMubGVmdC5vbihcImRvd25cIiwgKCkgPT4ge1xuICAgICAgdGhpcy5zZWxlY3RlZCA9IHRoaXMuc2VsZWN0ZWQgPT09IDAgPyBoaWdoZXN0TGV2ZWwgOiB0aGlzLnNlbGVjdGVkIC0gMTtcbiAgICAgIHRoaXMuY3Vyc29yLnNldFgobGV2ZWxUaWxlc1t0aGlzLnNlbGVjdGVkXS5waXhlbFgpXG4gICAgfSlcbiAgICB0aGlzLmN1cnNvcnMucmlnaHQub24oXCJkb3duXCIsICgpID0+IHtcbiAgICAgIHRoaXMuc2VsZWN0ZWQgPSB0aGlzLnNlbGVjdGVkID09PSBoaWdoZXN0TGV2ZWwgPyAwIDogdGhpcy5zZWxlY3RlZCArIDE7XG4gICAgICB0aGlzLmN1cnNvci5zZXRYKGxldmVsVGlsZXNbdGhpcy5zZWxlY3RlZF0ucGl4ZWxYKVxuICAgIH0pXG5cbiAgICBlbnRlcktleS5vbihcImRvd25cIiwgKCkgPT4ge1xuICAgICAgdGhpcy5zdGFydEdhbWUodGhpcy5zZWxlY3RlZClcbiAgICB9KTtcbiAgfVxuICBcbiAgcHJpdmF0ZSBzdGFydEdhbWUobGV2ZWw6IG51bWJlcikge1xuICAgIHRoaXMuc2NlbmUubGF1bmNoKCdHYW1lJywgeyBsZXZlbCB9KS5sYXVuY2goJ0hVRCcsIHsgbGV2ZWwgfSkuc3RvcCgpO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9