<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tiles" tilewidth="16" tileheight="16" tilecount="1056" columns="48" backgroundcolor="#000000">
 <image source="tiles.png" width="768" height="352"/>
</tileset>
