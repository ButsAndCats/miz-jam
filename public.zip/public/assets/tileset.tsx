<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="colored" tilewidth="16" tileheight="16" spacing="1" tilecount="1024" columns="32">
 <image source="../../../../Downloads/1bitpack_kenney_1.1/Tilemap/tileset_legacy.png" width="543" height="543"/>
</tileset>
